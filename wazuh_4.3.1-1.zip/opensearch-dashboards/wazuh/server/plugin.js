"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhPlugin = void 0;

var _securityFactory = require("./lib/security-factory");

var _routes = require("./routes");

var _start = require("./start");

var _cookie = require("./lib/cookie");

var ApiInterceptor = _interopRequireWildcard(require("./lib/api-interceptor"));

var _operators = require("rxjs/operators");

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class WazuhPlugin {
  constructor(initializerContext) {
    this.initializerContext = initializerContext;

    _defineProperty(this, "logger", void 0);

    this.logger = initializerContext.logger.get();
  }

  async setup(core, plugins) {
    this.logger.debug('Wazuh-wui: Setup');
    const wazuhSecurity = await (0, _securityFactory.SecurityObj)(plugins);
    const serverInfo = core.http.getServerInfo();
    core.http.registerRouteHandlerContext('wazuh', (context, request) => {
      return {
        logger: this.logger,
        server: {
          info: serverInfo
        },
        plugins,
        security: wazuhSecurity,
        api: {
          client: {
            asInternalUser: {
              authenticate: async apiHostID => await ApiInterceptor.authenticate(apiHostID),
              request: async (method, path, data, options) => await ApiInterceptor.requestAsInternalUser(method, path, data, options)
            },
            asCurrentUser: {
              authenticate: async apiHostID => await ApiInterceptor.authenticate(apiHostID, (await wazuhSecurity.getCurrentUser(request, context)).authContext),
              request: async (method, path, data, options) => await ApiInterceptor.requestAsCurrentUser(method, path, data, { ...options,
                token: (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-token')
              })
            }
          }
        }
      };
    }); // Add custom headers to the responses

    core.http.registerOnPreResponse((request, response, toolkit) => {
      const additionalHeaders = {
        'x-frame-options': 'sameorigin'
      };
      return toolkit.next({
        headers: additionalHeaders
      });
    }); // Routes

    const router = core.http.createRouter();
    (0, _routes.setupRoutes)(router);
    return {};
  }

  async start(core) {
    const globalConfiguration = await this.initializerContext.config.legacy.globalConfig$.pipe((0, _operators.first)()).toPromise();
    const wazuhApiClient = {
      client: {
        asInternalUser: {
          authenticate: async apiHostID => await ApiInterceptor.authenticate(apiHostID),
          request: async (method, path, data, options) => await ApiInterceptor.requestAsInternalUser(method, path, data, options)
        }
      }
    };
    const contextServer = {
      config: globalConfiguration
    }; // Initialize

    (0, _start.jobInitializeRun)({
      core,
      wazuh: {
        logger: this.logger.get('initialize'),
        api: wazuhApiClient
      },
      server: contextServer
    }); // Monitoring

    (0, _start.jobMonitoringRun)({
      core,
      wazuh: {
        logger: this.logger.get('monitoring'),
        api: wazuhApiClient
      },
      server: contextServer
    }); // Scheduler

    (0, _start.jobSchedulerRun)({
      core,
      wazuh: {
        logger: this.logger.get('cron-scheduler'),
        api: wazuhApiClient
      },
      server: contextServer
    }); // Queue

    (0, _start.jobQueueRun)({
      core,
      wazuh: {
        logger: this.logger.get('queue'),
        api: wazuhApiClient
      },
      server: contextServer
    });
    return {};
  }

  stop() {}

}

exports.WazuhPlugin = WazuhPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBsdWdpbi50cyJdLCJuYW1lcyI6WyJXYXp1aFBsdWdpbiIsImNvbnN0cnVjdG9yIiwiaW5pdGlhbGl6ZXJDb250ZXh0IiwibG9nZ2VyIiwiZ2V0Iiwic2V0dXAiLCJjb3JlIiwicGx1Z2lucyIsImRlYnVnIiwid2F6dWhTZWN1cml0eSIsInNlcnZlckluZm8iLCJodHRwIiwiZ2V0U2VydmVySW5mbyIsInJlZ2lzdGVyUm91dGVIYW5kbGVyQ29udGV4dCIsImNvbnRleHQiLCJyZXF1ZXN0Iiwic2VydmVyIiwiaW5mbyIsInNlY3VyaXR5IiwiYXBpIiwiY2xpZW50IiwiYXNJbnRlcm5hbFVzZXIiLCJhdXRoZW50aWNhdGUiLCJhcGlIb3N0SUQiLCJBcGlJbnRlcmNlcHRvciIsIm1ldGhvZCIsInBhdGgiLCJkYXRhIiwib3B0aW9ucyIsInJlcXVlc3RBc0ludGVybmFsVXNlciIsImFzQ3VycmVudFVzZXIiLCJnZXRDdXJyZW50VXNlciIsImF1dGhDb250ZXh0IiwicmVxdWVzdEFzQ3VycmVudFVzZXIiLCJ0b2tlbiIsImhlYWRlcnMiLCJjb29raWUiLCJyZWdpc3Rlck9uUHJlUmVzcG9uc2UiLCJyZXNwb25zZSIsInRvb2xraXQiLCJhZGRpdGlvbmFsSGVhZGVycyIsIm5leHQiLCJyb3V0ZXIiLCJjcmVhdGVSb3V0ZXIiLCJzdGFydCIsImdsb2JhbENvbmZpZ3VyYXRpb24iLCJjb25maWciLCJsZWdhY3kiLCJnbG9iYWxDb25maWckIiwicGlwZSIsInRvUHJvbWlzZSIsIndhenVoQXBpQ2xpZW50IiwiY29udGV4dFNlcnZlciIsIndhenVoIiwic3RvcCJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQTZCQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFHQTs7Ozs7Ozs7QUF3Qk8sTUFBTUEsV0FBTixDQUF3RTtBQUc3RUMsRUFBQUEsV0FBVyxDQUFrQkMsa0JBQWxCLEVBQWdFO0FBQUEsU0FBOUNBLGtCQUE4QyxHQUE5Q0Esa0JBQThDOztBQUFBOztBQUN6RSxTQUFLQyxNQUFMLEdBQWNELGtCQUFrQixDQUFDQyxNQUFuQixDQUEwQkMsR0FBMUIsRUFBZDtBQUNEOztBQUVELFFBQWFDLEtBQWIsQ0FBbUJDLElBQW5CLEVBQW9DQyxPQUFwQyxFQUEwRDtBQUN4RCxTQUFLSixNQUFMLENBQVlLLEtBQVosQ0FBa0Isa0JBQWxCO0FBRUEsVUFBTUMsYUFBYSxHQUFHLE1BQU0sa0NBQVlGLE9BQVosQ0FBNUI7QUFDQSxVQUFNRyxVQUFVLEdBQUdKLElBQUksQ0FBQ0ssSUFBTCxDQUFVQyxhQUFWLEVBQW5CO0FBRUFOLElBQUFBLElBQUksQ0FBQ0ssSUFBTCxDQUFVRSwyQkFBVixDQUFzQyxPQUF0QyxFQUErQyxDQUFDQyxPQUFELEVBQVVDLE9BQVYsS0FBc0I7QUFDbkUsYUFBTztBQUNMWixRQUFBQSxNQUFNLEVBQUUsS0FBS0EsTUFEUjtBQUVMYSxRQUFBQSxNQUFNLEVBQUU7QUFDTkMsVUFBQUEsSUFBSSxFQUFFUDtBQURBLFNBRkg7QUFLTEgsUUFBQUEsT0FMSztBQU1MVyxRQUFBQSxRQUFRLEVBQUVULGFBTkw7QUFPTFUsUUFBQUEsR0FBRyxFQUFFO0FBQ0hDLFVBQUFBLE1BQU0sRUFBRTtBQUNOQyxZQUFBQSxjQUFjLEVBQUU7QUFDZEMsY0FBQUEsWUFBWSxFQUFFLE1BQU9DLFNBQVAsSUFBcUIsTUFBTUMsY0FBYyxDQUFDRixZQUFmLENBQTRCQyxTQUE1QixDQUQzQjtBQUVkUixjQUFBQSxPQUFPLEVBQUUsT0FBT1UsTUFBUCxFQUFlQyxJQUFmLEVBQXFCQyxJQUFyQixFQUEyQkMsT0FBM0IsS0FBdUMsTUFBTUosY0FBYyxDQUFDSyxxQkFBZixDQUFxQ0osTUFBckMsRUFBNkNDLElBQTdDLEVBQW1EQyxJQUFuRCxFQUF5REMsT0FBekQ7QUFGeEMsYUFEVjtBQUtORSxZQUFBQSxhQUFhLEVBQUU7QUFDYlIsY0FBQUEsWUFBWSxFQUFFLE1BQU9DLFNBQVAsSUFBcUIsTUFBTUMsY0FBYyxDQUFDRixZQUFmLENBQTRCQyxTQUE1QixFQUF1QyxDQUFDLE1BQU1kLGFBQWEsQ0FBQ3NCLGNBQWQsQ0FBNkJoQixPQUE3QixFQUFzQ0QsT0FBdEMsQ0FBUCxFQUF1RGtCLFdBQTlGLENBRDVCO0FBRWJqQixjQUFBQSxPQUFPLEVBQUUsT0FBT1UsTUFBUCxFQUFlQyxJQUFmLEVBQXFCQyxJQUFyQixFQUEyQkMsT0FBM0IsS0FBdUMsTUFBTUosY0FBYyxDQUFDUyxvQkFBZixDQUFvQ1IsTUFBcEMsRUFBNENDLElBQTVDLEVBQWtEQyxJQUFsRCxFQUF3RCxFQUFDLEdBQUdDLE9BQUo7QUFBYU0sZ0JBQUFBLEtBQUssRUFBRSxrQ0FBcUJuQixPQUFPLENBQUNvQixPQUFSLENBQWdCQyxNQUFyQyxFQUE2QyxVQUE3QztBQUFwQixlQUF4RDtBQUZ6QztBQUxUO0FBREw7QUFQQSxPQUFQO0FBb0JELEtBckJELEVBTndELENBNkJ4RDs7QUFDQTlCLElBQUFBLElBQUksQ0FBQ0ssSUFBTCxDQUFVMEIscUJBQVYsQ0FBZ0MsQ0FBQ3RCLE9BQUQsRUFBVXVCLFFBQVYsRUFBb0JDLE9BQXBCLEtBQWdDO0FBQzlELFlBQU1DLGlCQUFpQixHQUFHO0FBQ3hCLDJCQUFtQjtBQURLLE9BQTFCO0FBR0EsYUFBT0QsT0FBTyxDQUFDRSxJQUFSLENBQWE7QUFBRU4sUUFBQUEsT0FBTyxFQUFFSztBQUFYLE9BQWIsQ0FBUDtBQUNELEtBTEQsRUE5QndELENBcUN4RDs7QUFDQSxVQUFNRSxNQUFNLEdBQUdwQyxJQUFJLENBQUNLLElBQUwsQ0FBVWdDLFlBQVYsRUFBZjtBQUNBLDZCQUFZRCxNQUFaO0FBRUEsV0FBTyxFQUFQO0FBQ0Q7O0FBRUQsUUFBYUUsS0FBYixDQUFtQnRDLElBQW5CLEVBQW9DO0FBQ2xDLFVBQU11QyxtQkFBdUMsR0FBRyxNQUFNLEtBQUszQyxrQkFBTCxDQUF3QjRDLE1BQXhCLENBQStCQyxNQUEvQixDQUFzQ0MsYUFBdEMsQ0FBb0RDLElBQXBELENBQXlELHVCQUF6RCxFQUFrRUMsU0FBbEUsRUFBdEQ7QUFDQSxVQUFNQyxjQUFjLEdBQUc7QUFDckIvQixNQUFBQSxNQUFNLEVBQUU7QUFDTkMsUUFBQUEsY0FBYyxFQUFFO0FBQ2RDLFVBQUFBLFlBQVksRUFBRSxNQUFPQyxTQUFQLElBQXFCLE1BQU1DLGNBQWMsQ0FBQ0YsWUFBZixDQUE0QkMsU0FBNUIsQ0FEM0I7QUFFZFIsVUFBQUEsT0FBTyxFQUFFLE9BQU9VLE1BQVAsRUFBZUMsSUFBZixFQUFxQkMsSUFBckIsRUFBMkJDLE9BQTNCLEtBQXVDLE1BQU1KLGNBQWMsQ0FBQ0sscUJBQWYsQ0FBcUNKLE1BQXJDLEVBQTZDQyxJQUE3QyxFQUFtREMsSUFBbkQsRUFBeURDLE9BQXpEO0FBRnhDO0FBRFY7QUFEYSxLQUF2QjtBQVNBLFVBQU13QixhQUFhLEdBQUc7QUFDcEJOLE1BQUFBLE1BQU0sRUFBRUQ7QUFEWSxLQUF0QixDQVhrQyxDQWVsQzs7QUFDQSxpQ0FBaUI7QUFDZnZDLE1BQUFBLElBRGU7QUFFZitDLE1BQUFBLEtBQUssRUFBRTtBQUNMbEQsUUFBQUEsTUFBTSxFQUFFLEtBQUtBLE1BQUwsQ0FBWUMsR0FBWixDQUFnQixZQUFoQixDQURIO0FBRUxlLFFBQUFBLEdBQUcsRUFBRWdDO0FBRkEsT0FGUTtBQU1mbkMsTUFBQUEsTUFBTSxFQUFFb0M7QUFOTyxLQUFqQixFQWhCa0MsQ0F5QmxDOztBQUNBLGlDQUFpQjtBQUNmOUMsTUFBQUEsSUFEZTtBQUVmK0MsTUFBQUEsS0FBSyxFQUFFO0FBQ0xsRCxRQUFBQSxNQUFNLEVBQUUsS0FBS0EsTUFBTCxDQUFZQyxHQUFaLENBQWdCLFlBQWhCLENBREg7QUFFTGUsUUFBQUEsR0FBRyxFQUFFZ0M7QUFGQSxPQUZRO0FBTWZuQyxNQUFBQSxNQUFNLEVBQUVvQztBQU5PLEtBQWpCLEVBMUJrQyxDQW1DbEM7O0FBQ0EsZ0NBQWdCO0FBQ2Q5QyxNQUFBQSxJQURjO0FBRWQrQyxNQUFBQSxLQUFLLEVBQUU7QUFDTGxELFFBQUFBLE1BQU0sRUFBRSxLQUFLQSxNQUFMLENBQVlDLEdBQVosQ0FBZ0IsZ0JBQWhCLENBREg7QUFFTGUsUUFBQUEsR0FBRyxFQUFFZ0M7QUFGQSxPQUZPO0FBTWRuQyxNQUFBQSxNQUFNLEVBQUVvQztBQU5NLEtBQWhCLEVBcENrQyxDQTZDbEM7O0FBQ0EsNEJBQVk7QUFDVjlDLE1BQUFBLElBRFU7QUFFVitDLE1BQUFBLEtBQUssRUFBRTtBQUNMbEQsUUFBQUEsTUFBTSxFQUFFLEtBQUtBLE1BQUwsQ0FBWUMsR0FBWixDQUFnQixPQUFoQixDQURIO0FBRUxlLFFBQUFBLEdBQUcsRUFBRWdDO0FBRkEsT0FGRztBQU1WbkMsTUFBQUEsTUFBTSxFQUFFb0M7QUFORSxLQUFaO0FBUUEsV0FBTyxFQUFQO0FBQ0Q7O0FBRU1FLEVBQUFBLElBQVAsR0FBYyxDQUFHOztBQTVHNEQiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogTGljZW5zZWQgdG8gRWxhc3RpY3NlYXJjaCBCLlYuIHVuZGVyIG9uZSBvciBtb3JlIGNvbnRyaWJ1dG9yXG4gKiBsaWNlbnNlIGFncmVlbWVudHMuIFNlZSB0aGUgTk9USUNFIGZpbGUgZGlzdHJpYnV0ZWQgd2l0aFxuICogdGhpcyB3b3JrIGZvciBhZGRpdGlvbmFsIGluZm9ybWF0aW9uIHJlZ2FyZGluZyBjb3B5cmlnaHRcbiAqIG93bmVyc2hpcC4gRWxhc3RpY3NlYXJjaCBCLlYuIGxpY2Vuc2VzIHRoaXMgZmlsZSB0byB5b3UgdW5kZXJcbiAqIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7IHlvdSBtYXlcbiAqIG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsXG4gKiBzb2Z0d2FyZSBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhblxuICogXCJBUyBJU1wiIEJBU0lTLCBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTllcbiAqIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuICBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZVxuICogc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZCBsaW1pdGF0aW9uc1xuICogdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHtcbiAgQ29yZVNldHVwLFxuICBDb3JlU3RhcnQsXG4gIExvZ2dlcixcbiAgUGx1Z2luLFxuICBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQsXG4gIFNoYXJlZEdsb2JhbENvbmZpZyxcbn0gZnJvbSAnb3BlbnNlYXJjaF9kYXNoYm9hcmRzL3NlcnZlcic7XG5cbmltcG9ydCB7IFdhenVoUGx1Z2luU2V0dXAsIFdhenVoUGx1Z2luU3RhcnQsIFBsdWdpblNldHVwIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBTZWN1cml0eU9iaiwgSVNlY3VyaXR5RmFjdG9yeSB9IGZyb20gJy4vbGliL3NlY3VyaXR5LWZhY3RvcnknO1xuaW1wb3J0IHsgc2V0dXBSb3V0ZXMgfSBmcm9tICcuL3JvdXRlcyc7XG5pbXBvcnQgeyBqb2JJbml0aWFsaXplUnVuLCBqb2JNb25pdG9yaW5nUnVuLCBqb2JTY2hlZHVsZXJSdW4sIGpvYlF1ZXVlUnVuIH0gZnJvbSAnLi9zdGFydCc7XG5pbXBvcnQgeyBnZXRDb29raWVWYWx1ZUJ5TmFtZSB9IGZyb20gJy4vbGliL2Nvb2tpZSc7XG5pbXBvcnQgKiBhcyBBcGlJbnRlcmNlcHRvciAgZnJvbSAnLi9saWIvYXBpLWludGVyY2VwdG9yJztcbmltcG9ydCB7IHNjaGVtYSwgVHlwZU9mIH0gZnJvbSAnQG9zZC9jb25maWctc2NoZW1hJztcbmltcG9ydCB0eXBlIHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgZmlyc3QgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5cbmRlY2xhcmUgbW9kdWxlICdvcGVuc2VhcmNoX2Rhc2hib2FyZHMvc2VydmVyJyB7XG4gIGludGVyZmFjZSBSZXF1ZXN0SGFuZGxlckNvbnRleHQge1xuICAgIHdhenVoOiB7XG4gICAgICBsb2dnZXI6IExvZ2dlcixcbiAgICAgIHBsdWdpbnM6IFBsdWdpblNldHVwLFxuICAgICAgc2VjdXJpdHk6IElTZWN1cml0eUZhY3RvcnlcbiAgICAgIGFwaToge1xuICAgICAgICBjbGllbnQ6IHtcbiAgICAgICAgICBhc0ludGVybmFsVXNlcjoge1xuICAgICAgICAgICAgYXV0aGVudGljYXRlOiAoYXBpSG9zdElEOiBzdHJpbmcpID0+IFByb21pc2U8c3RyaW5nPlxuICAgICAgICAgICAgcmVxdWVzdDogKG1ldGhvZDogc3RyaW5nLCBwYXRoOiBzdHJpbmcsIGRhdGE6IGFueSwgb3B0aW9uczoge2FwaUhvc3RJRDogc3RyaW5nLCBmb3JjZVJlZnJlc2g/OmJvb2xlYW59KSA9PiBQcm9taXNlPGFueT5cbiAgICAgICAgICB9LFxuICAgICAgICAgIGFzQ3VycmVudFVzZXI6IHtcbiAgICAgICAgICAgIGF1dGhlbnRpY2F0ZTogKGFwaUhvc3RJRDogc3RyaW5nKSA9PiBQcm9taXNlPHN0cmluZz5cbiAgICAgICAgICAgIHJlcXVlc3Q6IChtZXRob2Q6IHN0cmluZywgcGF0aDogc3RyaW5nLCBkYXRhOiBhbnksIG9wdGlvbnM6IHthcGlIb3N0SUQ6IHN0cmluZywgZm9yY2VSZWZyZXNoPzpib29sZWFufSkgPT4gUHJvbWlzZTxhbnk+XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgV2F6dWhQbHVnaW4gaW1wbGVtZW50cyBQbHVnaW48V2F6dWhQbHVnaW5TZXR1cCwgV2F6dWhQbHVnaW5TdGFydD4ge1xuICBwcml2YXRlIHJlYWRvbmx5IGxvZ2dlcjogTG9nZ2VyO1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcbiAgICB0aGlzLmxvZ2dlciA9IGluaXRpYWxpemVyQ29udGV4dC5sb2dnZXIuZ2V0KCk7XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgc2V0dXAoY29yZTogQ29yZVNldHVwLCBwbHVnaW5zOiBQbHVnaW5TZXR1cCkge1xuICAgIHRoaXMubG9nZ2VyLmRlYnVnKCdXYXp1aC13dWk6IFNldHVwJyk7XG5cbiAgICBjb25zdCB3YXp1aFNlY3VyaXR5ID0gYXdhaXQgU2VjdXJpdHlPYmoocGx1Z2lucyk7XG4gICAgY29uc3Qgc2VydmVySW5mbyA9IGNvcmUuaHR0cC5nZXRTZXJ2ZXJJbmZvKCk7XG5cbiAgICBjb3JlLmh0dHAucmVnaXN0ZXJSb3V0ZUhhbmRsZXJDb250ZXh0KCd3YXp1aCcsIChjb250ZXh0LCByZXF1ZXN0KSA9PiB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsb2dnZXI6IHRoaXMubG9nZ2VyLFxuICAgICAgICBzZXJ2ZXI6IHtcbiAgICAgICAgICBpbmZvOiBzZXJ2ZXJJbmZvLFxuICAgICAgICB9LFxuICAgICAgICBwbHVnaW5zLFxuICAgICAgICBzZWN1cml0eTogd2F6dWhTZWN1cml0eSxcbiAgICAgICAgYXBpOiB7XG4gICAgICAgICAgY2xpZW50OiB7XG4gICAgICAgICAgICBhc0ludGVybmFsVXNlcjoge1xuICAgICAgICAgICAgICBhdXRoZW50aWNhdGU6IGFzeW5jIChhcGlIb3N0SUQpID0+IGF3YWl0IEFwaUludGVyY2VwdG9yLmF1dGhlbnRpY2F0ZShhcGlIb3N0SUQpLFxuICAgICAgICAgICAgICByZXF1ZXN0OiBhc3luYyAobWV0aG9kLCBwYXRoLCBkYXRhLCBvcHRpb25zKSA9PiBhd2FpdCBBcGlJbnRlcmNlcHRvci5yZXF1ZXN0QXNJbnRlcm5hbFVzZXIobWV0aG9kLCBwYXRoLCBkYXRhLCBvcHRpb25zKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBhc0N1cnJlbnRVc2VyOiB7XG4gICAgICAgICAgICAgIGF1dGhlbnRpY2F0ZTogYXN5bmMgKGFwaUhvc3RJRCkgPT4gYXdhaXQgQXBpSW50ZXJjZXB0b3IuYXV0aGVudGljYXRlKGFwaUhvc3RJRCwgKGF3YWl0IHdhenVoU2VjdXJpdHkuZ2V0Q3VycmVudFVzZXIocmVxdWVzdCwgY29udGV4dCkpLmF1dGhDb250ZXh0KSxcbiAgICAgICAgICAgICAgcmVxdWVzdDogYXN5bmMgKG1ldGhvZCwgcGF0aCwgZGF0YSwgb3B0aW9ucykgPT4gYXdhaXQgQXBpSW50ZXJjZXB0b3IucmVxdWVzdEFzQ3VycmVudFVzZXIobWV0aG9kLCBwYXRoLCBkYXRhLCB7Li4ub3B0aW9ucywgdG9rZW46IGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsICd3ei10b2tlbicpfSksXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgLy8gQWRkIGN1c3RvbSBoZWFkZXJzIHRvIHRoZSByZXNwb25zZXNcbiAgICBjb3JlLmh0dHAucmVnaXN0ZXJPblByZVJlc3BvbnNlKChyZXF1ZXN0LCByZXNwb25zZSwgdG9vbGtpdCkgPT4ge1xuICAgICAgY29uc3QgYWRkaXRpb25hbEhlYWRlcnMgPSB7XG4gICAgICAgICd4LWZyYW1lLW9wdGlvbnMnOiAnc2FtZW9yaWdpbicsXG4gICAgICB9O1xuICAgICAgcmV0dXJuIHRvb2xraXQubmV4dCh7IGhlYWRlcnM6IGFkZGl0aW9uYWxIZWFkZXJzIH0pO1xuICAgIH0pO1xuXG4gICAgLy8gUm91dGVzXG4gICAgY29uc3Qgcm91dGVyID0gY29yZS5odHRwLmNyZWF0ZVJvdXRlcigpO1xuICAgIHNldHVwUm91dGVzKHJvdXRlcik7XG5cbiAgICByZXR1cm4ge307XG4gIH1cblxuICBwdWJsaWMgYXN5bmMgc3RhcnQoY29yZTogQ29yZVN0YXJ0KSB7XG4gICAgY29uc3QgZ2xvYmFsQ29uZmlndXJhdGlvbjogU2hhcmVkR2xvYmFsQ29uZmlnID0gYXdhaXQgdGhpcy5pbml0aWFsaXplckNvbnRleHQuY29uZmlnLmxlZ2FjeS5nbG9iYWxDb25maWckLnBpcGUoZmlyc3QoKSkudG9Qcm9taXNlKCk7XG4gICAgY29uc3Qgd2F6dWhBcGlDbGllbnQgPSB7XG4gICAgICBjbGllbnQ6IHtcbiAgICAgICAgYXNJbnRlcm5hbFVzZXI6IHtcbiAgICAgICAgICBhdXRoZW50aWNhdGU6IGFzeW5jIChhcGlIb3N0SUQpID0+IGF3YWl0IEFwaUludGVyY2VwdG9yLmF1dGhlbnRpY2F0ZShhcGlIb3N0SUQpLFxuICAgICAgICAgIHJlcXVlc3Q6IGFzeW5jIChtZXRob2QsIHBhdGgsIGRhdGEsIG9wdGlvbnMpID0+IGF3YWl0IEFwaUludGVyY2VwdG9yLnJlcXVlc3RBc0ludGVybmFsVXNlcihtZXRob2QsIHBhdGgsIGRhdGEsIG9wdGlvbnMpLFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcblxuICAgIGNvbnN0IGNvbnRleHRTZXJ2ZXIgPSB7XG4gICAgICBjb25maWc6IGdsb2JhbENvbmZpZ3VyYXRpb25cbiAgICB9O1xuXG4gICAgLy8gSW5pdGlhbGl6ZVxuICAgIGpvYkluaXRpYWxpemVSdW4oe1xuICAgICAgY29yZSxcbiAgICAgIHdhenVoOiB7XG4gICAgICAgIGxvZ2dlcjogdGhpcy5sb2dnZXIuZ2V0KCdpbml0aWFsaXplJyksXG4gICAgICAgIGFwaTogd2F6dWhBcGlDbGllbnRcbiAgICAgIH0sXG4gICAgICBzZXJ2ZXI6IGNvbnRleHRTZXJ2ZXJcbiAgICB9KTtcblxuICAgIC8vIE1vbml0b3JpbmdcbiAgICBqb2JNb25pdG9yaW5nUnVuKHtcbiAgICAgIGNvcmUsXG4gICAgICB3YXp1aDoge1xuICAgICAgICBsb2dnZXI6IHRoaXMubG9nZ2VyLmdldCgnbW9uaXRvcmluZycpLFxuICAgICAgICBhcGk6IHdhenVoQXBpQ2xpZW50XG4gICAgICB9LFxuICAgICAgc2VydmVyOiBjb250ZXh0U2VydmVyXG4gICAgfSk7XG5cbiAgICAvLyBTY2hlZHVsZXJcbiAgICBqb2JTY2hlZHVsZXJSdW4oe1xuICAgICAgY29yZSxcbiAgICAgIHdhenVoOiB7XG4gICAgICAgIGxvZ2dlcjogdGhpcy5sb2dnZXIuZ2V0KCdjcm9uLXNjaGVkdWxlcicpLFxuICAgICAgICBhcGk6IHdhenVoQXBpQ2xpZW50XG4gICAgICB9LFxuICAgICAgc2VydmVyOiBjb250ZXh0U2VydmVyXG4gICAgfSk7XG5cbiAgICAvLyBRdWV1ZVxuICAgIGpvYlF1ZXVlUnVuKHtcbiAgICAgIGNvcmUsXG4gICAgICB3YXp1aDoge1xuICAgICAgICBsb2dnZXI6IHRoaXMubG9nZ2VyLmdldCgncXVldWUnKSxcbiAgICAgICAgYXBpOiB3YXp1aEFwaUNsaWVudFxuICAgICAgfSxcbiAgICAgIHNlcnZlcjogY29udGV4dFNlcnZlclxuICAgIH0pO1xuICAgIHJldHVybiB7fTtcbiAgfVxuXG4gIHB1YmxpYyBzdG9wKCkgeyB9XG59XG4iXX0=