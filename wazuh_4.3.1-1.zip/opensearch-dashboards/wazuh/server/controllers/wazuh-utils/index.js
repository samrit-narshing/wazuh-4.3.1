"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _wazuhUtils = require("./wazuh-utils");

Object.keys(_wazuhUtils).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _wazuhUtils[key];
    }
  });
});

var _uiLogs = require("./ui-logs.controller");

Object.keys(_uiLogs).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _uiLogs[key];
    }
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFDQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgKiBmcm9tICcuL3dhenVoLXV0aWxzJztcbmV4cG9ydCAqIGZyb20gJy4vdWktbG9ncy5jb250cm9sbGVyJztcbiJdfQ==