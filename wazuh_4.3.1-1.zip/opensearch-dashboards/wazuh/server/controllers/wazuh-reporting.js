"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhReportingCtrl = void 0;

var _path = _interopRequireDefault(require("path"));

var _fs = _interopRequireDefault(require("fs"));

var _wazuhModules = require("../../common/wazuh-modules");

var TimSort = _interopRequireWildcard(require("timsort"));

var _errorResponse = require("../lib/error-response");

var VulnerabilityRequest = _interopRequireWildcard(require("../lib/reporting/vulnerability-request"));

var OverviewRequest = _interopRequireWildcard(require("../lib/reporting/overview-request"));

var RootcheckRequest = _interopRequireWildcard(require("../lib/reporting/rootcheck-request"));

var PCIRequest = _interopRequireWildcard(require("../lib/reporting/pci-request"));

var GDPRRequest = _interopRequireWildcard(require("../lib/reporting/gdpr-request"));

var TSCRequest = _interopRequireWildcard(require("../lib/reporting/tsc-request"));

var AuditRequest = _interopRequireWildcard(require("../lib/reporting/audit-request"));

var SyscheckRequest = _interopRequireWildcard(require("../lib/reporting/syscheck-request"));

var _pciRequirementsPdfmake = _interopRequireDefault(require("../integration-files/pci-requirements-pdfmake"));

var _gdprRequirementsPdfmake = _interopRequireDefault(require("../integration-files/gdpr-requirements-pdfmake"));

var _tscRequirementsPdfmake = _interopRequireDefault(require("../integration-files/tsc-requirements-pdfmake"));

var _processStateEquivalence = _interopRequireDefault(require("../lib/process-state-equivalence"));

var _csvKeyEquivalence = require("../../common/csv-key-equivalence");

var _agentConfiguration = require("../lib/reporting/agent-configuration");

var _printer = require("../lib/reporting/printer");

var _logger = require("../lib/logger");

var _constants = require("../../common/constants");

var _filesystem = require("../lib/filesystem");

var _moment = _interopRequireDefault(require("moment"));

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function () { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
 * Wazuh app - Class for Wazuh reporting controller
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
class WazuhReportingCtrl {
  constructor() {}
  /**
   * This do format to filters
   * @param {String} filters E.g: cluster.name: wazuh AND rule.groups: vulnerability
   * @param {String} searchBar search term
   */


  sanitizeKibanaFilters(filters, searchBar) {
    (0, _logger.log)('reporting:sanitizeKibanaFilters', `Started to sanitize filters`, 'info');
    (0, _logger.log)('reporting:sanitizeKibanaFilters', `filters: ${filters.length}, searchBar: ${searchBar}`, 'debug');
    let str = '';
    const agentsFilter = []; //separate agents filter

    filters = filters.filter(filter => {
      if (filter.meta.controlledBy === _constants.AUTHORIZED_AGENTS) {
        agentsFilter.push(filter);
        return false;
      }

      return filter;
    });
    const len = filters.length;

    for (let i = 0; i < len; i++) {
      const {
        negate,
        key,
        value,
        params,
        type
      } = filters[i].meta;
      str += `${negate ? 'NOT ' : ''}`;
      str += `${key}: `;
      str += `${type === 'range' ? `${params.gte}-${params.lt}` : type === 'phrases' ? '(' + params.join(" OR ") + ')' : type === 'exists' ? '*' : !!value ? value : (params || {}).query}`;
      str += `${i === len - 1 ? '' : ' AND '}`;
    }

    if (searchBar) {
      str += ` AND (${searchBar})`;
    }

    const agentsFilterStr = agentsFilter.map(filter => filter.meta.value).join(',');
    (0, _logger.log)('reporting:sanitizeKibanaFilters', `str: ${str}, agentsFilterStr: ${agentsFilterStr}`, 'debug');
    return [str, agentsFilterStr];
  }
  /**
   * This performs the rendering of given header
   * @param {String} printer section target
   * @param {String} section section target
   * @param {Object} tab tab target
   * @param {Boolean} isAgents is agents section
   * @param {String} apiId ID of API
   */


  async renderHeader(context, printer, section, tab, isAgents, apiId) {
    try {
      (0, _logger.log)('reporting:renderHeader', `section: ${section}, tab: ${tab}, isAgents: ${isAgents}, apiId: ${apiId}`, 'debug');

      if (section && typeof section === 'string') {
        if (!['agentConfig', 'groupConfig'].includes(section)) {
          printer.addContent({
            text: _wazuhModules.WAZUH_MODULES[tab].title + ' report',
            style: 'h1'
          });
        } else if (section === 'agentConfig') {
          printer.addContent({
            text: `Agent ${isAgents} configuration`,
            style: 'h1'
          });
        } else if (section === 'groupConfig') {
          printer.addContent({
            text: 'Agents in group',
            style: {
              fontSize: 14,
              color: '#000'
            },
            margin: [0, 20, 0, 0]
          });

          if (section === 'groupConfig' && !Object.keys(isAgents).length) {
            printer.addContent({
              text: 'There are still no agents in this group.',
              style: {
                fontSize: 12,
                color: '#000'
              },
              margin: [0, 10, 0, 0]
            });
          }
        }

        printer.addNewLine();
      }

      if (isAgents && typeof isAgents === 'object') {
        await this.buildAgentsTable(context, printer, isAgents, apiId, section === 'groupConfig' ? tab : false);
      }

      if (isAgents && typeof isAgents === 'string') {
        const agentResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents`, {
          params: {
            agents_list: isAgents
          }
        }, {
          apiHostID: apiId
        });
        const agentData = agentResponse.data.data.affected_items[0];

        if (agentData && agentData.status !== 'active') {
          printer.addContentWithNewLine({
            text: `Warning. Agent is ${agentData.status.toLowerCase()}`,
            style: 'standard'
          });
        }

        await this.buildAgentsTable(context, printer, [isAgents], apiId);

        if (agentData && agentData.group) {
          const agentGroups = agentData.group.join(', ');
          printer.addContentWithNewLine({
            text: `Group${agentData.group.length > 1 ? 's' : ''}: ${agentGroups}`,
            style: 'standard'
          });
        }
      }

      if (_wazuhModules.WAZUH_MODULES[tab] && _wazuhModules.WAZUH_MODULES[tab].description) {
        printer.addContentWithNewLine({
          text: _wazuhModules.WAZUH_MODULES[tab].description,
          style: 'standard'
        });
      }

      return;
    } catch (error) {
      (0, _logger.log)('reporting:renderHeader', error.message || error);
      return Promise.reject(error);
    }
  }
  /**
   * This build the agents table
   * @param {Array<Strings>} ids ids of agents
   * @param {String} apiId API id
   */


  async buildAgentsTable(context, printer, agentIDs, apiId, multi = false) {
    const dateFormat = await context.core.uiSettings.client.get('dateFormat');
    if (!agentIDs || !agentIDs.length) return;
    (0, _logger.log)('reporting:buildAgentsTable', `${agentIDs.length} agents for API ${apiId}`, 'info');

    try {
      let agentRows = [];

      if (multi) {
        try {
          const agentsResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/groups/${multi}/agents`, {}, {
            apiHostID: apiId
          });
          const agentsData = agentsResponse && agentsResponse.data && agentsResponse.data.data && agentsResponse.data.data.affected_items;
          agentRows = (agentsData || []).map(agent => ({ ...agent,
            manager: agent.manager || agent.manager_host,
            os: agent.os && agent.os.name && agent.os.version ? `${agent.os.name} ${agent.os.version}` : ''
          }));
        } catch (error) {
          (0, _logger.log)('reporting:buildAgentsTable', `Skip agent due to: ${error.message || error}`, 'debug');
        }
      } else {
        for (const agentID of agentIDs) {
          try {
            const agentResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents`, {
              params: {
                q: `id=${agentID}`
              }
            }, {
              apiHostID: apiId
            });
            const [agent] = agentResponse.data.data.affected_items;
            agentRows.push({ ...agent,
              manager: agent.manager || agent.manager_host,
              os: agent.os && agent.os.name && agent.os.version ? `${agent.os.name} ${agent.os.version}` : '',
              lastKeepAlive: (0, _moment.default)(agent.lastKeepAlive).format(dateFormat),
              dateAdd: (0, _moment.default)(agent.dateAdd).format(dateFormat)
            });
          } catch (error) {
            (0, _logger.log)('reporting:buildAgentsTable', `Skip agent due to: ${error.message || error}`, 'debug');
          }
        }
      }

      printer.addSimpleTable({
        columns: [{
          id: 'id',
          label: 'ID'
        }, {
          id: 'name',
          label: 'Name'
        }, {
          id: 'ip',
          label: 'IP'
        }, {
          id: 'version',
          label: 'Version'
        }, {
          id: 'manager',
          label: 'Manager'
        }, {
          id: 'os',
          label: 'OS'
        }, {
          id: 'dateAdd',
          label: 'Registration date'
        }, {
          id: 'lastKeepAlive',
          label: 'Last keep alive'
        }],
        items: agentRows
      });
    } catch (error) {
      (0, _logger.log)('reporting:buildAgentsTable', error.message || error);
      return Promise.reject(error);
    }
  }
  /**
   * This load more information
   * @param {*} context Endpoint context
   * @param {*} printer printer instance
   * @param {String} section section target
   * @param {Object} tab tab target
   * @param {String} apiId ID of API
   * @param {Number} from Timestamp (ms) from
   * @param {Number} to Timestamp (ms) to
   * @param {String} filters E.g: cluster.name: wazuh AND rule.groups: vulnerability
   * @param {String} pattern
   * @param {Object} agent agent target
   * @returns {Object} Extended information
   */


  async extendedInformation(context, printer, section, tab, apiId, from, to, filters, pattern = _constants.WAZUH_ALERTS_PATTERN, agent = null) {
    try {
      (0, _logger.log)('reporting:extendedInformation', `Section ${section} and tab ${tab}, API is ${apiId}. From ${from} to ${to}. Filters ${filters}. Index pattern ${pattern}`, 'info');

      if (section === 'agents' && !agent) {
        throw new Error('Reporting for specific agent needs an agent ID in order to work properly');
      }

      const agents = await context.wazuh.api.client.asCurrentUser.request('GET', '/agents', {
        params: {
          limit: 1
        }
      }, {
        apiHostID: apiId
      });
      const totalAgents = agents.data.data.total_affected_items;

      if (section === 'overview' && tab === 'vuls') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching overview vulnerability detector metrics', 'debug');
        const vulnerabilitiesLevels = ['Low', 'Medium', 'High', 'Critical'];
        const vulnerabilitiesResponsesCount = (await Promise.all(vulnerabilitiesLevels.map(async vulnerabilitiesLevel => {
          try {
            const count = await VulnerabilityRequest.uniqueSeverityCount(context, from, to, vulnerabilitiesLevel, filters, pattern);
            return count ? `${count} of ${totalAgents} agents have ${vulnerabilitiesLevel.toLocaleLowerCase()} vulnerabilities.` : undefined;
          } catch (error) {}
        }))).filter(vulnerabilitiesResponse => vulnerabilitiesResponse);
        printer.addList({
          title: {
            text: 'Summary',
            style: 'h2'
          },
          list: vulnerabilitiesResponsesCount
        });
        (0, _logger.log)('reporting:extendedInformation', 'Fetching overview vulnerability detector top 3 agents by category', 'debug');
        const lowRank = await VulnerabilityRequest.topAgentCount(context, from, to, 'Low', filters, pattern);
        const mediumRank = await VulnerabilityRequest.topAgentCount(context, from, to, 'Medium', filters, pattern);
        const highRank = await VulnerabilityRequest.topAgentCount(context, from, to, 'High', filters, pattern);
        const criticalRank = await VulnerabilityRequest.topAgentCount(context, from, to, 'Critical', filters, pattern);
        (0, _logger.log)('reporting:extendedInformation', 'Adding overview vulnerability detector top 3 agents by category', 'debug');

        if (criticalRank && criticalRank.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 agents with critical severity vulnerabilities',
            style: 'h3'
          });
          await this.buildAgentsTable(context, printer, criticalRank, apiId);
          printer.addNewLine();
        }

        if (highRank && highRank.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 agents with high severity vulnerabilities',
            style: 'h3'
          });
          await this.buildAgentsTable(context, printer, highRank, apiId);
          printer.addNewLine();
        }

        if (mediumRank && mediumRank.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 agents with medium severity vulnerabilities',
            style: 'h3'
          });
          await this.buildAgentsTable(context, printer, mediumRank, apiId);
          printer.addNewLine();
        }

        if (lowRank && lowRank.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 agents with low severity vulnerabilities',
            style: 'h3'
          });
          await this.buildAgentsTable(context, printer, lowRank, apiId);
          printer.addNewLine();
        }

        (0, _logger.log)('reporting:extendedInformation', 'Fetching overview vulnerability detector top 3 CVEs', 'debug');
        const cveRank = await VulnerabilityRequest.topCVECount(context, from, to, filters, pattern);
        (0, _logger.log)('reporting:extendedInformation', 'Adding overview vulnerability detector top 3 CVEs', 'debug');

        if (cveRank && cveRank.length) {
          printer.addSimpleTable({
            title: {
              text: 'Top 3 CVE',
              style: 'h2'
            },
            columns: [{
              id: 'top',
              label: 'Top'
            }, {
              id: 'cve',
              label: 'CVE'
            }],
            items: cveRank.map(item => ({
              top: cveRank.indexOf(item) + 1,
              cve: item
            }))
          });
        }
      }

      if (section === 'overview' && tab === 'general') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top 3 agents with level 15 alerts', 'debug');
        const level15Rank = await OverviewRequest.topLevel15(context, from, to, filters, pattern);
        (0, _logger.log)('reporting:extendedInformation', 'Adding top 3 agents with level 15 alerts', 'debug');

        if (level15Rank.length) {
          printer.addContent({
            text: 'Top 3 agents with level 15 alerts',
            style: 'h2'
          });
          await this.buildAgentsTable(context, printer, level15Rank, apiId);
        }
      }

      if (section === 'overview' && tab === 'pm') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching most common rootkits', 'debug');
        const top5RootkitsRank = await RootcheckRequest.top5RootkitsDetected(context, from, to, filters, pattern);
        (0, _logger.log)('reporting:extendedInformation', 'Adding most common rootkits', 'debug');

        if (top5RootkitsRank && top5RootkitsRank.length) {
          printer.addContentWithNewLine({
            text: 'Most common rootkits found among your agents',
            style: 'h2'
          }).addContentWithNewLine({
            text: 'Rootkits are a set of software tools that enable an unauthorized user to gain control of a computer system without being detected.',
            style: 'standard'
          }).addSimpleTable({
            items: top5RootkitsRank.map(item => {
              return {
                top: top5RootkitsRank.indexOf(item) + 1,
                name: item
              };
            }),
            columns: [{
              id: 'top',
              label: 'Top'
            }, {
              id: 'name',
              label: 'Rootkit'
            }]
          });
        }

        (0, _logger.log)('reporting:extendedInformation', 'Fetching hidden pids', 'debug');
        const hiddenPids = await RootcheckRequest.agentsWithHiddenPids(context, from, to, filters, pattern);
        hiddenPids && printer.addContent({
          text: `${hiddenPids} of ${totalAgents} agents have hidden processes`,
          style: 'h3'
        });
        !hiddenPids && printer.addContentWithNewLine({
          text: `No agents have hidden processes`,
          style: 'h3'
        });
        const hiddenPorts = await RootcheckRequest.agentsWithHiddenPorts(context, from, to, filters, pattern);
        hiddenPorts && printer.addContent({
          text: `${hiddenPorts} of ${totalAgents} agents have hidden ports`,
          style: 'h3'
        });
        !hiddenPorts && printer.addContent({
          text: `No agents have hidden ports`,
          style: 'h3'
        });
        printer.addNewLine();
      }

      if (['overview', 'agents'].includes(section) && tab === 'pci') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top PCI DSS requirements', 'debug');
        const topPciRequirements = await PCIRequest.topPCIRequirements(context, from, to, filters, pattern);
        printer.addContentWithNewLine({
          text: 'Most common PCI DSS requirements alerts found',
          style: 'h2'
        });

        for (const item of topPciRequirements) {
          const rules = await PCIRequest.getRulesByRequirement(context, from, to, filters, item, pattern);
          printer.addContentWithNewLine({
            text: `Requirement ${item}`,
            style: 'h3'
          });

          if (_pciRequirementsPdfmake.default[item]) {
            const content = typeof _pciRequirementsPdfmake.default[item] === 'string' ? {
              text: _pciRequirementsPdfmake.default[item],
              style: 'standard'
            } : _pciRequirementsPdfmake.default[item];
            printer.addContentWithNewLine(content);
          }

          rules && rules.length && printer.addSimpleTable({
            columns: [{
              id: 'ruleID',
              label: 'Rule ID'
            }, {
              id: 'ruleDescription',
              label: 'Description'
            }],
            items: rules,
            title: `Top rules for ${item} requirement`
          });
        }
      }

      if (['overview', 'agents'].includes(section) && tab === 'tsc') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top TSC requirements', 'debug');
        const topTSCRequirements = await TSCRequest.topTSCRequirements(context, from, to, filters, pattern);
        printer.addContentWithNewLine({
          text: 'Most common TSC requirements alerts found',
          style: 'h2'
        });

        for (const item of topTSCRequirements) {
          const rules = await TSCRequest.getRulesByRequirement(context, from, to, filters, item, pattern);
          printer.addContentWithNewLine({
            text: `Requirement ${item}`,
            style: 'h3'
          });

          if (_tscRequirementsPdfmake.default[item]) {
            const content = typeof _tscRequirementsPdfmake.default[item] === 'string' ? {
              text: _tscRequirementsPdfmake.default[item],
              style: 'standard'
            } : _tscRequirementsPdfmake.default[item];
            printer.addContentWithNewLine(content);
          }

          rules && rules.length && printer.addSimpleTable({
            columns: [{
              id: 'ruleID',
              label: 'Rule ID'
            }, {
              id: 'ruleDescription',
              label: 'Description'
            }],
            items: rules,
            title: `Top rules for ${item} requirement`
          });
        }
      }

      if (['overview', 'agents'].includes(section) && tab === 'gdpr') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top GDPR requirements', 'debug');
        const topGdprRequirements = await GDPRRequest.topGDPRRequirements(context, from, to, filters, pattern);
        printer.addContentWithNewLine({
          text: 'Most common GDPR requirements alerts found',
          style: 'h2'
        });

        for (const item of topGdprRequirements) {
          const rules = await GDPRRequest.getRulesByRequirement(context, from, to, filters, item, pattern);
          printer.addContentWithNewLine({
            text: `Requirement ${item}`,
            style: 'h3'
          });

          if (_gdprRequirementsPdfmake.default && _gdprRequirementsPdfmake.default[item]) {
            const content = typeof _gdprRequirementsPdfmake.default[item] === 'string' ? {
              text: _gdprRequirementsPdfmake.default[item],
              style: 'standard'
            } : _gdprRequirementsPdfmake.default[item];
            printer.addContentWithNewLine(content);
          }

          rules && rules.length && printer.addSimpleTable({
            columns: [{
              id: 'ruleID',
              label: 'Rule ID'
            }, {
              id: 'ruleDescription',
              label: 'Description'
            }],
            items: rules,
            title: `Top rules for ${item} requirement`
          });
        }

        printer.addNewLine();
      }

      if (section === 'overview' && tab === 'audit') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching agents with high number of failed sudo commands', 'debug');
        const auditAgentsNonSuccess = await AuditRequest.getTop3AgentsSudoNonSuccessful(context, from, to, filters, pattern);

        if (auditAgentsNonSuccess && auditAgentsNonSuccess.length) {
          printer.addContent({
            text: 'Agents with high number of failed sudo commands',
            style: 'h2'
          });
          await this.buildAgentsTable(context, printer, auditAgentsNonSuccess, apiId);
        }

        const auditAgentsFailedSyscall = await AuditRequest.getTop3AgentsFailedSyscalls(context, from, to, filters, pattern);

        if (auditAgentsFailedSyscall && auditAgentsFailedSyscall.length) {
          printer.addSimpleTable({
            columns: [{
              id: 'agent',
              label: 'Agent ID'
            }, {
              id: 'syscall_id',
              label: 'Syscall ID'
            }, {
              id: 'syscall_syscall',
              label: 'Syscall'
            }],
            items: auditAgentsFailedSyscall.map(item => ({
              agent: item.agent,
              syscall_id: item.syscall.id,
              syscall_syscall: item.syscall.syscall
            })),
            title: {
              text: 'Most common failing syscalls',
              style: 'h2'
            }
          });
        }
      }

      if (section === 'overview' && tab === 'fim') {
        (0, _logger.log)('reporting:extendedInformation', 'Fetching top 3 rules for FIM', 'debug');
        const rules = await SyscheckRequest.top3Rules(context, from, to, filters, pattern);

        if (rules && rules.length) {
          printer.addContentWithNewLine({
            text: 'Top 3 FIM rules',
            style: 'h2'
          }).addSimpleTable({
            columns: [{
              id: 'ruleID',
              label: 'Rule ID'
            }, {
              id: 'ruleDescription',
              label: 'Description'
            }],
            items: rules,
            title: {
              text: 'Top 3 rules that are generating most alerts.',
              style: 'standard'
            }
          });
        }

        (0, _logger.log)('reporting:extendedInformation', 'Fetching top 3 agents for FIM', 'debug');
        const agents = await SyscheckRequest.top3agents(context, from, to, filters, pattern);

        if (agents && agents.length) {
          printer.addContentWithNewLine({
            text: 'Agents with suspicious FIM activity',
            style: 'h2'
          });
          printer.addContentWithNewLine({
            text: 'Top 3 agents that have most FIM alerts from level 7 to level 15. Take care about them.',
            style: 'standard'
          });
          await this.buildAgentsTable(context, printer, agents, apiId);
        }
      }

      if (section === 'agents' && tab === 'audit') {
        (0, _logger.log)('reporting:extendedInformation', `Fetching most common failed syscalls`, 'debug');
        const auditFailedSyscall = await AuditRequest.getTopFailedSyscalls(context, from, to, filters, pattern);
        auditFailedSyscall && auditFailedSyscall.length && printer.addSimpleTable({
          columns: [{
            id: 'id',
            label: 'id'
          }, {
            id: 'syscall',
            label: 'Syscall'
          }],
          items: auditFailedSyscall,
          title: 'Most common failing syscalls'
        });
      }

      if (section === 'agents' && tab === 'fim') {
        (0, _logger.log)('reporting:extendedInformation', `Fetching syscheck database for agent ${agent}`, 'debug');
        const lastScanResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/syscheck/${agent}/last_scan`, {}, {
          apiHostID: apiId
        });

        if (lastScanResponse && lastScanResponse.data) {
          const lastScanData = lastScanResponse.data.data.affected_items[0];

          if (lastScanData.start && lastScanData.end) {
            printer.addContent({
              text: `Last file integrity monitoring scan was executed from ${lastScanData.start} to ${lastScanData.end}.`
            });
          } else if (lastScanData.start) {
            printer.addContent({
              text: `File integrity monitoring scan is currently in progress for this agent (started on ${lastScanData.start}).`
            });
          } else {
            printer.addContent({
              text: `File integrity monitoring scan is currently in progress for this agent.`
            });
          }

          printer.addNewLine();
        }

        (0, _logger.log)('reporting:extendedInformation', `Fetching last 10 deleted files for FIM`, 'debug');
        const lastTenDeleted = await SyscheckRequest.lastTenDeletedFiles(context, from, to, filters, pattern);
        lastTenDeleted && lastTenDeleted.length && printer.addSimpleTable({
          columns: [{
            id: 'path',
            label: 'Path'
          }, {
            id: 'date',
            label: 'Date'
          }],
          items: lastTenDeleted,
          title: 'Last 10 deleted files'
        });
        (0, _logger.log)('reporting:extendedInformation', `Fetching last 10 modified files`, 'debug');
        const lastTenModified = await SyscheckRequest.lastTenModifiedFiles(context, from, to, filters, pattern);
        lastTenModified && lastTenModified.length && printer.addSimpleTable({
          columns: [{
            id: 'path',
            label: 'Path'
          }, {
            id: 'date',
            label: 'Date'
          }],
          items: lastTenModified,
          title: 'Last 10 modified files'
        });
      }

      if (section === 'agents' && tab === 'syscollector') {
        (0, _logger.log)('reporting:extendedInformation', `Fetching hardware information for agent ${agent}`, 'debug');
        const requestsSyscollectorLists = [{
          endpoint: `/syscollector/${agent}/hardware`,
          loggerMessage: `Fetching Hardware information for agent ${agent}`,
          list: {
            title: {
              text: 'Hardware information',
              style: 'h2'
            }
          },
          mapResponse: hardware => [hardware.cpu && hardware.cpu.cores && `${hardware.cpu.cores} cores`, hardware.cpu && hardware.cpu.name, hardware.ram && hardware.ram.total && `${Number(hardware.ram.total / 1024 / 1024).toFixed(2)}GB RAM`]
        }, {
          endpoint: `/syscollector/${agent}/os`,
          loggerMessage: `Fetching OS information for agent ${agent}`,
          list: {
            title: {
              text: 'OS information',
              style: 'h2'
            }
          },
          mapResponse: osData => [osData.sysname, osData.version, osData.architecture, osData.release, osData.os && osData.os.name && osData.os.version && `${osData.os.name} ${osData.os.version}`]
        }];
        const syscollectorLists = await Promise.all(requestsSyscollectorLists.map(async requestSyscollector => {
          try {
            (0, _logger.log)('reporting:extendedInformation', requestSyscollector.loggerMessage, 'debug');
            const responseSyscollector = await context.wazuh.api.client.asCurrentUser.request('GET', requestSyscollector.endpoint, {}, {
              apiHostID: apiId
            });
            const [data] = responseSyscollector && responseSyscollector.data && responseSyscollector.data.data && responseSyscollector.data.data.affected_items || [];

            if (data) {
              return { ...requestSyscollector.list,
                list: requestSyscollector.mapResponse(data)
              };
            }
          } catch (error) {
            (0, _logger.log)('reporting:extendedInformation', error.message || error);
          }
        }));

        if (syscollectorLists) {
          syscollectorLists.filter(syscollectorList => syscollectorList).forEach(syscollectorList => printer.addList(syscollectorList));
        }

        const vulnerabilitiesRequests = ['Critical', 'High'];
        const vulnerabilitiesResponsesItems = (await Promise.all(vulnerabilitiesRequests.map(async vulnerabilitiesLevel => {
          try {
            (0, _logger.log)('reporting:extendedInformation', `Fetching top ${vulnerabilitiesLevel} packages`, 'debug');
            return await VulnerabilityRequest.topPackages(context, from, to, vulnerabilitiesLevel, filters, pattern);
          } catch (error) {
            (0, _logger.log)('reporting:extendedInformation', error.message || error);
          }
        }))).filter(vulnerabilitiesResponse => vulnerabilitiesResponse).flat();

        if (vulnerabilitiesResponsesItems && vulnerabilitiesResponsesItems.length) {
          printer.addSimpleTable({
            title: {
              text: 'Vulnerable packages found (last 24 hours)',
              style: 'h2'
            },
            columns: [{
              id: 'package',
              label: 'Package'
            }, {
              id: 'severity',
              label: 'Severity'
            }],
            items: vulnerabilitiesResponsesItems
          });
        }
      }

      if (section === 'agents' && tab === 'vuls') {
        const topCriticalPackages = await VulnerabilityRequest.topPackagesWithCVE(context, from, to, 'Critical', filters, pattern);

        if (topCriticalPackages && topCriticalPackages.length) {
          printer.addContentWithNewLine({
            text: 'Critical severity',
            style: 'h2'
          });
          printer.addContentWithNewLine({
            text: 'These vulnerabilties are critical, please review your agent. Click on each link to read more about each found vulnerability.',
            style: 'standard'
          });
          const customul = [];

          for (const critical of topCriticalPackages) {
            customul.push({
              text: critical.package,
              style: 'standard'
            });
            customul.push({
              ul: critical.references.map(item => ({
                text: item.substring(0, 80) + '...',
                link: item,
                color: '#1EA5C8'
              }))
            });
          }

          printer.addContentWithNewLine({
            ul: customul
          });
        }

        const topHighPackages = await VulnerabilityRequest.topPackagesWithCVE(context, from, to, 'High', filters, pattern);

        if (topHighPackages && topHighPackages.length) {
          printer.addContentWithNewLine({
            text: 'High severity',
            style: 'h2'
          });
          printer.addContentWithNewLine({
            text: 'Click on each link to read more about each found vulnerability.',
            style: 'standard'
          });
          const customul = [];

          for (const critical of topHighPackages) {
            customul.push({
              text: critical.package,
              style: 'standard'
            });
            customul.push({
              ul: critical.references.map(item => ({
                text: item,
                color: '#1EA5C8'
              }))
            });
          }

          customul && customul.length && printer.addContent({
            ul: customul
          });
          printer.addNewLine();
        }
      }

      return false;
    } catch (error) {
      (0, _logger.log)('reporting:extendedInformation', error.message || error);
      return Promise.reject(error);
    }
  }

  getConfigRows(data, labels) {
    (0, _logger.log)('reporting:getConfigRows', `Building configuration rows`, 'info');
    const result = [];

    for (let prop in data || []) {
      if (Array.isArray(data[prop])) {
        data[prop].forEach((x, idx) => {
          if (typeof x === 'object') data[prop][idx] = JSON.stringify(x);
        });
      }

      result.push([(labels || {})[prop] || _csvKeyEquivalence.KeyEquivalence[prop] || prop, data[prop] || '-']);
    }

    return result;
  }

  getConfigTables(data, section, tab, array = []) {
    (0, _logger.log)('reporting:getConfigTables', `Building configuration tables`, 'info');
    let plainData = {};
    const nestedData = [];
    const tableData = [];

    if (data.length === 1 && Array.isArray(data)) {
      tableData[section.config[tab].configuration] = data;
    } else {
      for (let key in data) {
        if (typeof data[key] !== 'object' && !Array.isArray(data[key]) || Array.isArray(data[key]) && typeof data[key][0] !== 'object') {
          plainData[key] = Array.isArray(data[key]) && typeof data[key][0] !== 'object' ? data[key].map(x => {
            return typeof x === 'object' ? JSON.stringify(x) : x + '\n';
          }) : data[key];
        } else if (Array.isArray(data[key]) && typeof data[key][0] === 'object') {
          tableData[key] = data[key];
        } else {
          if (section.isGroupConfig && ['pack', 'content'].includes(key)) {
            tableData[key] = [data[key]];
          } else {
            nestedData.push(data[key]);
          }
        }
      }
    }

    array.push({
      title: (section.options || {}).hideHeader ? '' : (section.tabs || [])[tab] || (section.isGroupConfig ? ((section.labels || [])[0] || [])[tab] : ''),
      columns: ['', ''],
      type: 'config',
      rows: this.getConfigRows(plainData, (section.labels || [])[0])
    });

    for (let key in tableData) {
      const columns = Object.keys(tableData[key][0]);
      columns.forEach((col, i) => {
        columns[i] = col[0].toUpperCase() + col.slice(1);
      });
      const rows = tableData[key].map(x => {
        let row = [];

        for (let key in x) {
          row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
            return x + '\n';
          }) : JSON.stringify(x[key]));
        }

        while (row.length < columns.length) {
          row.push('-');
        }

        return row;
      });
      array.push({
        title: ((section.labels || [])[0] || [])[key] || '',
        type: 'table',
        columns,
        rows
      });
    }

    nestedData.forEach(nest => {
      this.getConfigTables(nest, section, tab + 1, array);
    });
    return array;
  }
  /**
   * Create a report for the modules
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {*} reports list or ErrorResponse
   */


  async createReportsModules(context, request, response) {
    try {
      (0, _logger.log)('reporting:createReportsModules', `Report started`, 'info');
      const {
        array,
        agents,
        browserTimezone,
        searchBar,
        filters,
        time,
        tables,
        name,
        section,
        indexPatternTitle,
        apiId
      } = request.body;
      const {
        moduleID
      } = request.params;
      const {
        from,
        to
      } = time || {}; // Init

      const printer = new _printer.ReportPrinter();
      const {
        username: userID
      } = await context.wazuh.security.getCurrentUser(request, context);
      (0, _filesystem.createDataDirectoryIfNotExists)();
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID));
      await this.renderHeader(context, printer, section, moduleID, agents, apiId);
      const [sanitizedFilters, agentsFilter] = filters ? this.sanitizeKibanaFilters(filters, searchBar) : [false, false];

      if (time && sanitizedFilters) {
        printer.addTimeRangeAndFilters(from, to, sanitizedFilters, browserTimezone);
      }

      if (time) {
        await this.extendedInformation(context, printer, section, moduleID, apiId, new Date(from).getTime(), new Date(to).getTime(), sanitizedFilters, indexPatternTitle, agents);
      }

      printer.addVisualizations(array, agents, moduleID);

      if (tables) {
        printer.addTables(tables);
      } //add authorized agents


      if (agentsFilter) {
        printer.addAgentsFilters(agentsFilter);
      }

      await printer.print(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID, name));
      return response.ok({
        body: {
          success: true,
          message: `Report ${name} was created`
        }
      });
    } catch (error) {
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
    }
  }
  /**
   * Create a report for the groups
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {*} reports list or ErrorResponse
   */


  async createReportsGroups(context, request, response) {
    try {
      (0, _logger.log)('reporting:createReportsGroups', `Report started`, 'info');
      const {
        name,
        components,
        apiId
      } = request.body;
      const {
        groupID
      } = request.params; // Init

      const printer = new _printer.ReportPrinter();
      const {
        username: userID
      } = await context.wazuh.security.getCurrentUser(request, context);
      (0, _filesystem.createDataDirectoryIfNotExists)();
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID));
      let tables = [];
      const equivalences = {
        localfile: 'Local files',
        osquery: 'Osquery',
        command: 'Command',
        syscheck: 'Syscheck',
        'open-scap': 'OpenSCAP',
        'cis-cat': 'CIS-CAT',
        syscollector: 'Syscollector',
        rootcheck: 'Rootcheck',
        labels: 'Labels',
        sca: 'Security configuration assessment'
      };
      printer.addContent({
        text: `Group ${groupID} configuration`,
        style: 'h1'
      });

      if (components['0']) {
        let configuration = {};

        try {
          const configurationResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/groups/${groupID}/configuration`, {}, {
            apiHostID: apiId
          });
          configuration = configurationResponse.data.data;
        } catch (error) {
          (0, _logger.log)('reporting:createReportsGroups', error.message || error, 'debug');
        }

        if (configuration.affected_items.length > 0 && Object.keys(configuration.affected_items[0].config).length) {
          printer.addContent({
            text: 'Configurations',
            style: {
              fontSize: 14,
              color: '#000'
            },
            margin: [0, 10, 0, 15]
          });
          const section = {
            labels: [],
            isGroupConfig: true
          };

          for (let config of configuration.affected_items) {
            let filterTitle = '';
            let index = 0;

            for (let filter of Object.keys(config.filters)) {
              filterTitle = filterTitle.concat(`${filter}: ${config.filters[filter]}`);

              if (index < Object.keys(config.filters).length - 1) {
                filterTitle = filterTitle.concat(' | ');
              }

              index++;
            }

            printer.addContent({
              text: filterTitle,
              style: 'h4',
              margin: [0, 0, 0, 10]
            });
            let idx = 0;
            section.tabs = [];

            for (let _d of Object.keys(config.config)) {
              for (let c of _agentConfiguration.AgentConfiguration.configurations) {
                for (let s of c.sections) {
                  section.opts = s.opts || {};

                  for (let cn of s.config || []) {
                    if (cn.configuration === _d) {
                      section.labels = s.labels || [[]];
                    }
                  }

                  for (let wo of s.wodle || []) {
                    if (wo.name === _d) {
                      section.labels = s.labels || [[]];
                    }
                  }
                }
              }

              section.labels[0]['pack'] = 'Packs';
              section.labels[0]['content'] = 'Evaluations';
              section.labels[0]['7'] = 'Scan listening netwotk ports';
              section.tabs.push(equivalences[_d]);

              if (Array.isArray(config.config[_d])) {
                /* LOG COLLECTOR */
                if (_d === 'localfile') {
                  let groups = [];

                  config.config[_d].forEach(obj => {
                    if (!groups[obj.logformat]) {
                      groups[obj.logformat] = [];
                    }

                    groups[obj.logformat].push(obj);
                  });

                  Object.keys(groups).forEach(group => {
                    let saveidx = 0;
                    groups[group].forEach((x, i) => {
                      if (Object.keys(x).length > Object.keys(groups[group][saveidx]).length) {
                        saveidx = i;
                      }
                    });
                    const columns = Object.keys(groups[group][saveidx]);
                    const rows = groups[group].map(x => {
                      let row = [];
                      columns.forEach(key => {
                        row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
                          return x + '\n';
                        }) : JSON.stringify(x[key]));
                      });
                      return row;
                    });
                    columns.forEach((col, i) => {
                      columns[i] = col[0].toUpperCase() + col.slice(1);
                    });
                    tables.push({
                      title: 'Local files',
                      type: 'table',
                      columns,
                      rows
                    });
                  });
                } else if (_d === 'labels') {
                  const obj = config.config[_d][0].label;
                  const columns = Object.keys(obj[0]);

                  if (!columns.includes('hidden')) {
                    columns.push('hidden');
                  }

                  const rows = obj.map(x => {
                    let row = [];
                    columns.forEach(key => {
                      row.push(x[key]);
                    });
                    return row;
                  });
                  columns.forEach((col, i) => {
                    columns[i] = col[0].toUpperCase() + col.slice(1);
                  });
                  tables.push({
                    title: 'Labels',
                    type: 'table',
                    columns,
                    rows
                  });
                } else {
                  for (let _d2 of config.config[_d]) {
                    tables.push(...this.getConfigTables(_d2, section, idx));
                  }
                }
              } else {
                /*INTEGRITY MONITORING MONITORED DIRECTORIES */
                if (config.config[_d].directories) {
                  const directories = config.config[_d].directories;
                  delete config.config[_d].directories;
                  tables.push(...this.getConfigTables(config.config[_d], section, idx));
                  let diffOpts = [];
                  Object.keys(section.opts).forEach(x => {
                    diffOpts.push(x);
                  });
                  const columns = ['', ...diffOpts.filter(x => x !== 'check_all' && x !== 'check_sum')];
                  let rows = [];
                  directories.forEach(x => {
                    let row = [];
                    row.push(x.path);
                    columns.forEach(y => {
                      if (y !== '') {
                        y = y !== 'check_whodata' ? y : 'whodata';
                        row.push(x[y] ? x[y] : 'no');
                      }
                    });
                    row.push(x.recursion_level);
                    rows.push(row);
                  });
                  columns.forEach((x, idx) => {
                    columns[idx] = section.opts[x];
                  });
                  columns.push('RL');
                  tables.push({
                    title: 'Monitored directories',
                    type: 'table',
                    columns,
                    rows
                  });
                } else {
                  tables.push(...this.getConfigTables(config.config[_d], section, idx));
                }
              }

              for (const table of tables) {
                printer.addConfigTables([table]);
              }

              idx++;
              tables = [];
            }

            tables = [];
          }
        } else {
          printer.addContent({
            text: 'A configuration for this group has not yet been set up.',
            style: {
              fontSize: 12,
              color: '#000'
            },
            margin: [0, 10, 0, 15]
          });
        }
      }

      if (components['1']) {
        let agentsInGroup = [];

        try {
          const agentsInGroupResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/groups/${groupID}/agents`, {}, {
            apiHostID: apiId
          });
          agentsInGroup = agentsInGroupResponse.data.data.affected_items;
        } catch (error) {
          (0, _logger.log)('reporting:report', error.message || error, 'debug');
        }

        await this.renderHeader(context, printer, 'groupConfig', groupID, (agentsInGroup || []).map(x => x.id), apiId);
      }

      await printer.print(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID, name));
      return response.ok({
        body: {
          success: true,
          message: `Report ${name} was created`
        }
      });
    } catch (error) {
      (0, _logger.log)('reporting:createReportsGroups', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
    }
  }
  /**
   * Create a report for the agents
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {*} reports list or ErrorResponse
   */


  async createReportsAgents(context, request, response) {
    try {
      (0, _logger.log)('reporting:createReportsAgents', `Report started`, 'info');
      const {
        name,
        components,
        apiId
      } = request.body;
      const {
        agentID
      } = request.params;
      const printer = new _printer.ReportPrinter();
      const {
        username: userID
      } = await context.wazuh.security.getCurrentUser(request, context);
      (0, _filesystem.createDataDirectoryIfNotExists)();
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID));
      let wmodulesResponse = {};
      let tables = [];

      try {
        wmodulesResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents/${agentID}/config/wmodules/wmodules`, {}, {
          apiHostID: apiId
        });
      } catch (error) {
        (0, _logger.log)('reporting:report', error.message || error, 'debug');
      }

      await this.renderHeader(context, printer, 'agentConfig', 'agentConfig', agentID, apiId);
      let idxComponent = 0;

      for (let config of _agentConfiguration.AgentConfiguration.configurations) {
        let titleOfSection = false;
        (0, _logger.log)('reporting:createReportsAgents', `Iterate over ${config.sections.length} configuration sections`, 'debug');

        for (let section of config.sections) {
          let titleOfSubsection = false;

          if (components[idxComponent] && (section.config || section.wodle)) {
            let idx = 0;
            const configs = (section.config || []).concat(section.wodle || []);
            (0, _logger.log)('reporting:createReportsAgents', `Iterate over ${configs.length} configuration blocks`, 'debug');

            for (let conf of configs) {
              let agentConfigResponse = {};

              try {
                if (!conf['name']) {
                  agentConfigResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents/${agentID}/config/${conf.component}/${conf.configuration}`, {}, {
                    apiHostID: apiId
                  });
                } else {
                  for (let wodle of wmodulesResponse.data.data['wmodules']) {
                    if (Object.keys(wodle)[0] === conf['name']) {
                      agentConfigResponse.data = {
                        data: wodle
                      };
                    }
                  }
                }

                const agentConfig = agentConfigResponse && agentConfigResponse.data && agentConfigResponse.data.data;

                if (!titleOfSection) {
                  printer.addContent({
                    text: config.title,
                    style: 'h1',
                    margin: [0, 0, 0, 15]
                  });
                  titleOfSection = true;
                }

                if (!titleOfSubsection) {
                  printer.addContent({
                    text: section.subtitle,
                    style: 'h4'
                  });
                  printer.addContent({
                    text: section.desc,
                    style: {
                      fontSize: 12,
                      color: '#000'
                    },
                    margin: [0, 0, 0, 10]
                  });
                  titleOfSubsection = true;
                }

                if (agentConfig) {
                  for (let agentConfigKey of Object.keys(agentConfig)) {
                    if (Array.isArray(agentConfig[agentConfigKey])) {
                      /* LOG COLLECTOR */
                      if (conf.filterBy) {
                        let groups = [];
                        agentConfig[agentConfigKey].forEach(obj => {
                          if (!groups[obj.logformat]) {
                            groups[obj.logformat] = [];
                          }

                          groups[obj.logformat].push(obj);
                        });
                        Object.keys(groups).forEach(group => {
                          let saveidx = 0;
                          groups[group].forEach((x, i) => {
                            if (Object.keys(x).length > Object.keys(groups[group][saveidx]).length) {
                              saveidx = i;
                            }
                          });
                          const columns = Object.keys(groups[group][saveidx]);
                          const rows = groups[group].map(x => {
                            let row = [];
                            columns.forEach(key => {
                              row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
                                return x + '\n';
                              }) : JSON.stringify(x[key]));
                            });
                            return row;
                          });
                          columns.forEach((col, i) => {
                            columns[i] = col[0].toUpperCase() + col.slice(1);
                          });
                          tables.push({
                            title: section.labels[0][group],
                            type: 'table',
                            columns,
                            rows
                          });
                        });
                      } else if (agentConfigKey.configuration !== 'socket') {
                        tables.push(...this.getConfigTables(agentConfig[agentConfigKey], section, idx));
                      } else {
                        for (let _d2 of agentConfig[agentConfigKey]) {
                          tables.push(...this.getConfigTables(_d2, section, idx));
                        }
                      }
                    } else {
                      /*INTEGRITY MONITORING MONITORED DIRECTORIES */
                      if (conf.matrix) {
                        const {
                          directories,
                          diff,
                          synchronization,
                          file_limit,
                          ...rest
                        } = agentConfig[agentConfigKey];
                        tables.push(...this.getConfigTables(rest, section, idx), ...(diff && diff.disk_quota ? this.getConfigTables(diff.disk_quota, {
                          tabs: ['Disk quota']
                        }, 0) : []), ...(diff && diff.file_size ? this.getConfigTables(diff.file_size, {
                          tabs: ['File size']
                        }, 0) : []), ...(synchronization ? this.getConfigTables(synchronization, {
                          tabs: ['Synchronization']
                        }, 0) : []), ...(file_limit ? this.getConfigTables(file_limit, {
                          tabs: ['File limit']
                        }, 0) : []));
                        let diffOpts = [];
                        Object.keys(section.opts).forEach(x => {
                          diffOpts.push(x);
                        });
                        const columns = ['', ...diffOpts.filter(x => x !== 'check_all' && x !== 'check_sum')];
                        let rows = [];
                        directories.forEach(x => {
                          let row = [];
                          row.push(x.dir);
                          columns.forEach(y => {
                            if (y !== '') {
                              row.push(x.opts.indexOf(y) > -1 ? 'yes' : 'no');
                            }
                          });
                          row.push(x.recursion_level);
                          rows.push(row);
                        });
                        columns.forEach((x, idx) => {
                          columns[idx] = section.opts[x];
                        });
                        columns.push('RL');
                        tables.push({
                          title: 'Monitored directories',
                          type: 'table',
                          columns,
                          rows
                        });
                      } else {
                        tables.push(...this.getConfigTables(agentConfig[agentConfigKey], section, idx));
                      }
                    }
                  }
                } else {
                  // Print no configured module and link to the documentation
                  printer.addContent({
                    text: ['This module is not configured. Please take a look on how to configure it in ', {
                      text: `${section.subtitle.toLowerCase()} configuration.`,
                      link: section.docuLink,
                      style: {
                        fontSize: 12,
                        color: '#1a0dab'
                      }
                    }],
                    margin: [0, 0, 0, 20]
                  });
                }
              } catch (error) {
                (0, _logger.log)('reporting:report', error.message || error, 'debug');
              }

              idx++;
            }

            for (const table of tables) {
              printer.addConfigTables([table]);
            }
          }

          idxComponent++;
          tables = [];
        }
      }

      await printer.print(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID, name));
      return response.ok({
        body: {
          success: true,
          message: `Report ${name} was created`
        }
      });
    } catch (error) {
      (0, _logger.log)('reporting:createReportsAgents', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
    }
  }
  /**
   * Create a report for the agents
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {*} reports list or ErrorResponse
   */


  async createReportsAgentsInventory(context, request, response) {
    try {
      (0, _logger.log)('reporting:createReportsAgentsInventory', `Report started`, 'info');
      const {
        searchBar,
        filters,
        time,
        name,
        indexPatternTitle,
        apiId
      } = request.body;
      const {
        agentID
      } = request.params;
      const {
        from,
        to
      } = time || {}; // Init

      const printer = new _printer.ReportPrinter();
      const {
        username: userID
      } = await context.wazuh.security.getCurrentUser(request, context);
      (0, _filesystem.createDataDirectoryIfNotExists)();
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID));
      (0, _logger.log)('reporting:createReportsAgentsInventory', `Syscollector report`, 'debug');
      const sanitizedFilters = filters ? this.sanitizeKibanaFilters(filters, searchBar) : false; // Get the agent OS

      let agentOs = '';

      try {
        const agentResponse = await context.wazuh.api.client.asCurrentUser.request('GET', '/agents', {
          params: {
            q: `id=${agentID}`
          }
        }, {
          apiHostID: apiId
        });
        agentOs = agentResponse.data.data.affected_items[0].os.platform;
      } catch (error) {
        (0, _logger.log)('reporting:createReportsAgentsInventory', error.message || error, 'debug');
      } // Add title


      printer.addContentWithNewLine({
        text: 'Inventory data report',
        style: 'h1'
      }); // Add table with the agent info

      await this.buildAgentsTable(context, printer, [agentID], apiId); // Get syscollector packages and processes

      const agentRequestsInventory = [{
        endpoint: `/syscollector/${agentID}/packages`,
        loggerMessage: `Fetching packages for agent ${agentID}`,
        table: {
          title: 'Packages',
          columns: agentOs === 'windows' ? [{
            id: 'name',
            label: 'Name'
          }, {
            id: 'architecture',
            label: 'Architecture'
          }, {
            id: 'version',
            label: 'Version'
          }, {
            id: 'vendor',
            label: 'Vendor'
          }] : [{
            id: 'name',
            label: 'Name'
          }, {
            id: 'architecture',
            label: 'Architecture'
          }, {
            id: 'version',
            label: 'Version'
          }, {
            id: 'vendor',
            label: 'Vendor'
          }, {
            id: 'description',
            label: 'Description'
          }]
        }
      }, {
        endpoint: `/syscollector/${agentID}/processes`,
        loggerMessage: `Fetching processes for agent ${agentID}`,
        table: {
          title: 'Processes',
          columns: agentOs === 'windows' ? [{
            id: 'name',
            label: 'Name'
          }, {
            id: 'cmd',
            label: 'CMD'
          }, {
            id: 'priority',
            label: 'Priority'
          }, {
            id: 'nlwp',
            label: 'NLWP'
          }] : [{
            id: 'name',
            label: 'Name'
          }, {
            id: 'euser',
            label: 'Effective user'
          }, {
            id: 'nice',
            label: 'Priority'
          }, {
            id: 'state',
            label: 'State'
          }]
        },
        mapResponseItems: item => agentOs === 'windows' ? item : { ...item,
          state: _processStateEquivalence.default[item.state]
        }
      }, {
        endpoint: `/syscollector/${agentID}/ports`,
        loggerMessage: `Fetching ports for agent ${agentID}`,
        table: {
          title: 'Network ports',
          columns: agentOs === 'windows' ? [{
            id: 'local_ip',
            label: 'Local IP'
          }, {
            id: 'local_port',
            label: 'Local port'
          }, {
            id: 'process',
            label: 'Process'
          }, {
            id: 'state',
            label: 'State'
          }, {
            id: 'protocol',
            label: 'Protocol'
          }] : [{
            id: 'local_ip',
            label: 'Local IP'
          }, {
            id: 'local_port',
            label: 'Local port'
          }, {
            id: 'state',
            label: 'State'
          }, {
            id: 'protocol',
            label: 'Protocol'
          }]
        },
        mapResponseItems: item => ({ ...item,
          local_ip: item.local.ip,
          local_port: item.local.port
        })
      }, {
        endpoint: `/syscollector/${agentID}/netiface`,
        loggerMessage: `Fetching netiface for agent ${agentID}`,
        table: {
          title: 'Network interfaces',
          columns: [{
            id: 'name',
            label: 'Name'
          }, {
            id: 'mac',
            label: 'Mac'
          }, {
            id: 'state',
            label: 'State'
          }, {
            id: 'mtu',
            label: 'MTU'
          }, {
            id: 'type',
            label: 'Type'
          }]
        }
      }, {
        endpoint: `/syscollector/${agentID}/netaddr`,
        loggerMessage: `Fetching netaddr for agent ${agentID}`,
        table: {
          title: 'Network settings',
          columns: [{
            id: 'iface',
            label: 'Interface'
          }, {
            id: 'address',
            label: 'address'
          }, {
            id: 'netmask',
            label: 'Netmask'
          }, {
            id: 'proto',
            label: 'Protocol'
          }, {
            id: 'broadcast',
            label: 'Broadcast'
          }]
        }
      }];
      agentOs === 'windows' && agentRequestsInventory.push({
        endpoint: `/syscollector/${agentID}/hotfixes`,
        loggerMessage: `Fetching hotfixes for agent ${agentID}`,
        table: {
          title: 'Windows updates',
          columns: [{
            id: 'hotfix',
            label: 'Update code'
          }]
        }
      });

      const requestInventory = async agentRequestInventory => {
        try {
          (0, _logger.log)('reporting:createReportsAgentsInventory', agentRequestInventory.loggerMessage, 'debug');
          const inventoryResponse = await context.wazuh.api.client.asCurrentUser.request('GET', agentRequestInventory.endpoint, {}, {
            apiHostID: apiId
          });
          const inventory = inventoryResponse && inventoryResponse.data && inventoryResponse.data.data && inventoryResponse.data.data.affected_items;

          if (inventory) {
            return { ...agentRequestInventory.table,
              items: agentRequestInventory.mapResponseItems ? inventory.map(agentRequestInventory.mapResponseItems) : inventory
            };
          }
        } catch (error) {
          (0, _logger.log)('reporting:createReportsAgentsInventory', error.message || error, 'debug');
        }
      };

      if (time) {
        await this.extendedInformation(context, printer, 'agents', 'syscollector', apiId, from, to, sanitizedFilters + ' AND rule.groups: "vulnerability-detector"', indexPatternTitle, agentID);
      } // Add inventory tables


      (await Promise.all(agentRequestsInventory.map(requestInventory))).filter(table => table).forEach(table => printer.addSimpleTable(table)); // Print the document

      await printer.print(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID, name));
      return response.ok({
        body: {
          success: true,
          message: `Report ${name} was created`
        }
      });
    } catch (error) {
      (0, _logger.log)('reporting:createReportsAgents', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
    }
  }
  /**
   * Fetch the reports list
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Array<Object>} reports list or ErrorResponse
   */


  async getReports(context, request, response) {
    try {
      (0, _logger.log)('reporting:getReports', `Fetching created reports`, 'info');
      const {
        username: userID
      } = await context.wazuh.security.getCurrentUser(request, context);
      (0, _filesystem.createDataDirectoryIfNotExists)();
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);

      const userReportsDirectory = _path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID);

      (0, _filesystem.createDirectoryIfNotExists)(userReportsDirectory);
      (0, _logger.log)('reporting:getReports', `Directory: ${userReportsDirectory}`, 'debug');

      const sortReportsByDate = (a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : 0;

      const reports = _fs.default.readdirSync(userReportsDirectory).map(file => {
        const stats = _fs.default.statSync(userReportsDirectory + '/' + file); // Get the file creation time (bithtime). It returns the first value that is a truthy value of next file stats: birthtime, mtime, ctime and atime.
        // This solves some OSs can have the bithtimeMs equal to 0 and returns the date like 1970-01-01


        const birthTimeField = ['birthtime', 'mtime', 'ctime', 'atime'].find(time => stats[`${time}Ms`]);
        return {
          name: file,
          size: stats.size,
          date: stats[birthTimeField]
        };
      });

      (0, _logger.log)('reporting:getReports', `Using TimSort for sorting ${reports.length} items`, 'debug');
      TimSort.sort(reports, sortReportsByDate);
      (0, _logger.log)('reporting:getReports', `Total reports: ${reports.length}`, 'debug');
      return response.ok({
        body: {
          reports
        }
      });
    } catch (error) {
      (0, _logger.log)('reporting:getReports', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5031, 500, response);
    }
  }
  /**
   * Fetch specific report
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} report or ErrorResponse
   */


  async getReportByName(context, request, response) {
    try {
      (0, _logger.log)('reporting:getReportByName', `Getting ${request.params.name} report`, 'debug');
      const {
        username: userID
      } = await context.wazuh.security.getCurrentUser(request, context);

      const reportFileBuffer = _fs.default.readFileSync(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID, request.params.name));

      return response.ok({
        headers: {
          'Content-Type': 'application/pdf'
        },
        body: reportFileBuffer
      });
    } catch (error) {
      (0, _logger.log)('reporting:getReportByName', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5030, 500, response);
    }
  }
  /**
   * Delete specific report
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */


  async deleteReportByName(context, request, response) {
    try {
      (0, _logger.log)('reporting:deleteReportByName', `Deleting ${request.params.name} report`, 'debug');
      const {
        username: userID
      } = await context.wazuh.security.getCurrentUser(request, context);

      _fs.default.unlinkSync(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, userID, request.params.name));

      (0, _logger.log)('reporting:deleteReportByName', `${request.params.name} report was deleted`, 'info');
      return response.ok({
        body: {
          error: 0
        }
      });
    } catch (error) {
      (0, _logger.log)('reporting:deleteReportByName', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5032, 500, response);
    }
  }

}

exports.WazuhReportingCtrl = WazuhReportingCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhenVoLXJlcG9ydGluZy50cyJdLCJuYW1lcyI6WyJXYXp1aFJlcG9ydGluZ0N0cmwiLCJjb25zdHJ1Y3RvciIsInNhbml0aXplS2liYW5hRmlsdGVycyIsImZpbHRlcnMiLCJzZWFyY2hCYXIiLCJsZW5ndGgiLCJzdHIiLCJhZ2VudHNGaWx0ZXIiLCJmaWx0ZXIiLCJtZXRhIiwiY29udHJvbGxlZEJ5IiwiQVVUSE9SSVpFRF9BR0VOVFMiLCJwdXNoIiwibGVuIiwiaSIsIm5lZ2F0ZSIsImtleSIsInZhbHVlIiwicGFyYW1zIiwidHlwZSIsImd0ZSIsImx0Iiwiam9pbiIsInF1ZXJ5IiwiYWdlbnRzRmlsdGVyU3RyIiwibWFwIiwicmVuZGVySGVhZGVyIiwiY29udGV4dCIsInByaW50ZXIiLCJzZWN0aW9uIiwidGFiIiwiaXNBZ2VudHMiLCJhcGlJZCIsImluY2x1ZGVzIiwiYWRkQ29udGVudCIsInRleHQiLCJXQVpVSF9NT0RVTEVTIiwidGl0bGUiLCJzdHlsZSIsImZvbnRTaXplIiwiY29sb3IiLCJtYXJnaW4iLCJPYmplY3QiLCJrZXlzIiwiYWRkTmV3TGluZSIsImJ1aWxkQWdlbnRzVGFibGUiLCJhZ2VudFJlc3BvbnNlIiwid2F6dWgiLCJhcGkiLCJjbGllbnQiLCJhc0N1cnJlbnRVc2VyIiwicmVxdWVzdCIsImFnZW50c19saXN0IiwiYXBpSG9zdElEIiwiYWdlbnREYXRhIiwiZGF0YSIsImFmZmVjdGVkX2l0ZW1zIiwic3RhdHVzIiwiYWRkQ29udGVudFdpdGhOZXdMaW5lIiwidG9Mb3dlckNhc2UiLCJncm91cCIsImFnZW50R3JvdXBzIiwiZGVzY3JpcHRpb24iLCJlcnJvciIsIm1lc3NhZ2UiLCJQcm9taXNlIiwicmVqZWN0IiwiYWdlbnRJRHMiLCJtdWx0aSIsImRhdGVGb3JtYXQiLCJjb3JlIiwidWlTZXR0aW5ncyIsImdldCIsImFnZW50Um93cyIsImFnZW50c1Jlc3BvbnNlIiwiYWdlbnRzRGF0YSIsImFnZW50IiwibWFuYWdlciIsIm1hbmFnZXJfaG9zdCIsIm9zIiwibmFtZSIsInZlcnNpb24iLCJhZ2VudElEIiwicSIsImxhc3RLZWVwQWxpdmUiLCJmb3JtYXQiLCJkYXRlQWRkIiwiYWRkU2ltcGxlVGFibGUiLCJjb2x1bW5zIiwiaWQiLCJsYWJlbCIsIml0ZW1zIiwiZXh0ZW5kZWRJbmZvcm1hdGlvbiIsImZyb20iLCJ0byIsInBhdHRlcm4iLCJXQVpVSF9BTEVSVFNfUEFUVEVSTiIsIkVycm9yIiwiYWdlbnRzIiwibGltaXQiLCJ0b3RhbEFnZW50cyIsInRvdGFsX2FmZmVjdGVkX2l0ZW1zIiwidnVsbmVyYWJpbGl0aWVzTGV2ZWxzIiwidnVsbmVyYWJpbGl0aWVzUmVzcG9uc2VzQ291bnQiLCJhbGwiLCJ2dWxuZXJhYmlsaXRpZXNMZXZlbCIsImNvdW50IiwiVnVsbmVyYWJpbGl0eVJlcXVlc3QiLCJ1bmlxdWVTZXZlcml0eUNvdW50IiwidG9Mb2NhbGVMb3dlckNhc2UiLCJ1bmRlZmluZWQiLCJ2dWxuZXJhYmlsaXRpZXNSZXNwb25zZSIsImFkZExpc3QiLCJsaXN0IiwibG93UmFuayIsInRvcEFnZW50Q291bnQiLCJtZWRpdW1SYW5rIiwiaGlnaFJhbmsiLCJjcml0aWNhbFJhbmsiLCJjdmVSYW5rIiwidG9wQ1ZFQ291bnQiLCJpdGVtIiwidG9wIiwiaW5kZXhPZiIsImN2ZSIsImxldmVsMTVSYW5rIiwiT3ZlcnZpZXdSZXF1ZXN0IiwidG9wTGV2ZWwxNSIsInRvcDVSb290a2l0c1JhbmsiLCJSb290Y2hlY2tSZXF1ZXN0IiwidG9wNVJvb3RraXRzRGV0ZWN0ZWQiLCJoaWRkZW5QaWRzIiwiYWdlbnRzV2l0aEhpZGRlblBpZHMiLCJoaWRkZW5Qb3J0cyIsImFnZW50c1dpdGhIaWRkZW5Qb3J0cyIsInRvcFBjaVJlcXVpcmVtZW50cyIsIlBDSVJlcXVlc3QiLCJ0b3BQQ0lSZXF1aXJlbWVudHMiLCJydWxlcyIsImdldFJ1bGVzQnlSZXF1aXJlbWVudCIsIlBDSSIsImNvbnRlbnQiLCJ0b3BUU0NSZXF1aXJlbWVudHMiLCJUU0NSZXF1ZXN0IiwiVFNDIiwidG9wR2RwclJlcXVpcmVtZW50cyIsIkdEUFJSZXF1ZXN0IiwidG9wR0RQUlJlcXVpcmVtZW50cyIsIkdEUFIiLCJhdWRpdEFnZW50c05vblN1Y2Nlc3MiLCJBdWRpdFJlcXVlc3QiLCJnZXRUb3AzQWdlbnRzU3Vkb05vblN1Y2Nlc3NmdWwiLCJhdWRpdEFnZW50c0ZhaWxlZFN5c2NhbGwiLCJnZXRUb3AzQWdlbnRzRmFpbGVkU3lzY2FsbHMiLCJzeXNjYWxsX2lkIiwic3lzY2FsbCIsInN5c2NhbGxfc3lzY2FsbCIsIlN5c2NoZWNrUmVxdWVzdCIsInRvcDNSdWxlcyIsInRvcDNhZ2VudHMiLCJhdWRpdEZhaWxlZFN5c2NhbGwiLCJnZXRUb3BGYWlsZWRTeXNjYWxscyIsImxhc3RTY2FuUmVzcG9uc2UiLCJsYXN0U2NhbkRhdGEiLCJzdGFydCIsImVuZCIsImxhc3RUZW5EZWxldGVkIiwibGFzdFRlbkRlbGV0ZWRGaWxlcyIsImxhc3RUZW5Nb2RpZmllZCIsImxhc3RUZW5Nb2RpZmllZEZpbGVzIiwicmVxdWVzdHNTeXNjb2xsZWN0b3JMaXN0cyIsImVuZHBvaW50IiwibG9nZ2VyTWVzc2FnZSIsIm1hcFJlc3BvbnNlIiwiaGFyZHdhcmUiLCJjcHUiLCJjb3JlcyIsInJhbSIsInRvdGFsIiwiTnVtYmVyIiwidG9GaXhlZCIsIm9zRGF0YSIsInN5c25hbWUiLCJhcmNoaXRlY3R1cmUiLCJyZWxlYXNlIiwic3lzY29sbGVjdG9yTGlzdHMiLCJyZXF1ZXN0U3lzY29sbGVjdG9yIiwicmVzcG9uc2VTeXNjb2xsZWN0b3IiLCJzeXNjb2xsZWN0b3JMaXN0IiwiZm9yRWFjaCIsInZ1bG5lcmFiaWxpdGllc1JlcXVlc3RzIiwidnVsbmVyYWJpbGl0aWVzUmVzcG9uc2VzSXRlbXMiLCJ0b3BQYWNrYWdlcyIsImZsYXQiLCJ0b3BDcml0aWNhbFBhY2thZ2VzIiwidG9wUGFja2FnZXNXaXRoQ1ZFIiwiY3VzdG9tdWwiLCJjcml0aWNhbCIsInBhY2thZ2UiLCJ1bCIsInJlZmVyZW5jZXMiLCJzdWJzdHJpbmciLCJsaW5rIiwidG9wSGlnaFBhY2thZ2VzIiwiZ2V0Q29uZmlnUm93cyIsImxhYmVscyIsInJlc3VsdCIsInByb3AiLCJBcnJheSIsImlzQXJyYXkiLCJ4IiwiaWR4IiwiSlNPTiIsInN0cmluZ2lmeSIsIktleUVxdWl2YWxlbmNlIiwiZ2V0Q29uZmlnVGFibGVzIiwiYXJyYXkiLCJwbGFpbkRhdGEiLCJuZXN0ZWREYXRhIiwidGFibGVEYXRhIiwiY29uZmlnIiwiY29uZmlndXJhdGlvbiIsImlzR3JvdXBDb25maWciLCJvcHRpb25zIiwiaGlkZUhlYWRlciIsInRhYnMiLCJyb3dzIiwiY29sIiwidG9VcHBlckNhc2UiLCJzbGljZSIsInJvdyIsIm5lc3QiLCJjcmVhdGVSZXBvcnRzTW9kdWxlcyIsInJlc3BvbnNlIiwiYnJvd3NlclRpbWV6b25lIiwidGltZSIsInRhYmxlcyIsImluZGV4UGF0dGVyblRpdGxlIiwiYm9keSIsIm1vZHVsZUlEIiwiUmVwb3J0UHJpbnRlciIsInVzZXJuYW1lIiwidXNlcklEIiwic2VjdXJpdHkiLCJnZXRDdXJyZW50VXNlciIsIldBWlVIX0RBVEFfRE9XTkxPQURTX0RJUkVDVE9SWV9QQVRIIiwiV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCIsInBhdGgiLCJzYW5pdGl6ZWRGaWx0ZXJzIiwiYWRkVGltZVJhbmdlQW5kRmlsdGVycyIsIkRhdGUiLCJnZXRUaW1lIiwiYWRkVmlzdWFsaXphdGlvbnMiLCJhZGRUYWJsZXMiLCJhZGRBZ2VudHNGaWx0ZXJzIiwicHJpbnQiLCJvayIsInN1Y2Nlc3MiLCJjcmVhdGVSZXBvcnRzR3JvdXBzIiwiY29tcG9uZW50cyIsImdyb3VwSUQiLCJlcXVpdmFsZW5jZXMiLCJsb2NhbGZpbGUiLCJvc3F1ZXJ5IiwiY29tbWFuZCIsInN5c2NoZWNrIiwic3lzY29sbGVjdG9yIiwicm9vdGNoZWNrIiwic2NhIiwiY29uZmlndXJhdGlvblJlc3BvbnNlIiwiZmlsdGVyVGl0bGUiLCJpbmRleCIsImNvbmNhdCIsIl9kIiwiYyIsIkFnZW50Q29uZmlndXJhdGlvbiIsImNvbmZpZ3VyYXRpb25zIiwicyIsInNlY3Rpb25zIiwib3B0cyIsImNuIiwid28iLCJ3b2RsZSIsImdyb3VwcyIsIm9iaiIsImxvZ2Zvcm1hdCIsInNhdmVpZHgiLCJfZDIiLCJkaXJlY3RvcmllcyIsImRpZmZPcHRzIiwieSIsInJlY3Vyc2lvbl9sZXZlbCIsInRhYmxlIiwiYWRkQ29uZmlnVGFibGVzIiwiYWdlbnRzSW5Hcm91cCIsImFnZW50c0luR3JvdXBSZXNwb25zZSIsImNyZWF0ZVJlcG9ydHNBZ2VudHMiLCJ3bW9kdWxlc1Jlc3BvbnNlIiwiaWR4Q29tcG9uZW50IiwidGl0bGVPZlNlY3Rpb24iLCJ0aXRsZU9mU3Vic2VjdGlvbiIsImNvbmZpZ3MiLCJjb25mIiwiYWdlbnRDb25maWdSZXNwb25zZSIsImNvbXBvbmVudCIsImFnZW50Q29uZmlnIiwic3VidGl0bGUiLCJkZXNjIiwiYWdlbnRDb25maWdLZXkiLCJmaWx0ZXJCeSIsIm1hdHJpeCIsImRpZmYiLCJzeW5jaHJvbml6YXRpb24iLCJmaWxlX2xpbWl0IiwicmVzdCIsImRpc2tfcXVvdGEiLCJmaWxlX3NpemUiLCJkaXIiLCJkb2N1TGluayIsImNyZWF0ZVJlcG9ydHNBZ2VudHNJbnZlbnRvcnkiLCJhZ2VudE9zIiwicGxhdGZvcm0iLCJhZ2VudFJlcXVlc3RzSW52ZW50b3J5IiwibWFwUmVzcG9uc2VJdGVtcyIsInN0YXRlIiwiUHJvY2Vzc0VxdWl2YWxlbmNlIiwibG9jYWxfaXAiLCJsb2NhbCIsImlwIiwibG9jYWxfcG9ydCIsInBvcnQiLCJyZXF1ZXN0SW52ZW50b3J5IiwiYWdlbnRSZXF1ZXN0SW52ZW50b3J5IiwiaW52ZW50b3J5UmVzcG9uc2UiLCJpbnZlbnRvcnkiLCJnZXRSZXBvcnRzIiwidXNlclJlcG9ydHNEaXJlY3RvcnkiLCJzb3J0UmVwb3J0c0J5RGF0ZSIsImEiLCJiIiwiZGF0ZSIsInJlcG9ydHMiLCJmcyIsInJlYWRkaXJTeW5jIiwiZmlsZSIsInN0YXRzIiwic3RhdFN5bmMiLCJiaXJ0aFRpbWVGaWVsZCIsImZpbmQiLCJzaXplIiwiVGltU29ydCIsInNvcnQiLCJnZXRSZXBvcnRCeU5hbWUiLCJyZXBvcnRGaWxlQnVmZmVyIiwicmVhZEZpbGVTeW5jIiwiaGVhZGVycyIsImRlbGV0ZVJlcG9ydEJ5TmFtZSIsInVubGlua1N5bmMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFXQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFFQTs7QUFDQTs7QUFDQTs7QUFNQTs7QUFDQTs7Ozs7Ozs7QUF4Q0E7Ozs7Ozs7Ozs7O0FBMENPLE1BQU1BLGtCQUFOLENBQXlCO0FBQzlCQyxFQUFBQSxXQUFXLEdBQUcsQ0FBRTtBQUVoQjs7Ozs7OztBQUtRQyxFQUFBQSxxQkFBUixDQUE4QkMsT0FBOUIsRUFBNENDLFNBQTVDLEVBQWtGO0FBQ2hGLHFCQUFJLGlDQUFKLEVBQXdDLDZCQUF4QyxFQUFzRSxNQUF0RTtBQUNBLHFCQUNFLGlDQURGLEVBRUcsWUFBV0QsT0FBTyxDQUFDRSxNQUFPLGdCQUFlRCxTQUFVLEVBRnRELEVBR0UsT0FIRjtBQUtBLFFBQUlFLEdBQUcsR0FBRyxFQUFWO0FBRUEsVUFBTUMsWUFBaUIsR0FBRyxFQUExQixDQVRnRixDQVdoRjs7QUFDQUosSUFBQUEsT0FBTyxHQUFHQSxPQUFPLENBQUNLLE1BQVIsQ0FBZ0JBLE1BQUQsSUFBWTtBQUNuQyxVQUFJQSxNQUFNLENBQUNDLElBQVAsQ0FBWUMsWUFBWixLQUE2QkMsNEJBQWpDLEVBQW9EO0FBQ2xESixRQUFBQSxZQUFZLENBQUNLLElBQWIsQ0FBa0JKLE1BQWxCO0FBQ0EsZUFBTyxLQUFQO0FBQ0Q7O0FBQ0QsYUFBT0EsTUFBUDtBQUNELEtBTlMsQ0FBVjtBQVFBLFVBQU1LLEdBQUcsR0FBR1YsT0FBTyxDQUFDRSxNQUFwQjs7QUFFQSxTQUFLLElBQUlTLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdELEdBQXBCLEVBQXlCQyxDQUFDLEVBQTFCLEVBQThCO0FBQzVCLFlBQU07QUFBRUMsUUFBQUEsTUFBRjtBQUFVQyxRQUFBQSxHQUFWO0FBQWVDLFFBQUFBLEtBQWY7QUFBc0JDLFFBQUFBLE1BQXRCO0FBQThCQyxRQUFBQTtBQUE5QixVQUF1Q2hCLE9BQU8sQ0FBQ1csQ0FBRCxDQUFQLENBQVdMLElBQXhEO0FBQ0FILE1BQUFBLEdBQUcsSUFBSyxHQUFFUyxNQUFNLEdBQUcsTUFBSCxHQUFZLEVBQUcsRUFBL0I7QUFDQVQsTUFBQUEsR0FBRyxJQUFLLEdBQUVVLEdBQUksSUFBZDtBQUNBVixNQUFBQSxHQUFHLElBQUssR0FDTmEsSUFBSSxLQUFLLE9BQVQsR0FDSyxHQUFFRCxNQUFNLENBQUNFLEdBQUksSUFBR0YsTUFBTSxDQUFDRyxFQUFHLEVBRC9CLEdBRUlGLElBQUksS0FBSyxTQUFULEdBQ0UsTUFBTUQsTUFBTSxDQUFDSSxJQUFQLENBQVksTUFBWixDQUFOLEdBQTRCLEdBRDlCLEdBRUVILElBQUksS0FBSyxRQUFULEdBQ0UsR0FERixHQUVFLENBQUMsQ0FBQ0YsS0FBRixHQUNKQSxLQURJLEdBRUosQ0FBQ0MsTUFBTSxJQUFJLEVBQVgsRUFBZUssS0FDcEIsRUFWRDtBQVdBakIsTUFBQUEsR0FBRyxJQUFLLEdBQUVRLENBQUMsS0FBS0QsR0FBRyxHQUFHLENBQVosR0FBZ0IsRUFBaEIsR0FBcUIsT0FBUSxFQUF2QztBQUNEOztBQUVELFFBQUlULFNBQUosRUFBZTtBQUNiRSxNQUFBQSxHQUFHLElBQUssU0FBU0YsU0FBVSxHQUEzQjtBQUNEOztBQUVELFVBQU1vQixlQUFlLEdBQUdqQixZQUFZLENBQUNrQixHQUFiLENBQWtCakIsTUFBRCxJQUFZQSxNQUFNLENBQUNDLElBQVAsQ0FBWVEsS0FBekMsRUFBZ0RLLElBQWhELENBQXFELEdBQXJELENBQXhCO0FBRUEscUJBQ0UsaUNBREYsRUFFRyxRQUFPaEIsR0FBSSxzQkFBcUJrQixlQUFnQixFQUZuRCxFQUdFLE9BSEY7QUFNQSxXQUFPLENBQUNsQixHQUFELEVBQU1rQixlQUFOLENBQVA7QUFDRDtBQUVEOzs7Ozs7Ozs7O0FBUUEsUUFBY0UsWUFBZCxDQUEyQkMsT0FBM0IsRUFBb0NDLE9BQXBDLEVBQTZDQyxPQUE3QyxFQUFzREMsR0FBdEQsRUFBMkRDLFFBQTNELEVBQXFFQyxLQUFyRSxFQUE0RTtBQUMxRSxRQUFJO0FBQ0YsdUJBQ0Usd0JBREYsRUFFRyxZQUFXSCxPQUFRLFVBQVNDLEdBQUksZUFBY0MsUUFBUyxZQUFXQyxLQUFNLEVBRjNFLEVBR0UsT0FIRjs7QUFLQSxVQUFJSCxPQUFPLElBQUksT0FBT0EsT0FBUCxLQUFtQixRQUFsQyxFQUE0QztBQUMxQyxZQUFJLENBQUMsQ0FBQyxhQUFELEVBQWdCLGFBQWhCLEVBQStCSSxRQUEvQixDQUF3Q0osT0FBeEMsQ0FBTCxFQUF1RDtBQUNyREQsVUFBQUEsT0FBTyxDQUFDTSxVQUFSLENBQW1CO0FBQ2pCQyxZQUFBQSxJQUFJLEVBQUVDLDRCQUFjTixHQUFkLEVBQW1CTyxLQUFuQixHQUEyQixTQURoQjtBQUVqQkMsWUFBQUEsS0FBSyxFQUFFO0FBRlUsV0FBbkI7QUFJRCxTQUxELE1BS08sSUFBSVQsT0FBTyxLQUFLLGFBQWhCLEVBQStCO0FBQ3BDRCxVQUFBQSxPQUFPLENBQUNNLFVBQVIsQ0FBbUI7QUFDakJDLFlBQUFBLElBQUksRUFBRyxTQUFRSixRQUFTLGdCQURQO0FBRWpCTyxZQUFBQSxLQUFLLEVBQUU7QUFGVSxXQUFuQjtBQUlELFNBTE0sTUFLQSxJQUFJVCxPQUFPLEtBQUssYUFBaEIsRUFBK0I7QUFDcENELFVBQUFBLE9BQU8sQ0FBQ00sVUFBUixDQUFtQjtBQUNqQkMsWUFBQUEsSUFBSSxFQUFFLGlCQURXO0FBRWpCRyxZQUFBQSxLQUFLLEVBQUU7QUFBRUMsY0FBQUEsUUFBUSxFQUFFLEVBQVo7QUFBZ0JDLGNBQUFBLEtBQUssRUFBRTtBQUF2QixhQUZVO0FBR2pCQyxZQUFBQSxNQUFNLEVBQUUsQ0FBQyxDQUFELEVBQUksRUFBSixFQUFRLENBQVIsRUFBVyxDQUFYO0FBSFMsV0FBbkI7O0FBS0EsY0FBSVosT0FBTyxLQUFLLGFBQVosSUFBNkIsQ0FBQ2EsTUFBTSxDQUFDQyxJQUFQLENBQVlaLFFBQVosRUFBc0IxQixNQUF4RCxFQUFnRTtBQUM5RHVCLFlBQUFBLE9BQU8sQ0FBQ00sVUFBUixDQUFtQjtBQUNqQkMsY0FBQUEsSUFBSSxFQUFFLDBDQURXO0FBRWpCRyxjQUFBQSxLQUFLLEVBQUU7QUFBRUMsZ0JBQUFBLFFBQVEsRUFBRSxFQUFaO0FBQWdCQyxnQkFBQUEsS0FBSyxFQUFFO0FBQXZCLGVBRlU7QUFHakJDLGNBQUFBLE1BQU0sRUFBRSxDQUFDLENBQUQsRUFBSSxFQUFKLEVBQVEsQ0FBUixFQUFXLENBQVg7QUFIUyxhQUFuQjtBQUtEO0FBQ0Y7O0FBQ0RiLFFBQUFBLE9BQU8sQ0FBQ2dCLFVBQVI7QUFDRDs7QUFFRCxVQUFJYixRQUFRLElBQUksT0FBT0EsUUFBUCxLQUFvQixRQUFwQyxFQUE4QztBQUM1QyxjQUFNLEtBQUtjLGdCQUFMLENBQ0psQixPQURJLEVBRUpDLE9BRkksRUFHSkcsUUFISSxFQUlKQyxLQUpJLEVBS0pILE9BQU8sS0FBSyxhQUFaLEdBQTRCQyxHQUE1QixHQUFrQyxLQUw5QixDQUFOO0FBT0Q7O0FBRUQsVUFBSUMsUUFBUSxJQUFJLE9BQU9BLFFBQVAsS0FBb0IsUUFBcEMsRUFBOEM7QUFDNUMsY0FBTWUsYUFBYSxHQUFHLE1BQU1uQixPQUFPLENBQUNvQixLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Q0MsT0FBdkMsQ0FDMUIsS0FEMEIsRUFFekIsU0FGeUIsRUFHMUI7QUFBRWpDLFVBQUFBLE1BQU0sRUFBRTtBQUFFa0MsWUFBQUEsV0FBVyxFQUFFckI7QUFBZjtBQUFWLFNBSDBCLEVBSTFCO0FBQUVzQixVQUFBQSxTQUFTLEVBQUVyQjtBQUFiLFNBSjBCLENBQTVCO0FBTUEsY0FBTXNCLFNBQVMsR0FBR1IsYUFBYSxDQUFDUyxJQUFkLENBQW1CQSxJQUFuQixDQUF3QkMsY0FBeEIsQ0FBdUMsQ0FBdkMsQ0FBbEI7O0FBQ0EsWUFBSUYsU0FBUyxJQUFJQSxTQUFTLENBQUNHLE1BQVYsS0FBcUIsUUFBdEMsRUFBZ0Q7QUFDOUM3QixVQUFBQSxPQUFPLENBQUM4QixxQkFBUixDQUE4QjtBQUM1QnZCLFlBQUFBLElBQUksRUFBRyxxQkFBb0JtQixTQUFTLENBQUNHLE1BQVYsQ0FBaUJFLFdBQWpCLEVBQStCLEVBRDlCO0FBRTVCckIsWUFBQUEsS0FBSyxFQUFFO0FBRnFCLFdBQTlCO0FBSUQ7O0FBQ0QsY0FBTSxLQUFLTyxnQkFBTCxDQUFzQmxCLE9BQXRCLEVBQStCQyxPQUEvQixFQUF3QyxDQUFDRyxRQUFELENBQXhDLEVBQW9EQyxLQUFwRCxDQUFOOztBQUVBLFlBQUlzQixTQUFTLElBQUlBLFNBQVMsQ0FBQ00sS0FBM0IsRUFBa0M7QUFDaEMsZ0JBQU1DLFdBQVcsR0FBR1AsU0FBUyxDQUFDTSxLQUFWLENBQWdCdEMsSUFBaEIsQ0FBcUIsSUFBckIsQ0FBcEI7QUFDQU0sVUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFDNUJ2QixZQUFBQSxJQUFJLEVBQUcsUUFBT21CLFNBQVMsQ0FBQ00sS0FBVixDQUFnQnZELE1BQWhCLEdBQXlCLENBQXpCLEdBQTZCLEdBQTdCLEdBQW1DLEVBQUcsS0FBSXdELFdBQVksRUFEeEM7QUFFNUJ2QixZQUFBQSxLQUFLLEVBQUU7QUFGcUIsV0FBOUI7QUFJRDtBQUNGOztBQUNELFVBQUlGLDRCQUFjTixHQUFkLEtBQXNCTSw0QkFBY04sR0FBZCxFQUFtQmdDLFdBQTdDLEVBQTBEO0FBQ3hEbEMsUUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFDNUJ2QixVQUFBQSxJQUFJLEVBQUVDLDRCQUFjTixHQUFkLEVBQW1CZ0MsV0FERztBQUU1QnhCLFVBQUFBLEtBQUssRUFBRTtBQUZxQixTQUE5QjtBQUlEOztBQUVEO0FBQ0QsS0E1RUQsQ0E0RUUsT0FBT3lCLEtBQVAsRUFBYztBQUNkLHVCQUFJLHdCQUFKLEVBQThCQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQS9DO0FBQ0EsYUFBT0UsT0FBTyxDQUFDQyxNQUFSLENBQWVILEtBQWYsQ0FBUDtBQUNEO0FBQ0Y7QUFFRDs7Ozs7OztBQUtBLFFBQWNsQixnQkFBZCxDQUErQmxCLE9BQS9CLEVBQXdDQyxPQUF4QyxFQUFnRXVDLFFBQWhFLEVBQW9GbkMsS0FBcEYsRUFBbUdvQyxLQUFLLEdBQUcsS0FBM0csRUFBa0g7QUFDaEgsVUFBTUMsVUFBVSxHQUFHLE1BQU0xQyxPQUFPLENBQUMyQyxJQUFSLENBQWFDLFVBQWIsQ0FBd0J0QixNQUF4QixDQUErQnVCLEdBQS9CLENBQW1DLFlBQW5DLENBQXpCO0FBQ0EsUUFBSSxDQUFDTCxRQUFELElBQWEsQ0FBQ0EsUUFBUSxDQUFDOUQsTUFBM0IsRUFBbUM7QUFDbkMscUJBQUksNEJBQUosRUFBbUMsR0FBRThELFFBQVEsQ0FBQzlELE1BQU8sbUJBQWtCMkIsS0FBTSxFQUE3RSxFQUFnRixNQUFoRjs7QUFDQSxRQUFJO0FBQ0YsVUFBSXlDLFNBQVMsR0FBRyxFQUFoQjs7QUFDQSxVQUFJTCxLQUFKLEVBQVc7QUFDVCxZQUFJO0FBQ0YsZ0JBQU1NLGNBQWMsR0FBRyxNQUFNL0MsT0FBTyxDQUFDb0IsS0FBUixDQUFjQyxHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUNDLE9BQXZDLENBQzNCLEtBRDJCLEVBRTFCLFdBQVVpQixLQUFNLFNBRlUsRUFHM0IsRUFIMkIsRUFJM0I7QUFBRWYsWUFBQUEsU0FBUyxFQUFFckI7QUFBYixXQUoyQixDQUE3QjtBQU1BLGdCQUFNMkMsVUFBVSxHQUNkRCxjQUFjLElBQ2RBLGNBQWMsQ0FBQ25CLElBRGYsSUFFQW1CLGNBQWMsQ0FBQ25CLElBQWYsQ0FBb0JBLElBRnBCLElBR0FtQixjQUFjLENBQUNuQixJQUFmLENBQW9CQSxJQUFwQixDQUF5QkMsY0FKM0I7QUFLQWlCLFVBQUFBLFNBQVMsR0FBRyxDQUFDRSxVQUFVLElBQUksRUFBZixFQUFtQmxELEdBQW5CLENBQXdCbUQsS0FBRCxLQUFZLEVBQzdDLEdBQUdBLEtBRDBDO0FBRTdDQyxZQUFBQSxPQUFPLEVBQUVELEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBSyxDQUFDRSxZQUZhO0FBRzdDQyxZQUFBQSxFQUFFLEVBQ0FILEtBQUssQ0FBQ0csRUFBTixJQUFZSCxLQUFLLENBQUNHLEVBQU4sQ0FBU0MsSUFBckIsSUFBNkJKLEtBQUssQ0FBQ0csRUFBTixDQUFTRSxPQUF0QyxHQUNLLEdBQUVMLEtBQUssQ0FBQ0csRUFBTixDQUFTQyxJQUFLLElBQUdKLEtBQUssQ0FBQ0csRUFBTixDQUFTRSxPQUFRLEVBRHpDLEdBRUk7QUFOdUMsV0FBWixDQUF2QixDQUFaO0FBUUQsU0FwQkQsQ0FvQkUsT0FBT2xCLEtBQVAsRUFBYztBQUNkLDJCQUNFLDRCQURGLEVBRUcsc0JBQXFCQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQU0sRUFGL0MsRUFHRSxPQUhGO0FBS0Q7QUFDRixPQTVCRCxNQTRCTztBQUNMLGFBQUssTUFBTW1CLE9BQVgsSUFBc0JmLFFBQXRCLEVBQWdDO0FBQzlCLGNBQUk7QUFDRixrQkFBTXJCLGFBQWEsR0FBRyxNQUFNbkIsT0FBTyxDQUFDb0IsS0FBUixDQUFjQyxHQUFkLENBQWtCQyxNQUFsQixDQUF5QkMsYUFBekIsQ0FBdUNDLE9BQXZDLENBQzFCLEtBRDBCLEVBRXpCLFNBRnlCLEVBRzFCO0FBQUVqQyxjQUFBQSxNQUFNLEVBQUU7QUFBRWlFLGdCQUFBQSxDQUFDLEVBQUcsTUFBS0QsT0FBUTtBQUFuQjtBQUFWLGFBSDBCLEVBSTFCO0FBQUU3QixjQUFBQSxTQUFTLEVBQUVyQjtBQUFiLGFBSjBCLENBQTVCO0FBTUEsa0JBQU0sQ0FBQzRDLEtBQUQsSUFBVTlCLGFBQWEsQ0FBQ1MsSUFBZCxDQUFtQkEsSUFBbkIsQ0FBd0JDLGNBQXhDO0FBQ0FpQixZQUFBQSxTQUFTLENBQUM3RCxJQUFWLENBQWUsRUFDYixHQUFHZ0UsS0FEVTtBQUViQyxjQUFBQSxPQUFPLEVBQUVELEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBSyxDQUFDRSxZQUZuQjtBQUdiQyxjQUFBQSxFQUFFLEVBQUdILEtBQUssQ0FBQ0csRUFBTixJQUFZSCxLQUFLLENBQUNHLEVBQU4sQ0FBU0MsSUFBckIsSUFBNkJKLEtBQUssQ0FBQ0csRUFBTixDQUFTRSxPQUF2QyxHQUFtRCxHQUFFTCxLQUFLLENBQUNHLEVBQU4sQ0FBU0MsSUFBSyxJQUFHSixLQUFLLENBQUNHLEVBQU4sQ0FBU0UsT0FBUSxFQUF2RixHQUEyRixFQUhsRjtBQUliRyxjQUFBQSxhQUFhLEVBQUUscUJBQU9SLEtBQUssQ0FBQ1EsYUFBYixFQUE0QkMsTUFBNUIsQ0FBbUNoQixVQUFuQyxDQUpGO0FBS2JpQixjQUFBQSxPQUFPLEVBQUUscUJBQU9WLEtBQUssQ0FBQ1UsT0FBYixFQUFzQkQsTUFBdEIsQ0FBNkJoQixVQUE3QjtBQUxJLGFBQWY7QUFPRCxXQWZELENBZUUsT0FBT04sS0FBUCxFQUFjO0FBQ2QsNkJBQ0UsNEJBREYsRUFFRyxzQkFBcUJBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBTSxFQUYvQyxFQUdFLE9BSEY7QUFLRDtBQUNGO0FBQ0Y7O0FBQ0RuQyxNQUFBQSxPQUFPLENBQUMyRCxjQUFSLENBQXVCO0FBQ3JCQyxRQUFBQSxPQUFPLEVBQUUsQ0FDUDtBQUFFQyxVQUFBQSxFQUFFLEVBQUUsSUFBTjtBQUFZQyxVQUFBQSxLQUFLLEVBQUU7QUFBbkIsU0FETyxFQUVQO0FBQUVELFVBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNDLFVBQUFBLEtBQUssRUFBRTtBQUFyQixTQUZPLEVBR1A7QUFBRUQsVUFBQUEsRUFBRSxFQUFFLElBQU47QUFBWUMsVUFBQUEsS0FBSyxFQUFFO0FBQW5CLFNBSE8sRUFJUDtBQUFFRCxVQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQkMsVUFBQUEsS0FBSyxFQUFFO0FBQXhCLFNBSk8sRUFLUDtBQUFFRCxVQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQkMsVUFBQUEsS0FBSyxFQUFFO0FBQXhCLFNBTE8sRUFNUDtBQUFFRCxVQUFBQSxFQUFFLEVBQUUsSUFBTjtBQUFZQyxVQUFBQSxLQUFLLEVBQUU7QUFBbkIsU0FOTyxFQU9QO0FBQUVELFVBQUFBLEVBQUUsRUFBRSxTQUFOO0FBQWlCQyxVQUFBQSxLQUFLLEVBQUU7QUFBeEIsU0FQTyxFQVFQO0FBQUVELFVBQUFBLEVBQUUsRUFBRSxlQUFOO0FBQXVCQyxVQUFBQSxLQUFLLEVBQUU7QUFBOUIsU0FSTyxDQURZO0FBV3JCQyxRQUFBQSxLQUFLLEVBQUVsQjtBQVhjLE9BQXZCO0FBYUQsS0FyRUQsQ0FxRUUsT0FBT1YsS0FBUCxFQUFjO0FBQ2QsdUJBQUksNEJBQUosRUFBa0NBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBbkQ7QUFDQSxhQUFPRSxPQUFPLENBQUNDLE1BQVIsQ0FBZUgsS0FBZixDQUFQO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7Ozs7Ozs7Ozs7O0FBY0EsUUFBYzZCLG1CQUFkLENBQ0VqRSxPQURGLEVBRUVDLE9BRkYsRUFHRUMsT0FIRixFQUlFQyxHQUpGLEVBS0VFLEtBTEYsRUFNRTZELElBTkYsRUFPRUMsRUFQRixFQVFFM0YsT0FSRixFQVNFNEYsT0FBTyxHQUFHQywrQkFUWixFQVVFcEIsS0FBSyxHQUFHLElBVlYsRUFXRTtBQUNBLFFBQUk7QUFDRix1QkFDRSwrQkFERixFQUVHLFdBQVUvQyxPQUFRLFlBQVdDLEdBQUksWUFBV0UsS0FBTSxVQUFTNkQsSUFBSyxPQUFNQyxFQUFHLGFBQVkzRixPQUFRLG1CQUFrQjRGLE9BQVEsRUFGMUgsRUFHRSxNQUhGOztBQUtBLFVBQUlsRSxPQUFPLEtBQUssUUFBWixJQUF3QixDQUFDK0MsS0FBN0IsRUFBb0M7QUFDbEMsY0FBTSxJQUFJcUIsS0FBSixDQUFVLDBFQUFWLENBQU47QUFDRDs7QUFFRCxZQUFNQyxNQUFNLEdBQUcsTUFBTXZFLE9BQU8sQ0FBQ29CLEtBQVIsQ0FBY0MsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJDLGFBQXpCLENBQXVDQyxPQUF2QyxDQUNuQixLQURtQixFQUVuQixTQUZtQixFQUduQjtBQUFFakMsUUFBQUEsTUFBTSxFQUFFO0FBQUVpRixVQUFBQSxLQUFLLEVBQUU7QUFBVDtBQUFWLE9BSG1CLEVBSW5CO0FBQUU5QyxRQUFBQSxTQUFTLEVBQUVyQjtBQUFiLE9BSm1CLENBQXJCO0FBT0EsWUFBTW9FLFdBQVcsR0FBR0YsTUFBTSxDQUFDM0MsSUFBUCxDQUFZQSxJQUFaLENBQWlCOEMsb0JBQXJDOztBQUVBLFVBQUl4RSxPQUFPLEtBQUssVUFBWixJQUEwQkMsR0FBRyxLQUFLLE1BQXRDLEVBQThDO0FBQzVDLHlCQUNFLCtCQURGLEVBRUUsa0RBRkYsRUFHRSxPQUhGO0FBS0EsY0FBTXdFLHFCQUFxQixHQUFHLENBQUMsS0FBRCxFQUFRLFFBQVIsRUFBa0IsTUFBbEIsRUFBMEIsVUFBMUIsQ0FBOUI7QUFFQSxjQUFNQyw2QkFBNkIsR0FBRyxDQUNwQyxNQUFNdEMsT0FBTyxDQUFDdUMsR0FBUixDQUNKRixxQkFBcUIsQ0FBQzdFLEdBQXRCLENBQTBCLE1BQU9nRixvQkFBUCxJQUFnQztBQUN4RCxjQUFJO0FBQ0Ysa0JBQU1DLEtBQUssR0FBRyxNQUFNQyxvQkFBb0IsQ0FBQ0MsbUJBQXJCLENBQ2xCakYsT0FEa0IsRUFFbEJrRSxJQUZrQixFQUdsQkMsRUFIa0IsRUFJbEJXLG9CQUprQixFQUtsQnRHLE9BTGtCLEVBTWxCNEYsT0FOa0IsQ0FBcEI7QUFRQSxtQkFBT1csS0FBSyxHQUNQLEdBQUVBLEtBQU0sT0FBTU4sV0FBWSxnQkFBZUssb0JBQW9CLENBQUNJLGlCQUFyQixFQUF5QyxtQkFEM0UsR0FFUkMsU0FGSjtBQUdELFdBWkQsQ0FZRSxPQUFPL0MsS0FBUCxFQUFjLENBQUU7QUFDbkIsU0FkRCxDQURJLENBRDhCLEVBa0JwQ3ZELE1BbEJvQyxDQWtCNUJ1Ryx1QkFBRCxJQUE2QkEsdUJBbEJBLENBQXRDO0FBb0JBbkYsUUFBQUEsT0FBTyxDQUFDb0YsT0FBUixDQUFnQjtBQUNkM0UsVUFBQUEsS0FBSyxFQUFFO0FBQUVGLFlBQUFBLElBQUksRUFBRSxTQUFSO0FBQW1CRyxZQUFBQSxLQUFLLEVBQUU7QUFBMUIsV0FETztBQUVkMkUsVUFBQUEsSUFBSSxFQUFFVjtBQUZRLFNBQWhCO0FBS0EseUJBQ0UsK0JBREYsRUFFRSxtRUFGRixFQUdFLE9BSEY7QUFLQSxjQUFNVyxPQUFPLEdBQUcsTUFBTVAsb0JBQW9CLENBQUNRLGFBQXJCLENBQ3BCeEYsT0FEb0IsRUFFcEJrRSxJQUZvQixFQUdwQkMsRUFIb0IsRUFJcEIsS0FKb0IsRUFLcEIzRixPQUxvQixFQU1wQjRGLE9BTm9CLENBQXRCO0FBUUEsY0FBTXFCLFVBQVUsR0FBRyxNQUFNVCxvQkFBb0IsQ0FBQ1EsYUFBckIsQ0FDdkJ4RixPQUR1QixFQUV2QmtFLElBRnVCLEVBR3ZCQyxFQUh1QixFQUl2QixRQUp1QixFQUt2QjNGLE9BTHVCLEVBTXZCNEYsT0FOdUIsQ0FBekI7QUFRQSxjQUFNc0IsUUFBUSxHQUFHLE1BQU1WLG9CQUFvQixDQUFDUSxhQUFyQixDQUNyQnhGLE9BRHFCLEVBRXJCa0UsSUFGcUIsRUFHckJDLEVBSHFCLEVBSXJCLE1BSnFCLEVBS3JCM0YsT0FMcUIsRUFNckI0RixPQU5xQixDQUF2QjtBQVFBLGNBQU11QixZQUFZLEdBQUcsTUFBTVgsb0JBQW9CLENBQUNRLGFBQXJCLENBQ3pCeEYsT0FEeUIsRUFFekJrRSxJQUZ5QixFQUd6QkMsRUFIeUIsRUFJekIsVUFKeUIsRUFLekIzRixPQUx5QixFQU16QjRGLE9BTnlCLENBQTNCO0FBUUEseUJBQ0UsK0JBREYsRUFFRSxpRUFGRixFQUdFLE9BSEY7O0FBS0EsWUFBSXVCLFlBQVksSUFBSUEsWUFBWSxDQUFDakgsTUFBakMsRUFBeUM7QUFDdkN1QixVQUFBQSxPQUFPLENBQUM4QixxQkFBUixDQUE4QjtBQUM1QnZCLFlBQUFBLElBQUksRUFBRSxxREFEc0I7QUFFNUJHLFlBQUFBLEtBQUssRUFBRTtBQUZxQixXQUE5QjtBQUlBLGdCQUFNLEtBQUtPLGdCQUFMLENBQXNCbEIsT0FBdEIsRUFBK0JDLE9BQS9CLEVBQXdDMEYsWUFBeEMsRUFBc0R0RixLQUF0RCxDQUFOO0FBQ0FKLFVBQUFBLE9BQU8sQ0FBQ2dCLFVBQVI7QUFDRDs7QUFFRCxZQUFJeUUsUUFBUSxJQUFJQSxRQUFRLENBQUNoSCxNQUF6QixFQUFpQztBQUMvQnVCLFVBQUFBLE9BQU8sQ0FBQzhCLHFCQUFSLENBQThCO0FBQzVCdkIsWUFBQUEsSUFBSSxFQUFFLGlEQURzQjtBQUU1QkcsWUFBQUEsS0FBSyxFQUFFO0FBRnFCLFdBQTlCO0FBSUEsZ0JBQU0sS0FBS08sZ0JBQUwsQ0FBc0JsQixPQUF0QixFQUErQkMsT0FBL0IsRUFBd0N5RixRQUF4QyxFQUFrRHJGLEtBQWxELENBQU47QUFDQUosVUFBQUEsT0FBTyxDQUFDZ0IsVUFBUjtBQUNEOztBQUVELFlBQUl3RSxVQUFVLElBQUlBLFVBQVUsQ0FBQy9HLE1BQTdCLEVBQXFDO0FBQ25DdUIsVUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFDNUJ2QixZQUFBQSxJQUFJLEVBQUUsbURBRHNCO0FBRTVCRyxZQUFBQSxLQUFLLEVBQUU7QUFGcUIsV0FBOUI7QUFJQSxnQkFBTSxLQUFLTyxnQkFBTCxDQUFzQmxCLE9BQXRCLEVBQStCQyxPQUEvQixFQUF3Q3dGLFVBQXhDLEVBQW9EcEYsS0FBcEQsQ0FBTjtBQUNBSixVQUFBQSxPQUFPLENBQUNnQixVQUFSO0FBQ0Q7O0FBRUQsWUFBSXNFLE9BQU8sSUFBSUEsT0FBTyxDQUFDN0csTUFBdkIsRUFBK0I7QUFDN0J1QixVQUFBQSxPQUFPLENBQUM4QixxQkFBUixDQUE4QjtBQUM1QnZCLFlBQUFBLElBQUksRUFBRSxnREFEc0I7QUFFNUJHLFlBQUFBLEtBQUssRUFBRTtBQUZxQixXQUE5QjtBQUlBLGdCQUFNLEtBQUtPLGdCQUFMLENBQXNCbEIsT0FBdEIsRUFBK0JDLE9BQS9CLEVBQXdDc0YsT0FBeEMsRUFBaURsRixLQUFqRCxDQUFOO0FBQ0FKLFVBQUFBLE9BQU8sQ0FBQ2dCLFVBQVI7QUFDRDs7QUFFRCx5QkFDRSwrQkFERixFQUVFLHFEQUZGLEVBR0UsT0FIRjtBQUtBLGNBQU0yRSxPQUFPLEdBQUcsTUFBTVosb0JBQW9CLENBQUNhLFdBQXJCLENBQWlDN0YsT0FBakMsRUFBMENrRSxJQUExQyxFQUFnREMsRUFBaEQsRUFBb0QzRixPQUFwRCxFQUE2RDRGLE9BQTdELENBQXRCO0FBQ0EseUJBQ0UsK0JBREYsRUFFRSxtREFGRixFQUdFLE9BSEY7O0FBS0EsWUFBSXdCLE9BQU8sSUFBSUEsT0FBTyxDQUFDbEgsTUFBdkIsRUFBK0I7QUFDN0J1QixVQUFBQSxPQUFPLENBQUMyRCxjQUFSLENBQXVCO0FBQ3JCbEQsWUFBQUEsS0FBSyxFQUFFO0FBQUVGLGNBQUFBLElBQUksRUFBRSxXQUFSO0FBQXFCRyxjQUFBQSxLQUFLLEVBQUU7QUFBNUIsYUFEYztBQUVyQmtELFlBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQUVDLGNBQUFBLEVBQUUsRUFBRSxLQUFOO0FBQWFDLGNBQUFBLEtBQUssRUFBRTtBQUFwQixhQURPLEVBRVA7QUFBRUQsY0FBQUEsRUFBRSxFQUFFLEtBQU47QUFBYUMsY0FBQUEsS0FBSyxFQUFFO0FBQXBCLGFBRk8sQ0FGWTtBQU1yQkMsWUFBQUEsS0FBSyxFQUFFNEIsT0FBTyxDQUFDOUYsR0FBUixDQUFhZ0csSUFBRCxLQUFXO0FBQUVDLGNBQUFBLEdBQUcsRUFBRUgsT0FBTyxDQUFDSSxPQUFSLENBQWdCRixJQUFoQixJQUF3QixDQUEvQjtBQUFrQ0csY0FBQUEsR0FBRyxFQUFFSDtBQUF2QyxhQUFYLENBQVo7QUFOYyxXQUF2QjtBQVFEO0FBQ0Y7O0FBRUQsVUFBSTVGLE9BQU8sS0FBSyxVQUFaLElBQTBCQyxHQUFHLEtBQUssU0FBdEMsRUFBaUQ7QUFDL0MseUJBQUksK0JBQUosRUFBcUMsNENBQXJDLEVBQW1GLE9BQW5GO0FBRUEsY0FBTStGLFdBQVcsR0FBRyxNQUFNQyxlQUFlLENBQUNDLFVBQWhCLENBQTJCcEcsT0FBM0IsRUFBb0NrRSxJQUFwQyxFQUEwQ0MsRUFBMUMsRUFBOEMzRixPQUE5QyxFQUF1RDRGLE9BQXZELENBQTFCO0FBRUEseUJBQUksK0JBQUosRUFBcUMsMENBQXJDLEVBQWlGLE9BQWpGOztBQUNBLFlBQUk4QixXQUFXLENBQUN4SCxNQUFoQixFQUF3QjtBQUN0QnVCLFVBQUFBLE9BQU8sQ0FBQ00sVUFBUixDQUFtQjtBQUNqQkMsWUFBQUEsSUFBSSxFQUFFLG1DQURXO0FBRWpCRyxZQUFBQSxLQUFLLEVBQUU7QUFGVSxXQUFuQjtBQUlBLGdCQUFNLEtBQUtPLGdCQUFMLENBQXNCbEIsT0FBdEIsRUFBK0JDLE9BQS9CLEVBQXdDaUcsV0FBeEMsRUFBcUQ3RixLQUFyRCxDQUFOO0FBQ0Q7QUFDRjs7QUFFRCxVQUFJSCxPQUFPLEtBQUssVUFBWixJQUEwQkMsR0FBRyxLQUFLLElBQXRDLEVBQTRDO0FBQzFDLHlCQUFJLCtCQUFKLEVBQXFDLCtCQUFyQyxFQUFzRSxPQUF0RTtBQUNBLGNBQU1rRyxnQkFBZ0IsR0FBRyxNQUFNQyxnQkFBZ0IsQ0FBQ0Msb0JBQWpCLENBQzdCdkcsT0FENkIsRUFFN0JrRSxJQUY2QixFQUc3QkMsRUFINkIsRUFJN0IzRixPQUo2QixFQUs3QjRGLE9BTDZCLENBQS9CO0FBT0EseUJBQUksK0JBQUosRUFBcUMsNkJBQXJDLEVBQW9FLE9BQXBFOztBQUNBLFlBQUlpQyxnQkFBZ0IsSUFBSUEsZ0JBQWdCLENBQUMzSCxNQUF6QyxFQUFpRDtBQUMvQ3VCLFVBQUFBLE9BQU8sQ0FDSjhCLHFCQURILENBQ3lCO0FBQ3JCdkIsWUFBQUEsSUFBSSxFQUFFLDhDQURlO0FBRXJCRyxZQUFBQSxLQUFLLEVBQUU7QUFGYyxXQUR6QixFQUtHb0IscUJBTEgsQ0FLeUI7QUFDckJ2QixZQUFBQSxJQUFJLEVBQ0Ysb0lBRm1CO0FBR3JCRyxZQUFBQSxLQUFLLEVBQUU7QUFIYyxXQUx6QixFQVVHaUQsY0FWSCxDQVVrQjtBQUNkSSxZQUFBQSxLQUFLLEVBQUVxQyxnQkFBZ0IsQ0FBQ3ZHLEdBQWpCLENBQXNCZ0csSUFBRCxJQUFVO0FBQ3BDLHFCQUFPO0FBQUVDLGdCQUFBQSxHQUFHLEVBQUVNLGdCQUFnQixDQUFDTCxPQUFqQixDQUF5QkYsSUFBekIsSUFBaUMsQ0FBeEM7QUFBMkN6QyxnQkFBQUEsSUFBSSxFQUFFeUM7QUFBakQsZUFBUDtBQUNELGFBRk0sQ0FETztBQUlkakMsWUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRUMsY0FBQUEsRUFBRSxFQUFFLEtBQU47QUFBYUMsY0FBQUEsS0FBSyxFQUFFO0FBQXBCLGFBRE8sRUFFUDtBQUFFRCxjQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjQyxjQUFBQSxLQUFLLEVBQUU7QUFBckIsYUFGTztBQUpLLFdBVmxCO0FBbUJEOztBQUNELHlCQUFJLCtCQUFKLEVBQXFDLHNCQUFyQyxFQUE2RCxPQUE3RDtBQUNBLGNBQU15QyxVQUFVLEdBQUcsTUFBTUYsZ0JBQWdCLENBQUNHLG9CQUFqQixDQUN2QnpHLE9BRHVCLEVBRXZCa0UsSUFGdUIsRUFHdkJDLEVBSHVCLEVBSXZCM0YsT0FKdUIsRUFLdkI0RixPQUx1QixDQUF6QjtBQU9Bb0MsUUFBQUEsVUFBVSxJQUNSdkcsT0FBTyxDQUFDTSxVQUFSLENBQW1CO0FBQ2pCQyxVQUFBQSxJQUFJLEVBQUcsR0FBRWdHLFVBQVcsT0FBTS9CLFdBQVksK0JBRHJCO0FBRWpCOUQsVUFBQUEsS0FBSyxFQUFFO0FBRlUsU0FBbkIsQ0FERjtBQUtBLFNBQUM2RixVQUFELElBQ0V2RyxPQUFPLENBQUM4QixxQkFBUixDQUE4QjtBQUM1QnZCLFVBQUFBLElBQUksRUFBRyxpQ0FEcUI7QUFFNUJHLFVBQUFBLEtBQUssRUFBRTtBQUZxQixTQUE5QixDQURGO0FBTUEsY0FBTStGLFdBQVcsR0FBRyxNQUFNSixnQkFBZ0IsQ0FBQ0sscUJBQWpCLENBQ3hCM0csT0FEd0IsRUFFeEJrRSxJQUZ3QixFQUd4QkMsRUFId0IsRUFJeEIzRixPQUp3QixFQUt4QjRGLE9BTHdCLENBQTFCO0FBT0FzQyxRQUFBQSxXQUFXLElBQ1R6RyxPQUFPLENBQUNNLFVBQVIsQ0FBbUI7QUFDakJDLFVBQUFBLElBQUksRUFBRyxHQUFFa0csV0FBWSxPQUFNakMsV0FBWSwyQkFEdEI7QUFFakI5RCxVQUFBQSxLQUFLLEVBQUU7QUFGVSxTQUFuQixDQURGO0FBS0EsU0FBQytGLFdBQUQsSUFDRXpHLE9BQU8sQ0FBQ00sVUFBUixDQUFtQjtBQUNqQkMsVUFBQUEsSUFBSSxFQUFHLDZCQURVO0FBRWpCRyxVQUFBQSxLQUFLLEVBQUU7QUFGVSxTQUFuQixDQURGO0FBS0FWLFFBQUFBLE9BQU8sQ0FBQ2dCLFVBQVI7QUFDRDs7QUFFRCxVQUFJLENBQUMsVUFBRCxFQUFhLFFBQWIsRUFBdUJYLFFBQXZCLENBQWdDSixPQUFoQyxLQUE0Q0MsR0FBRyxLQUFLLEtBQXhELEVBQStEO0FBQzdELHlCQUFJLCtCQUFKLEVBQXFDLG1DQUFyQyxFQUEwRSxPQUExRTtBQUNBLGNBQU15RyxrQkFBa0IsR0FBRyxNQUFNQyxVQUFVLENBQUNDLGtCQUFYLENBQy9COUcsT0FEK0IsRUFFL0JrRSxJQUYrQixFQUcvQkMsRUFIK0IsRUFJL0IzRixPQUorQixFQUsvQjRGLE9BTCtCLENBQWpDO0FBT0FuRSxRQUFBQSxPQUFPLENBQUM4QixxQkFBUixDQUE4QjtBQUM1QnZCLFVBQUFBLElBQUksRUFBRSwrQ0FEc0I7QUFFNUJHLFVBQUFBLEtBQUssRUFBRTtBQUZxQixTQUE5Qjs7QUFJQSxhQUFLLE1BQU1tRixJQUFYLElBQW1CYyxrQkFBbkIsRUFBdUM7QUFDckMsZ0JBQU1HLEtBQUssR0FBRyxNQUFNRixVQUFVLENBQUNHLHFCQUFYLENBQ2xCaEgsT0FEa0IsRUFFbEJrRSxJQUZrQixFQUdsQkMsRUFIa0IsRUFJbEIzRixPQUprQixFQUtsQnNILElBTGtCLEVBTWxCMUIsT0FOa0IsQ0FBcEI7QUFRQW5FLFVBQUFBLE9BQU8sQ0FBQzhCLHFCQUFSLENBQThCO0FBQUV2QixZQUFBQSxJQUFJLEVBQUcsZUFBY3NGLElBQUssRUFBNUI7QUFBK0JuRixZQUFBQSxLQUFLLEVBQUU7QUFBdEMsV0FBOUI7O0FBRUEsY0FBSXNHLGdDQUFJbkIsSUFBSixDQUFKLEVBQWU7QUFDYixrQkFBTW9CLE9BQU8sR0FDWCxPQUFPRCxnQ0FBSW5CLElBQUosQ0FBUCxLQUFxQixRQUFyQixHQUFnQztBQUFFdEYsY0FBQUEsSUFBSSxFQUFFeUcsZ0NBQUluQixJQUFKLENBQVI7QUFBbUJuRixjQUFBQSxLQUFLLEVBQUU7QUFBMUIsYUFBaEMsR0FBeUVzRyxnQ0FBSW5CLElBQUosQ0FEM0U7QUFFQTdGLFlBQUFBLE9BQU8sQ0FBQzhCLHFCQUFSLENBQThCbUYsT0FBOUI7QUFDRDs7QUFFREgsVUFBQUEsS0FBSyxJQUNIQSxLQUFLLENBQUNySSxNQURSLElBRUV1QixPQUFPLENBQUMyRCxjQUFSLENBQXVCO0FBQ3JCQyxZQUFBQSxPQUFPLEVBQUUsQ0FDUDtBQUFFQyxjQUFBQSxFQUFFLEVBQUUsUUFBTjtBQUFnQkMsY0FBQUEsS0FBSyxFQUFFO0FBQXZCLGFBRE8sRUFFUDtBQUFFRCxjQUFBQSxFQUFFLEVBQUUsaUJBQU47QUFBeUJDLGNBQUFBLEtBQUssRUFBRTtBQUFoQyxhQUZPLENBRFk7QUFLckJDLFlBQUFBLEtBQUssRUFBRStDLEtBTGM7QUFNckJyRyxZQUFBQSxLQUFLLEVBQUcsaUJBQWdCb0YsSUFBSztBQU5SLFdBQXZCLENBRkY7QUFVRDtBQUNGOztBQUVELFVBQUksQ0FBQyxVQUFELEVBQWEsUUFBYixFQUF1QnhGLFFBQXZCLENBQWdDSixPQUFoQyxLQUE0Q0MsR0FBRyxLQUFLLEtBQXhELEVBQStEO0FBQzdELHlCQUFJLCtCQUFKLEVBQXFDLCtCQUFyQyxFQUFzRSxPQUF0RTtBQUNBLGNBQU1nSCxrQkFBa0IsR0FBRyxNQUFNQyxVQUFVLENBQUNELGtCQUFYLENBQy9CbkgsT0FEK0IsRUFFL0JrRSxJQUYrQixFQUcvQkMsRUFIK0IsRUFJL0IzRixPQUorQixFQUsvQjRGLE9BTCtCLENBQWpDO0FBT0FuRSxRQUFBQSxPQUFPLENBQUM4QixxQkFBUixDQUE4QjtBQUM1QnZCLFVBQUFBLElBQUksRUFBRSwyQ0FEc0I7QUFFNUJHLFVBQUFBLEtBQUssRUFBRTtBQUZxQixTQUE5Qjs7QUFJQSxhQUFLLE1BQU1tRixJQUFYLElBQW1CcUIsa0JBQW5CLEVBQXVDO0FBQ3JDLGdCQUFNSixLQUFLLEdBQUcsTUFBTUssVUFBVSxDQUFDSixxQkFBWCxDQUNsQmhILE9BRGtCLEVBRWxCa0UsSUFGa0IsRUFHbEJDLEVBSGtCLEVBSWxCM0YsT0FKa0IsRUFLbEJzSCxJQUxrQixFQU1sQjFCLE9BTmtCLENBQXBCO0FBUUFuRSxVQUFBQSxPQUFPLENBQUM4QixxQkFBUixDQUE4QjtBQUFFdkIsWUFBQUEsSUFBSSxFQUFHLGVBQWNzRixJQUFLLEVBQTVCO0FBQStCbkYsWUFBQUEsS0FBSyxFQUFFO0FBQXRDLFdBQTlCOztBQUVBLGNBQUkwRyxnQ0FBSXZCLElBQUosQ0FBSixFQUFlO0FBQ2Isa0JBQU1vQixPQUFPLEdBQ1gsT0FBT0csZ0NBQUl2QixJQUFKLENBQVAsS0FBcUIsUUFBckIsR0FBZ0M7QUFBRXRGLGNBQUFBLElBQUksRUFBRTZHLGdDQUFJdkIsSUFBSixDQUFSO0FBQW1CbkYsY0FBQUEsS0FBSyxFQUFFO0FBQTFCLGFBQWhDLEdBQXlFMEcsZ0NBQUl2QixJQUFKLENBRDNFO0FBRUE3RixZQUFBQSxPQUFPLENBQUM4QixxQkFBUixDQUE4Qm1GLE9BQTlCO0FBQ0Q7O0FBRURILFVBQUFBLEtBQUssSUFDSEEsS0FBSyxDQUFDckksTUFEUixJQUVFdUIsT0FBTyxDQUFDMkQsY0FBUixDQUF1QjtBQUNyQkMsWUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRUMsY0FBQUEsRUFBRSxFQUFFLFFBQU47QUFBZ0JDLGNBQUFBLEtBQUssRUFBRTtBQUF2QixhQURPLEVBRVA7QUFBRUQsY0FBQUEsRUFBRSxFQUFFLGlCQUFOO0FBQXlCQyxjQUFBQSxLQUFLLEVBQUU7QUFBaEMsYUFGTyxDQURZO0FBS3JCQyxZQUFBQSxLQUFLLEVBQUUrQyxLQUxjO0FBTXJCckcsWUFBQUEsS0FBSyxFQUFHLGlCQUFnQm9GLElBQUs7QUFOUixXQUF2QixDQUZGO0FBVUQ7QUFDRjs7QUFFRCxVQUFJLENBQUMsVUFBRCxFQUFhLFFBQWIsRUFBdUJ4RixRQUF2QixDQUFnQ0osT0FBaEMsS0FBNENDLEdBQUcsS0FBSyxNQUF4RCxFQUFnRTtBQUM5RCx5QkFBSSwrQkFBSixFQUFxQyxnQ0FBckMsRUFBdUUsT0FBdkU7QUFDQSxjQUFNbUgsbUJBQW1CLEdBQUcsTUFBTUMsV0FBVyxDQUFDQyxtQkFBWixDQUNoQ3hILE9BRGdDLEVBRWhDa0UsSUFGZ0MsRUFHaENDLEVBSGdDLEVBSWhDM0YsT0FKZ0MsRUFLaEM0RixPQUxnQyxDQUFsQztBQU9BbkUsUUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFDNUJ2QixVQUFBQSxJQUFJLEVBQUUsNENBRHNCO0FBRTVCRyxVQUFBQSxLQUFLLEVBQUU7QUFGcUIsU0FBOUI7O0FBSUEsYUFBSyxNQUFNbUYsSUFBWCxJQUFtQndCLG1CQUFuQixFQUF3QztBQUN0QyxnQkFBTVAsS0FBSyxHQUFHLE1BQU1RLFdBQVcsQ0FBQ1AscUJBQVosQ0FDbEJoSCxPQURrQixFQUVsQmtFLElBRmtCLEVBR2xCQyxFQUhrQixFQUlsQjNGLE9BSmtCLEVBS2xCc0gsSUFMa0IsRUFNbEIxQixPQU5rQixDQUFwQjtBQVFBbkUsVUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFBRXZCLFlBQUFBLElBQUksRUFBRyxlQUFjc0YsSUFBSyxFQUE1QjtBQUErQm5GLFlBQUFBLEtBQUssRUFBRTtBQUF0QyxXQUE5Qjs7QUFFQSxjQUFJOEcsb0NBQVFBLGlDQUFLM0IsSUFBTCxDQUFaLEVBQXdCO0FBQ3RCLGtCQUFNb0IsT0FBTyxHQUNYLE9BQU9PLGlDQUFLM0IsSUFBTCxDQUFQLEtBQXNCLFFBQXRCLEdBQWlDO0FBQUV0RixjQUFBQSxJQUFJLEVBQUVpSCxpQ0FBSzNCLElBQUwsQ0FBUjtBQUFvQm5GLGNBQUFBLEtBQUssRUFBRTtBQUEzQixhQUFqQyxHQUEyRThHLGlDQUFLM0IsSUFBTCxDQUQ3RTtBQUVBN0YsWUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEJtRixPQUE5QjtBQUNEOztBQUVESCxVQUFBQSxLQUFLLElBQ0hBLEtBQUssQ0FBQ3JJLE1BRFIsSUFFRXVCLE9BQU8sQ0FBQzJELGNBQVIsQ0FBdUI7QUFDckJDLFlBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQUVDLGNBQUFBLEVBQUUsRUFBRSxRQUFOO0FBQWdCQyxjQUFBQSxLQUFLLEVBQUU7QUFBdkIsYUFETyxFQUVQO0FBQUVELGNBQUFBLEVBQUUsRUFBRSxpQkFBTjtBQUF5QkMsY0FBQUEsS0FBSyxFQUFFO0FBQWhDLGFBRk8sQ0FEWTtBQUtyQkMsWUFBQUEsS0FBSyxFQUFFK0MsS0FMYztBQU1yQnJHLFlBQUFBLEtBQUssRUFBRyxpQkFBZ0JvRixJQUFLO0FBTlIsV0FBdkIsQ0FGRjtBQVVEOztBQUNEN0YsUUFBQUEsT0FBTyxDQUFDZ0IsVUFBUjtBQUNEOztBQUVELFVBQUlmLE9BQU8sS0FBSyxVQUFaLElBQTBCQyxHQUFHLEtBQUssT0FBdEMsRUFBK0M7QUFDN0MseUJBQ0UsK0JBREYsRUFFRSwwREFGRixFQUdFLE9BSEY7QUFLQSxjQUFNdUgscUJBQXFCLEdBQUcsTUFBTUMsWUFBWSxDQUFDQyw4QkFBYixDQUNsQzVILE9BRGtDLEVBRWxDa0UsSUFGa0MsRUFHbENDLEVBSGtDLEVBSWxDM0YsT0FKa0MsRUFLbEM0RixPQUxrQyxDQUFwQzs7QUFPQSxZQUFJc0QscUJBQXFCLElBQUlBLHFCQUFxQixDQUFDaEosTUFBbkQsRUFBMkQ7QUFDekR1QixVQUFBQSxPQUFPLENBQUNNLFVBQVIsQ0FBbUI7QUFDakJDLFlBQUFBLElBQUksRUFBRSxpREFEVztBQUVqQkcsWUFBQUEsS0FBSyxFQUFFO0FBRlUsV0FBbkI7QUFJQSxnQkFBTSxLQUFLTyxnQkFBTCxDQUFzQmxCLE9BQXRCLEVBQStCQyxPQUEvQixFQUF3Q3lILHFCQUF4QyxFQUErRHJILEtBQS9ELENBQU47QUFDRDs7QUFDRCxjQUFNd0gsd0JBQXdCLEdBQUcsTUFBTUYsWUFBWSxDQUFDRywyQkFBYixDQUNyQzlILE9BRHFDLEVBRXJDa0UsSUFGcUMsRUFHckNDLEVBSHFDLEVBSXJDM0YsT0FKcUMsRUFLckM0RixPQUxxQyxDQUF2Qzs7QUFPQSxZQUFJeUQsd0JBQXdCLElBQUlBLHdCQUF3QixDQUFDbkosTUFBekQsRUFBaUU7QUFDL0R1QixVQUFBQSxPQUFPLENBQUMyRCxjQUFSLENBQXVCO0FBQ3JCQyxZQUFBQSxPQUFPLEVBQUUsQ0FDUDtBQUFFQyxjQUFBQSxFQUFFLEVBQUUsT0FBTjtBQUFlQyxjQUFBQSxLQUFLLEVBQUU7QUFBdEIsYUFETyxFQUVQO0FBQUVELGNBQUFBLEVBQUUsRUFBRSxZQUFOO0FBQW9CQyxjQUFBQSxLQUFLLEVBQUU7QUFBM0IsYUFGTyxFQUdQO0FBQUVELGNBQUFBLEVBQUUsRUFBRSxpQkFBTjtBQUF5QkMsY0FBQUEsS0FBSyxFQUFFO0FBQWhDLGFBSE8sQ0FEWTtBQU1yQkMsWUFBQUEsS0FBSyxFQUFFNkQsd0JBQXdCLENBQUMvSCxHQUF6QixDQUE4QmdHLElBQUQsS0FBVztBQUM3QzdDLGNBQUFBLEtBQUssRUFBRTZDLElBQUksQ0FBQzdDLEtBRGlDO0FBRTdDOEUsY0FBQUEsVUFBVSxFQUFFakMsSUFBSSxDQUFDa0MsT0FBTCxDQUFhbEUsRUFGb0I7QUFHN0NtRSxjQUFBQSxlQUFlLEVBQUVuQyxJQUFJLENBQUNrQyxPQUFMLENBQWFBO0FBSGUsYUFBWCxDQUE3QixDQU5jO0FBV3JCdEgsWUFBQUEsS0FBSyxFQUFFO0FBQ0xGLGNBQUFBLElBQUksRUFBRSw4QkFERDtBQUVMRyxjQUFBQSxLQUFLLEVBQUU7QUFGRjtBQVhjLFdBQXZCO0FBZ0JEO0FBQ0Y7O0FBRUQsVUFBSVQsT0FBTyxLQUFLLFVBQVosSUFBMEJDLEdBQUcsS0FBSyxLQUF0QyxFQUE2QztBQUMzQyx5QkFBSSwrQkFBSixFQUFxQyw4QkFBckMsRUFBcUUsT0FBckU7QUFDQSxjQUFNNEcsS0FBSyxHQUFHLE1BQU1tQixlQUFlLENBQUNDLFNBQWhCLENBQTBCbkksT0FBMUIsRUFBbUNrRSxJQUFuQyxFQUF5Q0MsRUFBekMsRUFBNkMzRixPQUE3QyxFQUFzRDRGLE9BQXRELENBQXBCOztBQUVBLFlBQUkyQyxLQUFLLElBQUlBLEtBQUssQ0FBQ3JJLE1BQW5CLEVBQTJCO0FBQ3pCdUIsVUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFBRXZCLFlBQUFBLElBQUksRUFBRSxpQkFBUjtBQUEyQkcsWUFBQUEsS0FBSyxFQUFFO0FBQWxDLFdBQTlCLEVBQXdFaUQsY0FBeEUsQ0FBdUY7QUFDckZDLFlBQUFBLE9BQU8sRUFBRSxDQUNQO0FBQUVDLGNBQUFBLEVBQUUsRUFBRSxRQUFOO0FBQWdCQyxjQUFBQSxLQUFLLEVBQUU7QUFBdkIsYUFETyxFQUVQO0FBQUVELGNBQUFBLEVBQUUsRUFBRSxpQkFBTjtBQUF5QkMsY0FBQUEsS0FBSyxFQUFFO0FBQWhDLGFBRk8sQ0FENEU7QUFLckZDLFlBQUFBLEtBQUssRUFBRStDLEtBTDhFO0FBTXJGckcsWUFBQUEsS0FBSyxFQUFFO0FBQ0xGLGNBQUFBLElBQUksRUFBRSw4Q0FERDtBQUVMRyxjQUFBQSxLQUFLLEVBQUU7QUFGRjtBQU44RSxXQUF2RjtBQVdEOztBQUVELHlCQUFJLCtCQUFKLEVBQXFDLCtCQUFyQyxFQUFzRSxPQUF0RTtBQUNBLGNBQU00RCxNQUFNLEdBQUcsTUFBTTJELGVBQWUsQ0FBQ0UsVUFBaEIsQ0FBMkJwSSxPQUEzQixFQUFvQ2tFLElBQXBDLEVBQTBDQyxFQUExQyxFQUE4QzNGLE9BQTlDLEVBQXVENEYsT0FBdkQsQ0FBckI7O0FBRUEsWUFBSUcsTUFBTSxJQUFJQSxNQUFNLENBQUM3RixNQUFyQixFQUE2QjtBQUMzQnVCLFVBQUFBLE9BQU8sQ0FBQzhCLHFCQUFSLENBQThCO0FBQzVCdkIsWUFBQUEsSUFBSSxFQUFFLHFDQURzQjtBQUU1QkcsWUFBQUEsS0FBSyxFQUFFO0FBRnFCLFdBQTlCO0FBSUFWLFVBQUFBLE9BQU8sQ0FBQzhCLHFCQUFSLENBQThCO0FBQzVCdkIsWUFBQUEsSUFBSSxFQUNGLHdGQUYwQjtBQUc1QkcsWUFBQUEsS0FBSyxFQUFFO0FBSHFCLFdBQTlCO0FBS0EsZ0JBQU0sS0FBS08sZ0JBQUwsQ0FBc0JsQixPQUF0QixFQUErQkMsT0FBL0IsRUFBd0NzRSxNQUF4QyxFQUFnRGxFLEtBQWhELENBQU47QUFDRDtBQUNGOztBQUVELFVBQUlILE9BQU8sS0FBSyxRQUFaLElBQXdCQyxHQUFHLEtBQUssT0FBcEMsRUFBNkM7QUFDM0MseUJBQUksK0JBQUosRUFBc0Msc0NBQXRDLEVBQTZFLE9BQTdFO0FBQ0EsY0FBTWtJLGtCQUFrQixHQUFHLE1BQU1WLFlBQVksQ0FBQ1csb0JBQWIsQ0FDL0J0SSxPQUQrQixFQUUvQmtFLElBRitCLEVBRy9CQyxFQUgrQixFQUkvQjNGLE9BSitCLEVBSy9CNEYsT0FMK0IsQ0FBakM7QUFPQWlFLFFBQUFBLGtCQUFrQixJQUNoQkEsa0JBQWtCLENBQUMzSixNQURyQixJQUVFdUIsT0FBTyxDQUFDMkQsY0FBUixDQUF1QjtBQUNyQkMsVUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRUMsWUFBQUEsRUFBRSxFQUFFLElBQU47QUFBWUMsWUFBQUEsS0FBSyxFQUFFO0FBQW5CLFdBRE8sRUFFUDtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCLFdBRk8sQ0FEWTtBQUtyQkMsVUFBQUEsS0FBSyxFQUFFcUUsa0JBTGM7QUFNckIzSCxVQUFBQSxLQUFLLEVBQUU7QUFOYyxTQUF2QixDQUZGO0FBVUQ7O0FBRUQsVUFBSVIsT0FBTyxLQUFLLFFBQVosSUFBd0JDLEdBQUcsS0FBSyxLQUFwQyxFQUEyQztBQUN6Qyx5QkFDRSwrQkFERixFQUVHLHdDQUF1QzhDLEtBQU0sRUFGaEQsRUFHRSxPQUhGO0FBTUEsY0FBTXNGLGdCQUFnQixHQUFHLE1BQU12SSxPQUFPLENBQUNvQixLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Q0MsT0FBdkMsQ0FDN0IsS0FENkIsRUFFNUIsYUFBWXlCLEtBQU0sWUFGVSxFQUc3QixFQUg2QixFQUk3QjtBQUFFdkIsVUFBQUEsU0FBUyxFQUFFckI7QUFBYixTQUo2QixDQUEvQjs7QUFPQSxZQUFJa0ksZ0JBQWdCLElBQUlBLGdCQUFnQixDQUFDM0csSUFBekMsRUFBK0M7QUFDN0MsZ0JBQU00RyxZQUFZLEdBQUdELGdCQUFnQixDQUFDM0csSUFBakIsQ0FBc0JBLElBQXRCLENBQTJCQyxjQUEzQixDQUEwQyxDQUExQyxDQUFyQjs7QUFDQSxjQUFJMkcsWUFBWSxDQUFDQyxLQUFiLElBQXNCRCxZQUFZLENBQUNFLEdBQXZDLEVBQTRDO0FBQzFDekksWUFBQUEsT0FBTyxDQUFDTSxVQUFSLENBQW1CO0FBQ2pCQyxjQUFBQSxJQUFJLEVBQUcseURBQXdEZ0ksWUFBWSxDQUFDQyxLQUFNLE9BQU1ELFlBQVksQ0FBQ0UsR0FBSTtBQUR4RixhQUFuQjtBQUdELFdBSkQsTUFJTyxJQUFJRixZQUFZLENBQUNDLEtBQWpCLEVBQXdCO0FBQzdCeEksWUFBQUEsT0FBTyxDQUFDTSxVQUFSLENBQW1CO0FBQ2pCQyxjQUFBQSxJQUFJLEVBQUcsc0ZBQXFGZ0ksWUFBWSxDQUFDQyxLQUFNO0FBRDlGLGFBQW5CO0FBR0QsV0FKTSxNQUlBO0FBQ0x4SSxZQUFBQSxPQUFPLENBQUNNLFVBQVIsQ0FBbUI7QUFDakJDLGNBQUFBLElBQUksRUFBRztBQURVLGFBQW5CO0FBR0Q7O0FBQ0RQLFVBQUFBLE9BQU8sQ0FBQ2dCLFVBQVI7QUFDRDs7QUFFRCx5QkFBSSwrQkFBSixFQUFzQyx3Q0FBdEMsRUFBK0UsT0FBL0U7QUFDQSxjQUFNMEgsY0FBYyxHQUFHLE1BQU1ULGVBQWUsQ0FBQ1UsbUJBQWhCLENBQzNCNUksT0FEMkIsRUFFM0JrRSxJQUYyQixFQUczQkMsRUFIMkIsRUFJM0IzRixPQUoyQixFQUszQjRGLE9BTDJCLENBQTdCO0FBUUF1RSxRQUFBQSxjQUFjLElBQ1pBLGNBQWMsQ0FBQ2pLLE1BRGpCLElBRUV1QixPQUFPLENBQUMyRCxjQUFSLENBQXVCO0FBQ3JCQyxVQUFBQSxPQUFPLEVBQUUsQ0FDUDtBQUFFQyxZQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjQyxZQUFBQSxLQUFLLEVBQUU7QUFBckIsV0FETyxFQUVQO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNDLFlBQUFBLEtBQUssRUFBRTtBQUFyQixXQUZPLENBRFk7QUFLckJDLFVBQUFBLEtBQUssRUFBRTJFLGNBTGM7QUFNckJqSSxVQUFBQSxLQUFLLEVBQUU7QUFOYyxTQUF2QixDQUZGO0FBV0EseUJBQUksK0JBQUosRUFBc0MsaUNBQXRDLEVBQXdFLE9BQXhFO0FBQ0EsY0FBTW1JLGVBQWUsR0FBRyxNQUFNWCxlQUFlLENBQUNZLG9CQUFoQixDQUM1QjlJLE9BRDRCLEVBRTVCa0UsSUFGNEIsRUFHNUJDLEVBSDRCLEVBSTVCM0YsT0FKNEIsRUFLNUI0RixPQUw0QixDQUE5QjtBQVFBeUUsUUFBQUEsZUFBZSxJQUNiQSxlQUFlLENBQUNuSyxNQURsQixJQUVFdUIsT0FBTyxDQUFDMkQsY0FBUixDQUF1QjtBQUNyQkMsVUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRUMsWUFBQUEsRUFBRSxFQUFFLE1BQU47QUFBY0MsWUFBQUEsS0FBSyxFQUFFO0FBQXJCLFdBRE8sRUFFUDtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjQyxZQUFBQSxLQUFLLEVBQUU7QUFBckIsV0FGTyxDQURZO0FBS3JCQyxVQUFBQSxLQUFLLEVBQUU2RSxlQUxjO0FBTXJCbkksVUFBQUEsS0FBSyxFQUFFO0FBTmMsU0FBdkIsQ0FGRjtBQVVEOztBQUVELFVBQUlSLE9BQU8sS0FBSyxRQUFaLElBQXdCQyxHQUFHLEtBQUssY0FBcEMsRUFBb0Q7QUFDbEQseUJBQ0UsK0JBREYsRUFFRywyQ0FBMEM4QyxLQUFNLEVBRm5ELEVBR0UsT0FIRjtBQUtBLGNBQU04Rix5QkFBeUIsR0FBRyxDQUNoQztBQUNFQyxVQUFBQSxRQUFRLEVBQUcsaUJBQWdCL0YsS0FBTSxXQURuQztBQUVFZ0csVUFBQUEsYUFBYSxFQUFHLDJDQUEwQ2hHLEtBQU0sRUFGbEU7QUFHRXFDLFVBQUFBLElBQUksRUFBRTtBQUNKNUUsWUFBQUEsS0FBSyxFQUFFO0FBQUVGLGNBQUFBLElBQUksRUFBRSxzQkFBUjtBQUFnQ0csY0FBQUEsS0FBSyxFQUFFO0FBQXZDO0FBREgsV0FIUjtBQU1FdUksVUFBQUEsV0FBVyxFQUFHQyxRQUFELElBQWMsQ0FDekJBLFFBQVEsQ0FBQ0MsR0FBVCxJQUFnQkQsUUFBUSxDQUFDQyxHQUFULENBQWFDLEtBQTdCLElBQXVDLEdBQUVGLFFBQVEsQ0FBQ0MsR0FBVCxDQUFhQyxLQUFNLFFBRG5DLEVBRXpCRixRQUFRLENBQUNDLEdBQVQsSUFBZ0JELFFBQVEsQ0FBQ0MsR0FBVCxDQUFhL0YsSUFGSixFQUd6QjhGLFFBQVEsQ0FBQ0csR0FBVCxJQUNFSCxRQUFRLENBQUNHLEdBQVQsQ0FBYUMsS0FEZixJQUVHLEdBQUVDLE1BQU0sQ0FBQ0wsUUFBUSxDQUFDRyxHQUFULENBQWFDLEtBQWIsR0FBcUIsSUFBckIsR0FBNEIsSUFBN0IsQ0FBTixDQUF5Q0UsT0FBekMsQ0FBaUQsQ0FBakQsQ0FBb0QsUUFMaEM7QUFON0IsU0FEZ0MsRUFlaEM7QUFDRVQsVUFBQUEsUUFBUSxFQUFHLGlCQUFnQi9GLEtBQU0sS0FEbkM7QUFFRWdHLFVBQUFBLGFBQWEsRUFBRyxxQ0FBb0NoRyxLQUFNLEVBRjVEO0FBR0VxQyxVQUFBQSxJQUFJLEVBQUU7QUFDSjVFLFlBQUFBLEtBQUssRUFBRTtBQUFFRixjQUFBQSxJQUFJLEVBQUUsZ0JBQVI7QUFBMEJHLGNBQUFBLEtBQUssRUFBRTtBQUFqQztBQURILFdBSFI7QUFNRXVJLFVBQUFBLFdBQVcsRUFBR1EsTUFBRCxJQUFZLENBQ3ZCQSxNQUFNLENBQUNDLE9BRGdCLEVBRXZCRCxNQUFNLENBQUNwRyxPQUZnQixFQUd2Qm9HLE1BQU0sQ0FBQ0UsWUFIZ0IsRUFJdkJGLE1BQU0sQ0FBQ0csT0FKZ0IsRUFLdkJILE1BQU0sQ0FBQ3RHLEVBQVAsSUFDRXNHLE1BQU0sQ0FBQ3RHLEVBQVAsQ0FBVUMsSUFEWixJQUVFcUcsTUFBTSxDQUFDdEcsRUFBUCxDQUFVRSxPQUZaLElBR0csR0FBRW9HLE1BQU0sQ0FBQ3RHLEVBQVAsQ0FBVUMsSUFBSyxJQUFHcUcsTUFBTSxDQUFDdEcsRUFBUCxDQUFVRSxPQUFRLEVBUmxCO0FBTjNCLFNBZmdDLENBQWxDO0FBa0NBLGNBQU13RyxpQkFBaUIsR0FBRyxNQUFNeEgsT0FBTyxDQUFDdUMsR0FBUixDQUM5QmtFLHlCQUF5QixDQUFDakosR0FBMUIsQ0FBOEIsTUFBT2lLLG1CQUFQLElBQStCO0FBQzNELGNBQUk7QUFDRiw2QkFBSSwrQkFBSixFQUFxQ0EsbUJBQW1CLENBQUNkLGFBQXpELEVBQXdFLE9BQXhFO0FBQ0Esa0JBQU1lLG9CQUFvQixHQUFHLE1BQU1oSyxPQUFPLENBQUNvQixLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Q0MsT0FBdkMsQ0FDakMsS0FEaUMsRUFFakN1SSxtQkFBbUIsQ0FBQ2YsUUFGYSxFQUdqQyxFQUhpQyxFQUlqQztBQUFFdEgsY0FBQUEsU0FBUyxFQUFFckI7QUFBYixhQUppQyxDQUFuQztBQU1BLGtCQUFNLENBQUN1QixJQUFELElBQ0hvSSxvQkFBb0IsSUFDbkJBLG9CQUFvQixDQUFDcEksSUFEdEIsSUFFQ29JLG9CQUFvQixDQUFDcEksSUFBckIsQ0FBMEJBLElBRjNCLElBR0NvSSxvQkFBb0IsQ0FBQ3BJLElBQXJCLENBQTBCQSxJQUExQixDQUErQkMsY0FIakMsSUFJQSxFQUxGOztBQU1BLGdCQUFJRCxJQUFKLEVBQVU7QUFDUixxQkFBTyxFQUNMLEdBQUdtSSxtQkFBbUIsQ0FBQ3pFLElBRGxCO0FBRUxBLGdCQUFBQSxJQUFJLEVBQUV5RSxtQkFBbUIsQ0FBQ2IsV0FBcEIsQ0FBZ0N0SCxJQUFoQztBQUZELGVBQVA7QUFJRDtBQUNGLFdBcEJELENBb0JFLE9BQU9RLEtBQVAsRUFBYztBQUNkLDZCQUFJLCtCQUFKLEVBQXFDQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQXREO0FBQ0Q7QUFDRixTQXhCRCxDQUQ4QixDQUFoQzs7QUE0QkEsWUFBSTBILGlCQUFKLEVBQXVCO0FBQ3JCQSxVQUFBQSxpQkFBaUIsQ0FDZGpMLE1BREgsQ0FDV29MLGdCQUFELElBQXNCQSxnQkFEaEMsRUFFR0MsT0FGSCxDQUVZRCxnQkFBRCxJQUFzQmhLLE9BQU8sQ0FBQ29GLE9BQVIsQ0FBZ0I0RSxnQkFBaEIsQ0FGakM7QUFHRDs7QUFFRCxjQUFNRSx1QkFBdUIsR0FBRyxDQUFDLFVBQUQsRUFBYSxNQUFiLENBQWhDO0FBRUEsY0FBTUMsNkJBQTZCLEdBQUcsQ0FDcEMsTUFBTTlILE9BQU8sQ0FBQ3VDLEdBQVIsQ0FDSnNGLHVCQUF1QixDQUFDckssR0FBeEIsQ0FBNEIsTUFBT2dGLG9CQUFQLElBQWdDO0FBQzFELGNBQUk7QUFDRiw2QkFDRSwrQkFERixFQUVHLGdCQUFlQSxvQkFBcUIsV0FGdkMsRUFHRSxPQUhGO0FBTUEsbUJBQU8sTUFBTUUsb0JBQW9CLENBQUNxRixXQUFyQixDQUNYckssT0FEVyxFQUVYa0UsSUFGVyxFQUdYQyxFQUhXLEVBSVhXLG9CQUpXLEVBS1h0RyxPQUxXLEVBTVg0RixPQU5XLENBQWI7QUFRRCxXQWZELENBZUUsT0FBT2hDLEtBQVAsRUFBYztBQUNkLDZCQUFJLCtCQUFKLEVBQXFDQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQXREO0FBQ0Q7QUFDRixTQW5CRCxDQURJLENBRDhCLEVBd0JuQ3ZELE1BeEJtQyxDQXdCM0J1Ryx1QkFBRCxJQUE2QkEsdUJBeEJELEVBeUJuQ2tGLElBekJtQyxFQUF0Qzs7QUEyQkEsWUFBSUYsNkJBQTZCLElBQUlBLDZCQUE2QixDQUFDMUwsTUFBbkUsRUFBMkU7QUFDekV1QixVQUFBQSxPQUFPLENBQUMyRCxjQUFSLENBQXVCO0FBQ3JCbEQsWUFBQUEsS0FBSyxFQUFFO0FBQUVGLGNBQUFBLElBQUksRUFBRSwyQ0FBUjtBQUFxREcsY0FBQUEsS0FBSyxFQUFFO0FBQTVELGFBRGM7QUFFckJrRCxZQUFBQSxPQUFPLEVBQUUsQ0FDUDtBQUFFQyxjQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQkMsY0FBQUEsS0FBSyxFQUFFO0FBQXhCLGFBRE8sRUFFUDtBQUFFRCxjQUFBQSxFQUFFLEVBQUUsVUFBTjtBQUFrQkMsY0FBQUEsS0FBSyxFQUFFO0FBQXpCLGFBRk8sQ0FGWTtBQU1yQkMsWUFBQUEsS0FBSyxFQUFFb0c7QUFOYyxXQUF2QjtBQVFEO0FBQ0Y7O0FBRUQsVUFBSWxLLE9BQU8sS0FBSyxRQUFaLElBQXdCQyxHQUFHLEtBQUssTUFBcEMsRUFBNEM7QUFDMUMsY0FBTW9LLG1CQUFtQixHQUFHLE1BQU12RixvQkFBb0IsQ0FBQ3dGLGtCQUFyQixDQUNoQ3hLLE9BRGdDLEVBRWhDa0UsSUFGZ0MsRUFHaENDLEVBSGdDLEVBSWhDLFVBSmdDLEVBS2hDM0YsT0FMZ0MsRUFNaEM0RixPQU5nQyxDQUFsQzs7QUFRQSxZQUFJbUcsbUJBQW1CLElBQUlBLG1CQUFtQixDQUFDN0wsTUFBL0MsRUFBdUQ7QUFDckR1QixVQUFBQSxPQUFPLENBQUM4QixxQkFBUixDQUE4QjtBQUFFdkIsWUFBQUEsSUFBSSxFQUFFLG1CQUFSO0FBQTZCRyxZQUFBQSxLQUFLLEVBQUU7QUFBcEMsV0FBOUI7QUFDQVYsVUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFDNUJ2QixZQUFBQSxJQUFJLEVBQ0YsOEhBRjBCO0FBRzVCRyxZQUFBQSxLQUFLLEVBQUU7QUFIcUIsV0FBOUI7QUFLQSxnQkFBTThKLFFBQVEsR0FBRyxFQUFqQjs7QUFDQSxlQUFLLE1BQU1DLFFBQVgsSUFBdUJILG1CQUF2QixFQUE0QztBQUMxQ0UsWUFBQUEsUUFBUSxDQUFDeEwsSUFBVCxDQUFjO0FBQUV1QixjQUFBQSxJQUFJLEVBQUVrSyxRQUFRLENBQUNDLE9BQWpCO0FBQTBCaEssY0FBQUEsS0FBSyxFQUFFO0FBQWpDLGFBQWQ7QUFDQThKLFlBQUFBLFFBQVEsQ0FBQ3hMLElBQVQsQ0FBYztBQUNaMkwsY0FBQUEsRUFBRSxFQUFFRixRQUFRLENBQUNHLFVBQVQsQ0FBb0IvSyxHQUFwQixDQUF5QmdHLElBQUQsS0FBVztBQUNyQ3RGLGdCQUFBQSxJQUFJLEVBQUVzRixJQUFJLENBQUNnRixTQUFMLENBQWUsQ0FBZixFQUFrQixFQUFsQixJQUF3QixLQURPO0FBRXJDQyxnQkFBQUEsSUFBSSxFQUFFakYsSUFGK0I7QUFHckNqRixnQkFBQUEsS0FBSyxFQUFFO0FBSDhCLGVBQVgsQ0FBeEI7QUFEUSxhQUFkO0FBT0Q7O0FBQ0RaLFVBQUFBLE9BQU8sQ0FBQzhCLHFCQUFSLENBQThCO0FBQUU2SSxZQUFBQSxFQUFFLEVBQUVIO0FBQU4sV0FBOUI7QUFDRDs7QUFFRCxjQUFNTyxlQUFlLEdBQUcsTUFBTWhHLG9CQUFvQixDQUFDd0Ysa0JBQXJCLENBQzVCeEssT0FENEIsRUFFNUJrRSxJQUY0QixFQUc1QkMsRUFINEIsRUFJNUIsTUFKNEIsRUFLNUIzRixPQUw0QixFQU01QjRGLE9BTjRCLENBQTlCOztBQVFBLFlBQUk0RyxlQUFlLElBQUlBLGVBQWUsQ0FBQ3RNLE1BQXZDLEVBQStDO0FBQzdDdUIsVUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFBRXZCLFlBQUFBLElBQUksRUFBRSxlQUFSO0FBQXlCRyxZQUFBQSxLQUFLLEVBQUU7QUFBaEMsV0FBOUI7QUFDQVYsVUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFDNUJ2QixZQUFBQSxJQUFJLEVBQUUsaUVBRHNCO0FBRTVCRyxZQUFBQSxLQUFLLEVBQUU7QUFGcUIsV0FBOUI7QUFJQSxnQkFBTThKLFFBQVEsR0FBRyxFQUFqQjs7QUFDQSxlQUFLLE1BQU1DLFFBQVgsSUFBdUJNLGVBQXZCLEVBQXdDO0FBQ3RDUCxZQUFBQSxRQUFRLENBQUN4TCxJQUFULENBQWM7QUFBRXVCLGNBQUFBLElBQUksRUFBRWtLLFFBQVEsQ0FBQ0MsT0FBakI7QUFBMEJoSyxjQUFBQSxLQUFLLEVBQUU7QUFBakMsYUFBZDtBQUNBOEosWUFBQUEsUUFBUSxDQUFDeEwsSUFBVCxDQUFjO0FBQ1oyTCxjQUFBQSxFQUFFLEVBQUVGLFFBQVEsQ0FBQ0csVUFBVCxDQUFvQi9LLEdBQXBCLENBQXlCZ0csSUFBRCxLQUFXO0FBQ3JDdEYsZ0JBQUFBLElBQUksRUFBRXNGLElBRCtCO0FBRXJDakYsZ0JBQUFBLEtBQUssRUFBRTtBQUY4QixlQUFYLENBQXhCO0FBRFEsYUFBZDtBQU1EOztBQUNENEosVUFBQUEsUUFBUSxJQUFJQSxRQUFRLENBQUMvTCxNQUFyQixJQUErQnVCLE9BQU8sQ0FBQ00sVUFBUixDQUFtQjtBQUFFcUssWUFBQUEsRUFBRSxFQUFFSDtBQUFOLFdBQW5CLENBQS9CO0FBQ0F4SyxVQUFBQSxPQUFPLENBQUNnQixVQUFSO0FBQ0Q7QUFDRjs7QUFFRCxhQUFPLEtBQVA7QUFDRCxLQS9zQkQsQ0Erc0JFLE9BQU9tQixLQUFQLEVBQWM7QUFDZCx1QkFBSSwrQkFBSixFQUFxQ0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUF0RDtBQUNBLGFBQU9FLE9BQU8sQ0FBQ0MsTUFBUixDQUFlSCxLQUFmLENBQVA7QUFDRDtBQUNGOztBQUVPNkksRUFBQUEsYUFBUixDQUFzQnJKLElBQXRCLEVBQTRCc0osTUFBNUIsRUFBb0M7QUFDbEMscUJBQUkseUJBQUosRUFBZ0MsNkJBQWhDLEVBQThELE1BQTlEO0FBQ0EsVUFBTUMsTUFBTSxHQUFHLEVBQWY7O0FBQ0EsU0FBSyxJQUFJQyxJQUFULElBQWlCeEosSUFBSSxJQUFJLEVBQXpCLEVBQTZCO0FBQzNCLFVBQUl5SixLQUFLLENBQUNDLE9BQU4sQ0FBYzFKLElBQUksQ0FBQ3dKLElBQUQsQ0FBbEIsQ0FBSixFQUErQjtBQUM3QnhKLFFBQUFBLElBQUksQ0FBQ3dKLElBQUQsQ0FBSixDQUFXbEIsT0FBWCxDQUFtQixDQUFDcUIsQ0FBRCxFQUFJQyxHQUFKLEtBQVk7QUFDN0IsY0FBSSxPQUFPRCxDQUFQLEtBQWEsUUFBakIsRUFBMkIzSixJQUFJLENBQUN3SixJQUFELENBQUosQ0FBV0ksR0FBWCxJQUFrQkMsSUFBSSxDQUFDQyxTQUFMLENBQWVILENBQWYsQ0FBbEI7QUFDNUIsU0FGRDtBQUdEOztBQUNESixNQUFBQSxNQUFNLENBQUNsTSxJQUFQLENBQVksQ0FBQyxDQUFDaU0sTUFBTSxJQUFJLEVBQVgsRUFBZUUsSUFBZixLQUF3Qk8sa0NBQWVQLElBQWYsQ0FBeEIsSUFBZ0RBLElBQWpELEVBQXVEeEosSUFBSSxDQUFDd0osSUFBRCxDQUFKLElBQWMsR0FBckUsQ0FBWjtBQUNEOztBQUNELFdBQU9ELE1BQVA7QUFDRDs7QUFFT1MsRUFBQUEsZUFBUixDQUF3QmhLLElBQXhCLEVBQThCMUIsT0FBOUIsRUFBdUNDLEdBQXZDLEVBQTRDMEwsS0FBSyxHQUFHLEVBQXBELEVBQXdEO0FBQ3RELHFCQUFJLDJCQUFKLEVBQWtDLCtCQUFsQyxFQUFrRSxNQUFsRTtBQUNBLFFBQUlDLFNBQVMsR0FBRyxFQUFoQjtBQUNBLFVBQU1DLFVBQVUsR0FBRyxFQUFuQjtBQUNBLFVBQU1DLFNBQVMsR0FBRyxFQUFsQjs7QUFFQSxRQUFJcEssSUFBSSxDQUFDbEQsTUFBTCxLQUFnQixDQUFoQixJQUFxQjJNLEtBQUssQ0FBQ0MsT0FBTixDQUFjMUosSUFBZCxDQUF6QixFQUE4QztBQUM1Q29LLE1BQUFBLFNBQVMsQ0FBQzlMLE9BQU8sQ0FBQytMLE1BQVIsQ0FBZTlMLEdBQWYsRUFBb0IrTCxhQUFyQixDQUFULEdBQStDdEssSUFBL0M7QUFDRCxLQUZELE1BRU87QUFDTCxXQUFLLElBQUl2QyxHQUFULElBQWdCdUMsSUFBaEIsRUFBc0I7QUFDcEIsWUFDRyxPQUFPQSxJQUFJLENBQUN2QyxHQUFELENBQVgsS0FBcUIsUUFBckIsSUFBaUMsQ0FBQ2dNLEtBQUssQ0FBQ0MsT0FBTixDQUFjMUosSUFBSSxDQUFDdkMsR0FBRCxDQUFsQixDQUFuQyxJQUNDZ00sS0FBSyxDQUFDQyxPQUFOLENBQWMxSixJQUFJLENBQUN2QyxHQUFELENBQWxCLEtBQTRCLE9BQU91QyxJQUFJLENBQUN2QyxHQUFELENBQUosQ0FBVSxDQUFWLENBQVAsS0FBd0IsUUFGdkQsRUFHRTtBQUNBeU0sVUFBQUEsU0FBUyxDQUFDek0sR0FBRCxDQUFULEdBQ0VnTSxLQUFLLENBQUNDLE9BQU4sQ0FBYzFKLElBQUksQ0FBQ3ZDLEdBQUQsQ0FBbEIsS0FBNEIsT0FBT3VDLElBQUksQ0FBQ3ZDLEdBQUQsQ0FBSixDQUFVLENBQVYsQ0FBUCxLQUF3QixRQUFwRCxHQUNJdUMsSUFBSSxDQUFDdkMsR0FBRCxDQUFKLENBQVVTLEdBQVYsQ0FBZXlMLENBQUQsSUFBTztBQUNuQixtQkFBTyxPQUFPQSxDQUFQLEtBQWEsUUFBYixHQUF3QkUsSUFBSSxDQUFDQyxTQUFMLENBQWVILENBQWYsQ0FBeEIsR0FBNENBLENBQUMsR0FBRyxJQUF2RDtBQUNELFdBRkQsQ0FESixHQUlJM0osSUFBSSxDQUFDdkMsR0FBRCxDQUxWO0FBTUQsU0FWRCxNQVVPLElBQUlnTSxLQUFLLENBQUNDLE9BQU4sQ0FBYzFKLElBQUksQ0FBQ3ZDLEdBQUQsQ0FBbEIsS0FBNEIsT0FBT3VDLElBQUksQ0FBQ3ZDLEdBQUQsQ0FBSixDQUFVLENBQVYsQ0FBUCxLQUF3QixRQUF4RCxFQUFrRTtBQUN2RTJNLFVBQUFBLFNBQVMsQ0FBQzNNLEdBQUQsQ0FBVCxHQUFpQnVDLElBQUksQ0FBQ3ZDLEdBQUQsQ0FBckI7QUFDRCxTQUZNLE1BRUE7QUFDTCxjQUFJYSxPQUFPLENBQUNpTSxhQUFSLElBQXlCLENBQUMsTUFBRCxFQUFTLFNBQVQsRUFBb0I3TCxRQUFwQixDQUE2QmpCLEdBQTdCLENBQTdCLEVBQWdFO0FBQzlEMk0sWUFBQUEsU0FBUyxDQUFDM00sR0FBRCxDQUFULEdBQWlCLENBQUN1QyxJQUFJLENBQUN2QyxHQUFELENBQUwsQ0FBakI7QUFDRCxXQUZELE1BRU87QUFDTDBNLFlBQUFBLFVBQVUsQ0FBQzlNLElBQVgsQ0FBZ0IyQyxJQUFJLENBQUN2QyxHQUFELENBQXBCO0FBQ0Q7QUFDRjtBQUNGO0FBQ0Y7O0FBQ0R3TSxJQUFBQSxLQUFLLENBQUM1TSxJQUFOLENBQVc7QUFDVHlCLE1BQUFBLEtBQUssRUFBRSxDQUFDUixPQUFPLENBQUNrTSxPQUFSLElBQW1CLEVBQXBCLEVBQXdCQyxVQUF4QixHQUNILEVBREcsR0FFSCxDQUFDbk0sT0FBTyxDQUFDb00sSUFBUixJQUFnQixFQUFqQixFQUFxQm5NLEdBQXJCLE1BQ0NELE9BQU8sQ0FBQ2lNLGFBQVIsR0FBd0IsQ0FBQyxDQUFDak0sT0FBTyxDQUFDZ0wsTUFBUixJQUFrQixFQUFuQixFQUF1QixDQUF2QixLQUE2QixFQUE5QixFQUFrQy9LLEdBQWxDLENBQXhCLEdBQWlFLEVBRGxFLENBSEs7QUFLVDBELE1BQUFBLE9BQU8sRUFBRSxDQUFDLEVBQUQsRUFBSyxFQUFMLENBTEE7QUFNVHJFLE1BQUFBLElBQUksRUFBRSxRQU5HO0FBT1QrTSxNQUFBQSxJQUFJLEVBQUUsS0FBS3RCLGFBQUwsQ0FBbUJhLFNBQW5CLEVBQThCLENBQUM1TCxPQUFPLENBQUNnTCxNQUFSLElBQWtCLEVBQW5CLEVBQXVCLENBQXZCLENBQTlCO0FBUEcsS0FBWDs7QUFTQSxTQUFLLElBQUk3TCxHQUFULElBQWdCMk0sU0FBaEIsRUFBMkI7QUFDekIsWUFBTW5JLE9BQU8sR0FBRzlDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZZ0wsU0FBUyxDQUFDM00sR0FBRCxDQUFULENBQWUsQ0FBZixDQUFaLENBQWhCO0FBQ0F3RSxNQUFBQSxPQUFPLENBQUNxRyxPQUFSLENBQWdCLENBQUNzQyxHQUFELEVBQU1yTixDQUFOLEtBQVk7QUFDMUIwRSxRQUFBQSxPQUFPLENBQUMxRSxDQUFELENBQVAsR0FBYXFOLEdBQUcsQ0FBQyxDQUFELENBQUgsQ0FBT0MsV0FBUCxLQUF1QkQsR0FBRyxDQUFDRSxLQUFKLENBQVUsQ0FBVixDQUFwQztBQUNELE9BRkQ7QUFJQSxZQUFNSCxJQUFJLEdBQUdQLFNBQVMsQ0FBQzNNLEdBQUQsQ0FBVCxDQUFlUyxHQUFmLENBQW9CeUwsQ0FBRCxJQUFPO0FBQ3JDLFlBQUlvQixHQUFHLEdBQUcsRUFBVjs7QUFDQSxhQUFLLElBQUl0TixHQUFULElBQWdCa00sQ0FBaEIsRUFBbUI7QUFDakJvQixVQUFBQSxHQUFHLENBQUMxTixJQUFKLENBQ0UsT0FBT3NNLENBQUMsQ0FBQ2xNLEdBQUQsQ0FBUixLQUFrQixRQUFsQixHQUNJa00sQ0FBQyxDQUFDbE0sR0FBRCxDQURMLEdBRUlnTSxLQUFLLENBQUNDLE9BQU4sQ0FBY0MsQ0FBQyxDQUFDbE0sR0FBRCxDQUFmLElBQ0FrTSxDQUFDLENBQUNsTSxHQUFELENBQUQsQ0FBT1MsR0FBUCxDQUFZeUwsQ0FBRCxJQUFPO0FBQ2hCLG1CQUFPQSxDQUFDLEdBQUcsSUFBWDtBQUNELFdBRkQsQ0FEQSxHQUlBRSxJQUFJLENBQUNDLFNBQUwsQ0FBZUgsQ0FBQyxDQUFDbE0sR0FBRCxDQUFoQixDQVBOO0FBU0Q7O0FBQ0QsZUFBT3NOLEdBQUcsQ0FBQ2pPLE1BQUosR0FBYW1GLE9BQU8sQ0FBQ25GLE1BQTVCLEVBQW9DO0FBQ2xDaU8sVUFBQUEsR0FBRyxDQUFDMU4sSUFBSixDQUFTLEdBQVQ7QUFDRDs7QUFDRCxlQUFPME4sR0FBUDtBQUNELE9BakJZLENBQWI7QUFrQkFkLE1BQUFBLEtBQUssQ0FBQzVNLElBQU4sQ0FBVztBQUNUeUIsUUFBQUEsS0FBSyxFQUFFLENBQUMsQ0FBQ1IsT0FBTyxDQUFDZ0wsTUFBUixJQUFrQixFQUFuQixFQUF1QixDQUF2QixLQUE2QixFQUE5QixFQUFrQzdMLEdBQWxDLEtBQTBDLEVBRHhDO0FBRVRHLFFBQUFBLElBQUksRUFBRSxPQUZHO0FBR1RxRSxRQUFBQSxPQUhTO0FBSVQwSSxRQUFBQTtBQUpTLE9BQVg7QUFNRDs7QUFDRFIsSUFBQUEsVUFBVSxDQUFDN0IsT0FBWCxDQUFtQjBDLElBQUksSUFBSTtBQUN6QixXQUFLaEIsZUFBTCxDQUFxQmdCLElBQXJCLEVBQTJCMU0sT0FBM0IsRUFBb0NDLEdBQUcsR0FBRyxDQUExQyxFQUE2QzBMLEtBQTdDO0FBQ0QsS0FGRDtBQUdBLFdBQU9BLEtBQVA7QUFDRDtBQUVEOzs7Ozs7Ozs7QUFPQSxRQUFNZ0Isb0JBQU4sQ0FDRTdNLE9BREYsRUFFRXdCLE9BRkYsRUFHRXNMLFFBSEYsRUFJRTtBQUNBLFFBQUk7QUFDRix1QkFBSSxnQ0FBSixFQUF1QyxnQkFBdkMsRUFBd0QsTUFBeEQ7QUFDQSxZQUFNO0FBQ0pqQixRQUFBQSxLQURJO0FBRUp0SCxRQUFBQSxNQUZJO0FBR0p3SSxRQUFBQSxlQUhJO0FBSUp0TyxRQUFBQSxTQUpJO0FBS0pELFFBQUFBLE9BTEk7QUFNSndPLFFBQUFBLElBTkk7QUFPSkMsUUFBQUEsTUFQSTtBQVFKNUosUUFBQUEsSUFSSTtBQVNKbkQsUUFBQUEsT0FUSTtBQVVKZ04sUUFBQUEsaUJBVkk7QUFXSjdNLFFBQUFBO0FBWEksVUFZRm1CLE9BQU8sQ0FBQzJMLElBWlo7QUFhQSxZQUFNO0FBQUVDLFFBQUFBO0FBQUYsVUFBZTVMLE9BQU8sQ0FBQ2pDLE1BQTdCO0FBQ0EsWUFBTTtBQUFFMkUsUUFBQUEsSUFBRjtBQUFRQyxRQUFBQTtBQUFSLFVBQWU2SSxJQUFJLElBQUksRUFBN0IsQ0FoQkUsQ0FpQkY7O0FBQ0EsWUFBTS9NLE9BQU8sR0FBRyxJQUFJb04sc0JBQUosRUFBaEI7QUFDQSxZQUFNO0FBQUVDLFFBQUFBLFFBQVEsRUFBRUM7QUFBWixVQUF1QixNQUFNdk4sT0FBTyxDQUFDb0IsS0FBUixDQUFjb00sUUFBZCxDQUF1QkMsY0FBdkIsQ0FBc0NqTSxPQUF0QyxFQUErQ3hCLE9BQS9DLENBQW5DO0FBQ0E7QUFDQSxrREFBMkIwTiw4Q0FBM0I7QUFDQSxrREFBMkJDLHNEQUEzQjtBQUNBLGtEQUEyQkMsY0FBS2pPLElBQUwsQ0FBVWdPLHNEQUFWLEVBQXVESixNQUF2RCxDQUEzQjtBQUVBLFlBQU0sS0FBS3hOLFlBQUwsQ0FBa0JDLE9BQWxCLEVBQTJCQyxPQUEzQixFQUFvQ0MsT0FBcEMsRUFBNkNrTixRQUE3QyxFQUF1RDdJLE1BQXZELEVBQStEbEUsS0FBL0QsQ0FBTjtBQUVBLFlBQU0sQ0FBQ3dOLGdCQUFELEVBQW1CalAsWUFBbkIsSUFBbUNKLE9BQU8sR0FDNUMsS0FBS0QscUJBQUwsQ0FBMkJDLE9BQTNCLEVBQW9DQyxTQUFwQyxDQUQ0QyxHQUU1QyxDQUFDLEtBQUQsRUFBUSxLQUFSLENBRko7O0FBSUEsVUFBSXVPLElBQUksSUFBSWEsZ0JBQVosRUFBOEI7QUFDNUI1TixRQUFBQSxPQUFPLENBQUM2TixzQkFBUixDQUErQjVKLElBQS9CLEVBQXFDQyxFQUFyQyxFQUF5QzBKLGdCQUF6QyxFQUEyRGQsZUFBM0Q7QUFDRDs7QUFFRCxVQUFJQyxJQUFKLEVBQVU7QUFDUixjQUFNLEtBQUsvSSxtQkFBTCxDQUNKakUsT0FESSxFQUVKQyxPQUZJLEVBR0pDLE9BSEksRUFJSmtOLFFBSkksRUFLSi9NLEtBTEksRUFNSixJQUFJME4sSUFBSixDQUFTN0osSUFBVCxFQUFlOEosT0FBZixFQU5JLEVBT0osSUFBSUQsSUFBSixDQUFTNUosRUFBVCxFQUFhNkosT0FBYixFQVBJLEVBUUpILGdCQVJJLEVBU0pYLGlCQVRJLEVBVUozSSxNQVZJLENBQU47QUFZRDs7QUFFRHRFLE1BQUFBLE9BQU8sQ0FBQ2dPLGlCQUFSLENBQTBCcEMsS0FBMUIsRUFBaUN0SCxNQUFqQyxFQUF5QzZJLFFBQXpDOztBQUVBLFVBQUlILE1BQUosRUFBWTtBQUNWaE4sUUFBQUEsT0FBTyxDQUFDaU8sU0FBUixDQUFrQmpCLE1BQWxCO0FBQ0QsT0F0REMsQ0F3REY7OztBQUNBLFVBQUlyTyxZQUFKLEVBQWtCO0FBQ2hCcUIsUUFBQUEsT0FBTyxDQUFDa08sZ0JBQVIsQ0FBeUJ2UCxZQUF6QjtBQUNEOztBQUVELFlBQU1xQixPQUFPLENBQUNtTyxLQUFSLENBQWNSLGNBQUtqTyxJQUFMLENBQVVnTyxzREFBVixFQUF1REosTUFBdkQsRUFBK0RsSyxJQUEvRCxDQUFkLENBQU47QUFFQSxhQUFPeUosUUFBUSxDQUFDdUIsRUFBVCxDQUFZO0FBQ2pCbEIsUUFBQUEsSUFBSSxFQUFFO0FBQ0ptQixVQUFBQSxPQUFPLEVBQUUsSUFETDtBQUVKak0sVUFBQUEsT0FBTyxFQUFHLFVBQVNnQixJQUFLO0FBRnBCO0FBRFcsT0FBWixDQUFQO0FBTUQsS0FyRUQsQ0FxRUUsT0FBT2pCLEtBQVAsRUFBYztBQUNkLGFBQU8sa0NBQWNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUQwSyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7Ozs7QUFPQSxRQUFNeUIsbUJBQU4sQ0FDRXZPLE9BREYsRUFFRXdCLE9BRkYsRUFHRXNMLFFBSEYsRUFJRTtBQUNBLFFBQUk7QUFDRix1QkFBSSwrQkFBSixFQUFzQyxnQkFBdEMsRUFBdUQsTUFBdkQ7QUFDQSxZQUFNO0FBQUV6SixRQUFBQSxJQUFGO0FBQVFtTCxRQUFBQSxVQUFSO0FBQW9Cbk8sUUFBQUE7QUFBcEIsVUFBOEJtQixPQUFPLENBQUMyTCxJQUE1QztBQUNBLFlBQU07QUFBRXNCLFFBQUFBO0FBQUYsVUFBY2pOLE9BQU8sQ0FBQ2pDLE1BQTVCLENBSEUsQ0FJRjs7QUFDQSxZQUFNVSxPQUFPLEdBQUcsSUFBSW9OLHNCQUFKLEVBQWhCO0FBRUEsWUFBTTtBQUFFQyxRQUFBQSxRQUFRLEVBQUVDO0FBQVosVUFBdUIsTUFBTXZOLE9BQU8sQ0FBQ29CLEtBQVIsQ0FBY29NLFFBQWQsQ0FBdUJDLGNBQXZCLENBQXNDak0sT0FBdEMsRUFBK0N4QixPQUEvQyxDQUFuQztBQUNBO0FBQ0Esa0RBQTJCME4sOENBQTNCO0FBQ0Esa0RBQTJCQyxzREFBM0I7QUFDQSxrREFBMkJDLGNBQUtqTyxJQUFMLENBQVVnTyxzREFBVixFQUF1REosTUFBdkQsQ0FBM0I7QUFFQSxVQUFJTixNQUFNLEdBQUcsRUFBYjtBQUNBLFlBQU15QixZQUFZLEdBQUc7QUFDbkJDLFFBQUFBLFNBQVMsRUFBRSxhQURRO0FBRW5CQyxRQUFBQSxPQUFPLEVBQUUsU0FGVTtBQUduQkMsUUFBQUEsT0FBTyxFQUFFLFNBSFU7QUFJbkJDLFFBQUFBLFFBQVEsRUFBRSxVQUpTO0FBS25CLHFCQUFhLFVBTE07QUFNbkIsbUJBQVcsU0FOUTtBQU9uQkMsUUFBQUEsWUFBWSxFQUFFLGNBUEs7QUFRbkJDLFFBQUFBLFNBQVMsRUFBRSxXQVJRO0FBU25COUQsUUFBQUEsTUFBTSxFQUFFLFFBVFc7QUFVbkIrRCxRQUFBQSxHQUFHLEVBQUU7QUFWYyxPQUFyQjtBQVlBaFAsTUFBQUEsT0FBTyxDQUFDTSxVQUFSLENBQW1CO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUcsU0FBUWlPLE9BQVEsZ0JBRE47QUFFakI5TixRQUFBQSxLQUFLLEVBQUU7QUFGVSxPQUFuQjs7QUFLQSxVQUFJNk4sVUFBVSxDQUFDLEdBQUQsQ0FBZCxFQUFxQjtBQUNuQixZQUFJdEMsYUFBYSxHQUFHLEVBQXBCOztBQUNBLFlBQUk7QUFDRixnQkFBTWdELHFCQUFxQixHQUFHLE1BQU1sUCxPQUFPLENBQUNvQixLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Q0MsT0FBdkMsQ0FDbEMsS0FEa0MsRUFFakMsV0FBVWlOLE9BQVEsZ0JBRmUsRUFHbEMsRUFIa0MsRUFJbEM7QUFBRS9NLFlBQUFBLFNBQVMsRUFBRXJCO0FBQWIsV0FKa0MsQ0FBcEM7QUFNQTZMLFVBQUFBLGFBQWEsR0FBR2dELHFCQUFxQixDQUFDdE4sSUFBdEIsQ0FBMkJBLElBQTNDO0FBQ0QsU0FSRCxDQVFFLE9BQU9RLEtBQVAsRUFBYztBQUNkLDJCQUFJLCtCQUFKLEVBQXFDQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQXRELEVBQTZELE9BQTdEO0FBQ0Q7O0FBRUQsWUFDRThKLGFBQWEsQ0FBQ3JLLGNBQWQsQ0FBNkJuRCxNQUE3QixHQUFzQyxDQUF0QyxJQUNBcUMsTUFBTSxDQUFDQyxJQUFQLENBQVlrTCxhQUFhLENBQUNySyxjQUFkLENBQTZCLENBQTdCLEVBQWdDb0ssTUFBNUMsRUFBb0R2TixNQUZ0RCxFQUdFO0FBQ0F1QixVQUFBQSxPQUFPLENBQUNNLFVBQVIsQ0FBbUI7QUFDakJDLFlBQUFBLElBQUksRUFBRSxnQkFEVztBQUVqQkcsWUFBQUEsS0FBSyxFQUFFO0FBQUVDLGNBQUFBLFFBQVEsRUFBRSxFQUFaO0FBQWdCQyxjQUFBQSxLQUFLLEVBQUU7QUFBdkIsYUFGVTtBQUdqQkMsWUFBQUEsTUFBTSxFQUFFLENBQUMsQ0FBRCxFQUFJLEVBQUosRUFBUSxDQUFSLEVBQVcsRUFBWDtBQUhTLFdBQW5CO0FBS0EsZ0JBQU1aLE9BQU8sR0FBRztBQUNkZ0wsWUFBQUEsTUFBTSxFQUFFLEVBRE07QUFFZGlCLFlBQUFBLGFBQWEsRUFBRTtBQUZELFdBQWhCOztBQUlBLGVBQUssSUFBSUYsTUFBVCxJQUFtQkMsYUFBYSxDQUFDckssY0FBakMsRUFBaUQ7QUFDL0MsZ0JBQUlzTixXQUFXLEdBQUcsRUFBbEI7QUFDQSxnQkFBSUMsS0FBSyxHQUFHLENBQVo7O0FBQ0EsaUJBQUssSUFBSXZRLE1BQVQsSUFBbUJrQyxNQUFNLENBQUNDLElBQVAsQ0FBWWlMLE1BQU0sQ0FBQ3pOLE9BQW5CLENBQW5CLEVBQWdEO0FBQzlDMlEsY0FBQUEsV0FBVyxHQUFHQSxXQUFXLENBQUNFLE1BQVosQ0FBb0IsR0FBRXhRLE1BQU8sS0FBSW9OLE1BQU0sQ0FBQ3pOLE9BQVAsQ0FBZUssTUFBZixDQUF1QixFQUF4RCxDQUFkOztBQUNBLGtCQUFJdVEsS0FBSyxHQUFHck8sTUFBTSxDQUFDQyxJQUFQLENBQVlpTCxNQUFNLENBQUN6TixPQUFuQixFQUE0QkUsTUFBNUIsR0FBcUMsQ0FBakQsRUFBb0Q7QUFDbER5USxnQkFBQUEsV0FBVyxHQUFHQSxXQUFXLENBQUNFLE1BQVosQ0FBbUIsS0FBbkIsQ0FBZDtBQUNEOztBQUNERCxjQUFBQSxLQUFLO0FBQ047O0FBQ0RuUCxZQUFBQSxPQUFPLENBQUNNLFVBQVIsQ0FBbUI7QUFDakJDLGNBQUFBLElBQUksRUFBRTJPLFdBRFc7QUFFakJ4TyxjQUFBQSxLQUFLLEVBQUUsSUFGVTtBQUdqQkcsY0FBQUEsTUFBTSxFQUFFLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsRUFBVjtBQUhTLGFBQW5CO0FBS0EsZ0JBQUkwSyxHQUFHLEdBQUcsQ0FBVjtBQUNBdEwsWUFBQUEsT0FBTyxDQUFDb00sSUFBUixHQUFlLEVBQWY7O0FBQ0EsaUJBQUssSUFBSWdELEVBQVQsSUFBZXZPLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZaUwsTUFBTSxDQUFDQSxNQUFuQixDQUFmLEVBQTJDO0FBQ3pDLG1CQUFLLElBQUlzRCxDQUFULElBQWNDLHVDQUFtQkMsY0FBakMsRUFBaUQ7QUFDL0MscUJBQUssSUFBSUMsQ0FBVCxJQUFjSCxDQUFDLENBQUNJLFFBQWhCLEVBQTBCO0FBQ3hCelAsa0JBQUFBLE9BQU8sQ0FBQzBQLElBQVIsR0FBZUYsQ0FBQyxDQUFDRSxJQUFGLElBQVUsRUFBekI7O0FBQ0EsdUJBQUssSUFBSUMsRUFBVCxJQUFlSCxDQUFDLENBQUN6RCxNQUFGLElBQVksRUFBM0IsRUFBK0I7QUFDN0Isd0JBQUk0RCxFQUFFLENBQUMzRCxhQUFILEtBQXFCb0QsRUFBekIsRUFBNkI7QUFDM0JwUCxzQkFBQUEsT0FBTyxDQUFDZ0wsTUFBUixHQUFpQndFLENBQUMsQ0FBQ3hFLE1BQUYsSUFBWSxDQUFDLEVBQUQsQ0FBN0I7QUFDRDtBQUNGOztBQUNELHVCQUFLLElBQUk0RSxFQUFULElBQWVKLENBQUMsQ0FBQ0ssS0FBRixJQUFXLEVBQTFCLEVBQThCO0FBQzVCLHdCQUFJRCxFQUFFLENBQUN6TSxJQUFILEtBQVlpTSxFQUFoQixFQUFvQjtBQUNsQnBQLHNCQUFBQSxPQUFPLENBQUNnTCxNQUFSLEdBQWlCd0UsQ0FBQyxDQUFDeEUsTUFBRixJQUFZLENBQUMsRUFBRCxDQUE3QjtBQUNEO0FBQ0Y7QUFDRjtBQUNGOztBQUNEaEwsY0FBQUEsT0FBTyxDQUFDZ0wsTUFBUixDQUFlLENBQWYsRUFBa0IsTUFBbEIsSUFBNEIsT0FBNUI7QUFDQWhMLGNBQUFBLE9BQU8sQ0FBQ2dMLE1BQVIsQ0FBZSxDQUFmLEVBQWtCLFNBQWxCLElBQStCLGFBQS9CO0FBQ0FoTCxjQUFBQSxPQUFPLENBQUNnTCxNQUFSLENBQWUsQ0FBZixFQUFrQixHQUFsQixJQUF5Qiw4QkFBekI7QUFDQWhMLGNBQUFBLE9BQU8sQ0FBQ29NLElBQVIsQ0FBYXJOLElBQWIsQ0FBa0J5UCxZQUFZLENBQUNZLEVBQUQsQ0FBOUI7O0FBRUEsa0JBQUlqRSxLQUFLLENBQUNDLE9BQU4sQ0FBY1csTUFBTSxDQUFDQSxNQUFQLENBQWNxRCxFQUFkLENBQWQsQ0FBSixFQUFzQztBQUNwQztBQUNBLG9CQUFJQSxFQUFFLEtBQUssV0FBWCxFQUF3QjtBQUN0QixzQkFBSVUsTUFBTSxHQUFHLEVBQWI7O0FBQ0EvRCxrQkFBQUEsTUFBTSxDQUFDQSxNQUFQLENBQWNxRCxFQUFkLEVBQWtCcEYsT0FBbEIsQ0FBMkIrRixHQUFELElBQVM7QUFDakMsd0JBQUksQ0FBQ0QsTUFBTSxDQUFDQyxHQUFHLENBQUNDLFNBQUwsQ0FBWCxFQUE0QjtBQUMxQkYsc0JBQUFBLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDQyxTQUFMLENBQU4sR0FBd0IsRUFBeEI7QUFDRDs7QUFDREYsb0JBQUFBLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDQyxTQUFMLENBQU4sQ0FBc0JqUixJQUF0QixDQUEyQmdSLEdBQTNCO0FBQ0QsbUJBTEQ7O0FBTUFsUCxrQkFBQUEsTUFBTSxDQUFDQyxJQUFQLENBQVlnUCxNQUFaLEVBQW9COUYsT0FBcEIsQ0FBNkJqSSxLQUFELElBQVc7QUFDckMsd0JBQUlrTyxPQUFPLEdBQUcsQ0FBZDtBQUNBSCxvQkFBQUEsTUFBTSxDQUFDL04sS0FBRCxDQUFOLENBQWNpSSxPQUFkLENBQXNCLENBQUNxQixDQUFELEVBQUlwTSxDQUFKLEtBQVU7QUFDOUIsMEJBQUk0QixNQUFNLENBQUNDLElBQVAsQ0FBWXVLLENBQVosRUFBZTdNLE1BQWYsR0FBd0JxQyxNQUFNLENBQUNDLElBQVAsQ0FBWWdQLE1BQU0sQ0FBQy9OLEtBQUQsQ0FBTixDQUFja08sT0FBZCxDQUFaLEVBQW9DelIsTUFBaEUsRUFBd0U7QUFDdEV5Uix3QkFBQUEsT0FBTyxHQUFHaFIsQ0FBVjtBQUNEO0FBQ0YscUJBSkQ7QUFLQSwwQkFBTTBFLE9BQU8sR0FBRzlDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZZ1AsTUFBTSxDQUFDL04sS0FBRCxDQUFOLENBQWNrTyxPQUFkLENBQVosQ0FBaEI7QUFDQSwwQkFBTTVELElBQUksR0FBR3lELE1BQU0sQ0FBQy9OLEtBQUQsQ0FBTixDQUFjbkMsR0FBZCxDQUFtQnlMLENBQUQsSUFBTztBQUNwQywwQkFBSW9CLEdBQUcsR0FBRyxFQUFWO0FBQ0E5SSxzQkFBQUEsT0FBTyxDQUFDcUcsT0FBUixDQUFpQjdLLEdBQUQsSUFBUztBQUN2QnNOLHdCQUFBQSxHQUFHLENBQUMxTixJQUFKLENBQ0UsT0FBT3NNLENBQUMsQ0FBQ2xNLEdBQUQsQ0FBUixLQUFrQixRQUFsQixHQUNJa00sQ0FBQyxDQUFDbE0sR0FBRCxDQURMLEdBRUlnTSxLQUFLLENBQUNDLE9BQU4sQ0FBY0MsQ0FBQyxDQUFDbE0sR0FBRCxDQUFmLElBQ0FrTSxDQUFDLENBQUNsTSxHQUFELENBQUQsQ0FBT1MsR0FBUCxDQUFZeUwsQ0FBRCxJQUFPO0FBQ2hCLGlDQUFPQSxDQUFDLEdBQUcsSUFBWDtBQUNELHlCQUZELENBREEsR0FJQUUsSUFBSSxDQUFDQyxTQUFMLENBQWVILENBQUMsQ0FBQ2xNLEdBQUQsQ0FBaEIsQ0FQTjtBQVNELHVCQVZEO0FBV0EsNkJBQU9zTixHQUFQO0FBQ0QscUJBZFksQ0FBYjtBQWVBOUksb0JBQUFBLE9BQU8sQ0FBQ3FHLE9BQVIsQ0FBZ0IsQ0FBQ3NDLEdBQUQsRUFBTXJOLENBQU4sS0FBWTtBQUMxQjBFLHNCQUFBQSxPQUFPLENBQUMxRSxDQUFELENBQVAsR0FBYXFOLEdBQUcsQ0FBQyxDQUFELENBQUgsQ0FBT0MsV0FBUCxLQUF1QkQsR0FBRyxDQUFDRSxLQUFKLENBQVUsQ0FBVixDQUFwQztBQUNELHFCQUZEO0FBR0FPLG9CQUFBQSxNQUFNLENBQUNoTyxJQUFQLENBQVk7QUFDVnlCLHNCQUFBQSxLQUFLLEVBQUUsYUFERztBQUVWbEIsc0JBQUFBLElBQUksRUFBRSxPQUZJO0FBR1ZxRSxzQkFBQUEsT0FIVTtBQUlWMEksc0JBQUFBO0FBSlUscUJBQVo7QUFNRCxtQkFoQ0Q7QUFpQ0QsaUJBekNELE1BeUNPLElBQUkrQyxFQUFFLEtBQUssUUFBWCxFQUFxQjtBQUMxQix3QkFBTVcsR0FBRyxHQUFHaEUsTUFBTSxDQUFDQSxNQUFQLENBQWNxRCxFQUFkLEVBQWtCLENBQWxCLEVBQXFCdkwsS0FBakM7QUFDQSx3QkFBTUYsT0FBTyxHQUFHOUMsTUFBTSxDQUFDQyxJQUFQLENBQVlpUCxHQUFHLENBQUMsQ0FBRCxDQUFmLENBQWhCOztBQUNBLHNCQUFJLENBQUNwTSxPQUFPLENBQUN2RCxRQUFSLENBQWlCLFFBQWpCLENBQUwsRUFBaUM7QUFDL0J1RCxvQkFBQUEsT0FBTyxDQUFDNUUsSUFBUixDQUFhLFFBQWI7QUFDRDs7QUFDRCx3QkFBTXNOLElBQUksR0FBRzBELEdBQUcsQ0FBQ25RLEdBQUosQ0FBU3lMLENBQUQsSUFBTztBQUMxQix3QkFBSW9CLEdBQUcsR0FBRyxFQUFWO0FBQ0E5SSxvQkFBQUEsT0FBTyxDQUFDcUcsT0FBUixDQUFpQjdLLEdBQUQsSUFBUztBQUN2QnNOLHNCQUFBQSxHQUFHLENBQUMxTixJQUFKLENBQVNzTSxDQUFDLENBQUNsTSxHQUFELENBQVY7QUFDRCxxQkFGRDtBQUdBLDJCQUFPc04sR0FBUDtBQUNELG1CQU5ZLENBQWI7QUFPQTlJLGtCQUFBQSxPQUFPLENBQUNxRyxPQUFSLENBQWdCLENBQUNzQyxHQUFELEVBQU1yTixDQUFOLEtBQVk7QUFDMUIwRSxvQkFBQUEsT0FBTyxDQUFDMUUsQ0FBRCxDQUFQLEdBQWFxTixHQUFHLENBQUMsQ0FBRCxDQUFILENBQU9DLFdBQVAsS0FBdUJELEdBQUcsQ0FBQ0UsS0FBSixDQUFVLENBQVYsQ0FBcEM7QUFDRCxtQkFGRDtBQUdBTyxrQkFBQUEsTUFBTSxDQUFDaE8sSUFBUCxDQUFZO0FBQ1Z5QixvQkFBQUEsS0FBSyxFQUFFLFFBREc7QUFFVmxCLG9CQUFBQSxJQUFJLEVBQUUsT0FGSTtBQUdWcUUsb0JBQUFBLE9BSFU7QUFJVjBJLG9CQUFBQTtBQUpVLG1CQUFaO0FBTUQsaUJBdEJNLE1Bc0JBO0FBQ0wsdUJBQUssSUFBSTZELEdBQVQsSUFBZ0JuRSxNQUFNLENBQUNBLE1BQVAsQ0FBY3FELEVBQWQsQ0FBaEIsRUFBbUM7QUFDakNyQyxvQkFBQUEsTUFBTSxDQUFDaE8sSUFBUCxDQUFZLEdBQUcsS0FBSzJNLGVBQUwsQ0FBcUJ3RSxHQUFyQixFQUEwQmxRLE9BQTFCLEVBQW1Dc0wsR0FBbkMsQ0FBZjtBQUNEO0FBQ0Y7QUFDRixlQXRFRCxNQXNFTztBQUNMO0FBQ0Esb0JBQUlTLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjcUQsRUFBZCxFQUFrQmUsV0FBdEIsRUFBbUM7QUFDakMsd0JBQU1BLFdBQVcsR0FBR3BFLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjcUQsRUFBZCxFQUFrQmUsV0FBdEM7QUFDQSx5QkFBT3BFLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjcUQsRUFBZCxFQUFrQmUsV0FBekI7QUFDQXBELGtCQUFBQSxNQUFNLENBQUNoTyxJQUFQLENBQVksR0FBRyxLQUFLMk0sZUFBTCxDQUFxQkssTUFBTSxDQUFDQSxNQUFQLENBQWNxRCxFQUFkLENBQXJCLEVBQXdDcFAsT0FBeEMsRUFBaURzTCxHQUFqRCxDQUFmO0FBQ0Esc0JBQUk4RSxRQUFRLEdBQUcsRUFBZjtBQUNBdlAsa0JBQUFBLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZZCxPQUFPLENBQUMwUCxJQUFwQixFQUEwQjFGLE9BQTFCLENBQW1DcUIsQ0FBRCxJQUFPO0FBQ3ZDK0Usb0JBQUFBLFFBQVEsQ0FBQ3JSLElBQVQsQ0FBY3NNLENBQWQ7QUFDRCxtQkFGRDtBQUdBLHdCQUFNMUgsT0FBTyxHQUFHLENBQ2QsRUFEYyxFQUVkLEdBQUd5TSxRQUFRLENBQUN6UixNQUFULENBQWlCME0sQ0FBRCxJQUFPQSxDQUFDLEtBQUssV0FBTixJQUFxQkEsQ0FBQyxLQUFLLFdBQWxELENBRlcsQ0FBaEI7QUFJQSxzQkFBSWdCLElBQUksR0FBRyxFQUFYO0FBQ0E4RCxrQkFBQUEsV0FBVyxDQUFDbkcsT0FBWixDQUFxQnFCLENBQUQsSUFBTztBQUN6Qix3QkFBSW9CLEdBQUcsR0FBRyxFQUFWO0FBQ0FBLG9CQUFBQSxHQUFHLENBQUMxTixJQUFKLENBQVNzTSxDQUFDLENBQUNxQyxJQUFYO0FBQ0EvSixvQkFBQUEsT0FBTyxDQUFDcUcsT0FBUixDQUFpQnFHLENBQUQsSUFBTztBQUNyQiwwQkFBSUEsQ0FBQyxLQUFLLEVBQVYsRUFBYztBQUNaQSx3QkFBQUEsQ0FBQyxHQUFHQSxDQUFDLEtBQUssZUFBTixHQUF3QkEsQ0FBeEIsR0FBNEIsU0FBaEM7QUFDQTVELHdCQUFBQSxHQUFHLENBQUMxTixJQUFKLENBQVNzTSxDQUFDLENBQUNnRixDQUFELENBQUQsR0FBT2hGLENBQUMsQ0FBQ2dGLENBQUQsQ0FBUixHQUFjLElBQXZCO0FBQ0Q7QUFDRixxQkFMRDtBQU1BNUQsb0JBQUFBLEdBQUcsQ0FBQzFOLElBQUosQ0FBU3NNLENBQUMsQ0FBQ2lGLGVBQVg7QUFDQWpFLG9CQUFBQSxJQUFJLENBQUN0TixJQUFMLENBQVUwTixHQUFWO0FBQ0QsbUJBWEQ7QUFZQTlJLGtCQUFBQSxPQUFPLENBQUNxRyxPQUFSLENBQWdCLENBQUNxQixDQUFELEVBQUlDLEdBQUosS0FBWTtBQUMxQjNILG9CQUFBQSxPQUFPLENBQUMySCxHQUFELENBQVAsR0FBZXRMLE9BQU8sQ0FBQzBQLElBQVIsQ0FBYXJFLENBQWIsQ0FBZjtBQUNELG1CQUZEO0FBR0ExSCxrQkFBQUEsT0FBTyxDQUFDNUUsSUFBUixDQUFhLElBQWI7QUFDQWdPLGtCQUFBQSxNQUFNLENBQUNoTyxJQUFQLENBQVk7QUFDVnlCLG9CQUFBQSxLQUFLLEVBQUUsdUJBREc7QUFFVmxCLG9CQUFBQSxJQUFJLEVBQUUsT0FGSTtBQUdWcUUsb0JBQUFBLE9BSFU7QUFJVjBJLG9CQUFBQTtBQUpVLG1CQUFaO0FBTUQsaUJBbkNELE1BbUNPO0FBQ0xVLGtCQUFBQSxNQUFNLENBQUNoTyxJQUFQLENBQVksR0FBRyxLQUFLMk0sZUFBTCxDQUFxQkssTUFBTSxDQUFDQSxNQUFQLENBQWNxRCxFQUFkLENBQXJCLEVBQXdDcFAsT0FBeEMsRUFBaURzTCxHQUFqRCxDQUFmO0FBQ0Q7QUFDRjs7QUFDRCxtQkFBSyxNQUFNaUYsS0FBWCxJQUFvQnhELE1BQXBCLEVBQTRCO0FBQzFCaE4sZ0JBQUFBLE9BQU8sQ0FBQ3lRLGVBQVIsQ0FBd0IsQ0FBQ0QsS0FBRCxDQUF4QjtBQUNEOztBQUNEakYsY0FBQUEsR0FBRztBQUNIeUIsY0FBQUEsTUFBTSxHQUFHLEVBQVQ7QUFDRDs7QUFDREEsWUFBQUEsTUFBTSxHQUFHLEVBQVQ7QUFDRDtBQUNGLFNBMUtELE1BMEtPO0FBQ0xoTixVQUFBQSxPQUFPLENBQUNNLFVBQVIsQ0FBbUI7QUFDakJDLFlBQUFBLElBQUksRUFBRSx5REFEVztBQUVqQkcsWUFBQUEsS0FBSyxFQUFFO0FBQUVDLGNBQUFBLFFBQVEsRUFBRSxFQUFaO0FBQWdCQyxjQUFBQSxLQUFLLEVBQUU7QUFBdkIsYUFGVTtBQUdqQkMsWUFBQUEsTUFBTSxFQUFFLENBQUMsQ0FBRCxFQUFJLEVBQUosRUFBUSxDQUFSLEVBQVcsRUFBWDtBQUhTLFdBQW5CO0FBS0Q7QUFDRjs7QUFDRCxVQUFJME4sVUFBVSxDQUFDLEdBQUQsQ0FBZCxFQUFxQjtBQUNuQixZQUFJbUMsYUFBYSxHQUFHLEVBQXBCOztBQUNBLFlBQUk7QUFDRixnQkFBTUMscUJBQXFCLEdBQUcsTUFBTTVRLE9BQU8sQ0FBQ29CLEtBQVIsQ0FBY0MsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJDLGFBQXpCLENBQXVDQyxPQUF2QyxDQUNsQyxLQURrQyxFQUVqQyxXQUFVaU4sT0FBUSxTQUZlLEVBR2xDLEVBSGtDLEVBSWxDO0FBQUUvTSxZQUFBQSxTQUFTLEVBQUVyQjtBQUFiLFdBSmtDLENBQXBDO0FBTUFzUSxVQUFBQSxhQUFhLEdBQUdDLHFCQUFxQixDQUFDaFAsSUFBdEIsQ0FBMkJBLElBQTNCLENBQWdDQyxjQUFoRDtBQUNELFNBUkQsQ0FRRSxPQUFPTyxLQUFQLEVBQWM7QUFDZCwyQkFBSSxrQkFBSixFQUF3QkEsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUF6QyxFQUFnRCxPQUFoRDtBQUNEOztBQUNELGNBQU0sS0FBS3JDLFlBQUwsQ0FDSkMsT0FESSxFQUVKQyxPQUZJLEVBR0osYUFISSxFQUlKd08sT0FKSSxFQUtKLENBQUNrQyxhQUFhLElBQUksRUFBbEIsRUFBc0I3USxHQUF0QixDQUEyQnlMLENBQUQsSUFBT0EsQ0FBQyxDQUFDekgsRUFBbkMsQ0FMSSxFQU1KekQsS0FOSSxDQUFOO0FBUUQ7O0FBRUQsWUFBTUosT0FBTyxDQUFDbU8sS0FBUixDQUFjUixjQUFLak8sSUFBTCxDQUFVZ08sc0RBQVYsRUFBdURKLE1BQXZELEVBQStEbEssSUFBL0QsQ0FBZCxDQUFOO0FBRUEsYUFBT3lKLFFBQVEsQ0FBQ3VCLEVBQVQsQ0FBWTtBQUNqQmxCLFFBQUFBLElBQUksRUFBRTtBQUNKbUIsVUFBQUEsT0FBTyxFQUFFLElBREw7QUFFSmpNLFVBQUFBLE9BQU8sRUFBRyxVQUFTZ0IsSUFBSztBQUZwQjtBQURXLE9BQVosQ0FBUDtBQU1ELEtBOVBELENBOFBFLE9BQU9qQixLQUFQLEVBQWM7QUFDZCx1QkFBSSwrQkFBSixFQUFxQ0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUF0RDtBQUNBLGFBQU8sa0NBQWNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUQwSyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7Ozs7QUFPQSxRQUFNK0QsbUJBQU4sQ0FDRTdRLE9BREYsRUFFRXdCLE9BRkYsRUFHRXNMLFFBSEYsRUFJRTtBQUNBLFFBQUk7QUFDRix1QkFBSSwrQkFBSixFQUFzQyxnQkFBdEMsRUFBdUQsTUFBdkQ7QUFDQSxZQUFNO0FBQUV6SixRQUFBQSxJQUFGO0FBQVFtTCxRQUFBQSxVQUFSO0FBQW9Cbk8sUUFBQUE7QUFBcEIsVUFBOEJtQixPQUFPLENBQUMyTCxJQUE1QztBQUNBLFlBQU07QUFBRTVKLFFBQUFBO0FBQUYsVUFBYy9CLE9BQU8sQ0FBQ2pDLE1BQTVCO0FBRUEsWUFBTVUsT0FBTyxHQUFHLElBQUlvTixzQkFBSixFQUFoQjtBQUVBLFlBQU07QUFBRUMsUUFBQUEsUUFBUSxFQUFFQztBQUFaLFVBQXVCLE1BQU12TixPQUFPLENBQUNvQixLQUFSLENBQWNvTSxRQUFkLENBQXVCQyxjQUF2QixDQUFzQ2pNLE9BQXRDLEVBQStDeEIsT0FBL0MsQ0FBbkM7QUFDQTtBQUNBLGtEQUEyQjBOLDhDQUEzQjtBQUNBLGtEQUEyQkMsc0RBQTNCO0FBQ0Esa0RBQTJCQyxjQUFLak8sSUFBTCxDQUFVZ08sc0RBQVYsRUFBdURKLE1BQXZELENBQTNCO0FBRUEsVUFBSXVELGdCQUFnQixHQUFHLEVBQXZCO0FBQ0EsVUFBSTdELE1BQU0sR0FBRyxFQUFiOztBQUNBLFVBQUk7QUFDRjZELFFBQUFBLGdCQUFnQixHQUFHLE1BQU05USxPQUFPLENBQUNvQixLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Q0MsT0FBdkMsQ0FDdkIsS0FEdUIsRUFFdEIsV0FBVStCLE9BQVEsMkJBRkksRUFHdkIsRUFIdUIsRUFJdkI7QUFBRTdCLFVBQUFBLFNBQVMsRUFBRXJCO0FBQWIsU0FKdUIsQ0FBekI7QUFNRCxPQVBELENBT0UsT0FBTytCLEtBQVAsRUFBYztBQUNkLHlCQUFJLGtCQUFKLEVBQXdCQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQXpDLEVBQWdELE9BQWhEO0FBQ0Q7O0FBRUQsWUFBTSxLQUFLckMsWUFBTCxDQUFrQkMsT0FBbEIsRUFBMkJDLE9BQTNCLEVBQW9DLGFBQXBDLEVBQW1ELGFBQW5ELEVBQWtFc0QsT0FBbEUsRUFBMkVsRCxLQUEzRSxDQUFOO0FBRUEsVUFBSTBRLFlBQVksR0FBRyxDQUFuQjs7QUFDQSxXQUFLLElBQUk5RSxNQUFULElBQW1CdUQsdUNBQW1CQyxjQUF0QyxFQUFzRDtBQUNwRCxZQUFJdUIsY0FBYyxHQUFHLEtBQXJCO0FBQ0EseUJBQ0UsK0JBREYsRUFFRyxnQkFBZS9FLE1BQU0sQ0FBQzBELFFBQVAsQ0FBZ0JqUixNQUFPLHlCQUZ6QyxFQUdFLE9BSEY7O0FBS0EsYUFBSyxJQUFJd0IsT0FBVCxJQUFvQitMLE1BQU0sQ0FBQzBELFFBQTNCLEVBQXFDO0FBQ25DLGNBQUlzQixpQkFBaUIsR0FBRyxLQUF4Qjs7QUFDQSxjQUNFekMsVUFBVSxDQUFDdUMsWUFBRCxDQUFWLEtBQ0M3USxPQUFPLENBQUMrTCxNQUFSLElBQWtCL0wsT0FBTyxDQUFDNlAsS0FEM0IsQ0FERixFQUdFO0FBQ0EsZ0JBQUl2RSxHQUFHLEdBQUcsQ0FBVjtBQUNBLGtCQUFNMEYsT0FBTyxHQUFHLENBQUNoUixPQUFPLENBQUMrTCxNQUFSLElBQWtCLEVBQW5CLEVBQXVCb0QsTUFBdkIsQ0FBOEJuUCxPQUFPLENBQUM2UCxLQUFSLElBQWlCLEVBQS9DLENBQWhCO0FBQ0EsNkJBQ0UsK0JBREYsRUFFRyxnQkFBZW1CLE9BQU8sQ0FBQ3hTLE1BQU8sdUJBRmpDLEVBR0UsT0FIRjs7QUFLQSxpQkFBSyxJQUFJeVMsSUFBVCxJQUFpQkQsT0FBakIsRUFBMEI7QUFDeEIsa0JBQUlFLG1CQUFtQixHQUFHLEVBQTFCOztBQUNBLGtCQUFJO0FBQ0Ysb0JBQUksQ0FBQ0QsSUFBSSxDQUFDLE1BQUQsQ0FBVCxFQUFtQjtBQUNqQkMsa0JBQUFBLG1CQUFtQixHQUFHLE1BQU1wUixPQUFPLENBQUNvQixLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Q0MsT0FBdkMsQ0FDMUIsS0FEMEIsRUFFekIsV0FBVStCLE9BQVEsV0FBVTROLElBQUksQ0FBQ0UsU0FBVSxJQUFHRixJQUFJLENBQUNqRixhQUFjLEVBRnhDLEVBRzFCLEVBSDBCLEVBSTFCO0FBQUV4SyxvQkFBQUEsU0FBUyxFQUFFckI7QUFBYixtQkFKMEIsQ0FBNUI7QUFNRCxpQkFQRCxNQU9PO0FBQ0wsdUJBQUssSUFBSTBQLEtBQVQsSUFBa0JlLGdCQUFnQixDQUFDbFAsSUFBakIsQ0FBc0JBLElBQXRCLENBQTJCLFVBQTNCLENBQWxCLEVBQTBEO0FBQ3hELHdCQUFJYixNQUFNLENBQUNDLElBQVAsQ0FBWStPLEtBQVosRUFBbUIsQ0FBbkIsTUFBMEJvQixJQUFJLENBQUMsTUFBRCxDQUFsQyxFQUE0QztBQUMxQ0Msc0JBQUFBLG1CQUFtQixDQUFDeFAsSUFBcEIsR0FBMkI7QUFDekJBLHdCQUFBQSxJQUFJLEVBQUVtTztBQURtQix1QkFBM0I7QUFHRDtBQUNGO0FBQ0Y7O0FBRUQsc0JBQU11QixXQUFXLEdBQ2ZGLG1CQUFtQixJQUFJQSxtQkFBbUIsQ0FBQ3hQLElBQTNDLElBQW1Ed1AsbUJBQW1CLENBQUN4UCxJQUFwQixDQUF5QkEsSUFEOUU7O0FBRUEsb0JBQUksQ0FBQ29QLGNBQUwsRUFBcUI7QUFDbkIvUSxrQkFBQUEsT0FBTyxDQUFDTSxVQUFSLENBQW1CO0FBQ2pCQyxvQkFBQUEsSUFBSSxFQUFFeUwsTUFBTSxDQUFDdkwsS0FESTtBQUVqQkMsb0JBQUFBLEtBQUssRUFBRSxJQUZVO0FBR2pCRyxvQkFBQUEsTUFBTSxFQUFFLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsRUFBVjtBQUhTLG1CQUFuQjtBQUtBa1Esa0JBQUFBLGNBQWMsR0FBRyxJQUFqQjtBQUNEOztBQUNELG9CQUFJLENBQUNDLGlCQUFMLEVBQXdCO0FBQ3RCaFIsa0JBQUFBLE9BQU8sQ0FBQ00sVUFBUixDQUFtQjtBQUNqQkMsb0JBQUFBLElBQUksRUFBRU4sT0FBTyxDQUFDcVIsUUFERztBQUVqQjVRLG9CQUFBQSxLQUFLLEVBQUU7QUFGVSxtQkFBbkI7QUFJQVYsa0JBQUFBLE9BQU8sQ0FBQ00sVUFBUixDQUFtQjtBQUNqQkMsb0JBQUFBLElBQUksRUFBRU4sT0FBTyxDQUFDc1IsSUFERztBQUVqQjdRLG9CQUFBQSxLQUFLLEVBQUU7QUFBRUMsc0JBQUFBLFFBQVEsRUFBRSxFQUFaO0FBQWdCQyxzQkFBQUEsS0FBSyxFQUFFO0FBQXZCLHFCQUZVO0FBR2pCQyxvQkFBQUEsTUFBTSxFQUFFLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsRUFBVjtBQUhTLG1CQUFuQjtBQUtBbVEsa0JBQUFBLGlCQUFpQixHQUFHLElBQXBCO0FBQ0Q7O0FBQ0Qsb0JBQUlLLFdBQUosRUFBaUI7QUFDZix1QkFBSyxJQUFJRyxjQUFULElBQTJCMVEsTUFBTSxDQUFDQyxJQUFQLENBQVlzUSxXQUFaLENBQTNCLEVBQXFEO0FBQ25ELHdCQUFJakcsS0FBSyxDQUFDQyxPQUFOLENBQWNnRyxXQUFXLENBQUNHLGNBQUQsQ0FBekIsQ0FBSixFQUFnRDtBQUM5QztBQUNBLDBCQUFJTixJQUFJLENBQUNPLFFBQVQsRUFBbUI7QUFDakIsNEJBQUkxQixNQUFNLEdBQUcsRUFBYjtBQUNBc0Isd0JBQUFBLFdBQVcsQ0FBQ0csY0FBRCxDQUFYLENBQTRCdkgsT0FBNUIsQ0FBcUMrRixHQUFELElBQVM7QUFDM0MsOEJBQUksQ0FBQ0QsTUFBTSxDQUFDQyxHQUFHLENBQUNDLFNBQUwsQ0FBWCxFQUE0QjtBQUMxQkYsNEJBQUFBLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDQyxTQUFMLENBQU4sR0FBd0IsRUFBeEI7QUFDRDs7QUFDREYsMEJBQUFBLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDQyxTQUFMLENBQU4sQ0FBc0JqUixJQUF0QixDQUEyQmdSLEdBQTNCO0FBQ0QseUJBTEQ7QUFNQWxQLHdCQUFBQSxNQUFNLENBQUNDLElBQVAsQ0FBWWdQLE1BQVosRUFBb0I5RixPQUFwQixDQUE2QmpJLEtBQUQsSUFBVztBQUNyQyw4QkFBSWtPLE9BQU8sR0FBRyxDQUFkO0FBQ0FILDBCQUFBQSxNQUFNLENBQUMvTixLQUFELENBQU4sQ0FBY2lJLE9BQWQsQ0FBc0IsQ0FBQ3FCLENBQUQsRUFBSXBNLENBQUosS0FBVTtBQUM5QixnQ0FDRTRCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZdUssQ0FBWixFQUFlN00sTUFBZixHQUF3QnFDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZZ1AsTUFBTSxDQUFDL04sS0FBRCxDQUFOLENBQWNrTyxPQUFkLENBQVosRUFBb0N6UixNQUQ5RCxFQUVFO0FBQ0F5Uiw4QkFBQUEsT0FBTyxHQUFHaFIsQ0FBVjtBQUNEO0FBQ0YsMkJBTkQ7QUFPQSxnQ0FBTTBFLE9BQU8sR0FBRzlDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZZ1AsTUFBTSxDQUFDL04sS0FBRCxDQUFOLENBQWNrTyxPQUFkLENBQVosQ0FBaEI7QUFDQSxnQ0FBTTVELElBQUksR0FBR3lELE1BQU0sQ0FBQy9OLEtBQUQsQ0FBTixDQUFjbkMsR0FBZCxDQUFtQnlMLENBQUQsSUFBTztBQUNwQyxnQ0FBSW9CLEdBQUcsR0FBRyxFQUFWO0FBQ0E5SSw0QkFBQUEsT0FBTyxDQUFDcUcsT0FBUixDQUFpQjdLLEdBQUQsSUFBUztBQUN2QnNOLDhCQUFBQSxHQUFHLENBQUMxTixJQUFKLENBQ0UsT0FBT3NNLENBQUMsQ0FBQ2xNLEdBQUQsQ0FBUixLQUFrQixRQUFsQixHQUNJa00sQ0FBQyxDQUFDbE0sR0FBRCxDQURMLEdBRUlnTSxLQUFLLENBQUNDLE9BQU4sQ0FBY0MsQ0FBQyxDQUFDbE0sR0FBRCxDQUFmLElBQ0FrTSxDQUFDLENBQUNsTSxHQUFELENBQUQsQ0FBT1MsR0FBUCxDQUFZeUwsQ0FBRCxJQUFPO0FBQ2hCLHVDQUFPQSxDQUFDLEdBQUcsSUFBWDtBQUNELCtCQUZELENBREEsR0FJQUUsSUFBSSxDQUFDQyxTQUFMLENBQWVILENBQUMsQ0FBQ2xNLEdBQUQsQ0FBaEIsQ0FQTjtBQVNELDZCQVZEO0FBV0EsbUNBQU9zTixHQUFQO0FBQ0QsMkJBZFksQ0FBYjtBQWVBOUksMEJBQUFBLE9BQU8sQ0FBQ3FHLE9BQVIsQ0FBZ0IsQ0FBQ3NDLEdBQUQsRUFBTXJOLENBQU4sS0FBWTtBQUMxQjBFLDRCQUFBQSxPQUFPLENBQUMxRSxDQUFELENBQVAsR0FBYXFOLEdBQUcsQ0FBQyxDQUFELENBQUgsQ0FBT0MsV0FBUCxLQUF1QkQsR0FBRyxDQUFDRSxLQUFKLENBQVUsQ0FBVixDQUFwQztBQUNELDJCQUZEO0FBR0FPLDBCQUFBQSxNQUFNLENBQUNoTyxJQUFQLENBQVk7QUFDVnlCLDRCQUFBQSxLQUFLLEVBQUVSLE9BQU8sQ0FBQ2dMLE1BQVIsQ0FBZSxDQUFmLEVBQWtCakosS0FBbEIsQ0FERztBQUVWekMsNEJBQUFBLElBQUksRUFBRSxPQUZJO0FBR1ZxRSw0QkFBQUEsT0FIVTtBQUlWMEksNEJBQUFBO0FBSlUsMkJBQVo7QUFNRCx5QkFsQ0Q7QUFtQ0QsdUJBM0NELE1BMkNPLElBQUlrRixjQUFjLENBQUN2RixhQUFmLEtBQWlDLFFBQXJDLEVBQStDO0FBQ3BEZSx3QkFBQUEsTUFBTSxDQUFDaE8sSUFBUCxDQUNFLEdBQUcsS0FBSzJNLGVBQUwsQ0FBcUIwRixXQUFXLENBQUNHLGNBQUQsQ0FBaEMsRUFBa0R2UixPQUFsRCxFQUEyRHNMLEdBQTNELENBREw7QUFHRCx1QkFKTSxNQUlBO0FBQ0wsNkJBQUssSUFBSTRFLEdBQVQsSUFBZ0JrQixXQUFXLENBQUNHLGNBQUQsQ0FBM0IsRUFBNkM7QUFDM0N4RSwwQkFBQUEsTUFBTSxDQUFDaE8sSUFBUCxDQUFZLEdBQUcsS0FBSzJNLGVBQUwsQ0FBcUJ3RSxHQUFyQixFQUEwQmxRLE9BQTFCLEVBQW1Dc0wsR0FBbkMsQ0FBZjtBQUNEO0FBQ0Y7QUFDRixxQkF0REQsTUFzRE87QUFDTDtBQUNBLDBCQUFJMkYsSUFBSSxDQUFDUSxNQUFULEVBQWlCO0FBQ2YsOEJBQU07QUFBQ3RCLDBCQUFBQSxXQUFEO0FBQWF1QiwwQkFBQUEsSUFBYjtBQUFrQkMsMEJBQUFBLGVBQWxCO0FBQWtDQywwQkFBQUEsVUFBbEM7QUFBNkMsNkJBQUdDO0FBQWhELDRCQUF3RFQsV0FBVyxDQUFDRyxjQUFELENBQXpFO0FBQ0F4RSx3QkFBQUEsTUFBTSxDQUFDaE8sSUFBUCxDQUNFLEdBQUcsS0FBSzJNLGVBQUwsQ0FBcUJtRyxJQUFyQixFQUEyQjdSLE9BQTNCLEVBQW9Dc0wsR0FBcEMsQ0FETCxFQUVFLElBQUlvRyxJQUFJLElBQUlBLElBQUksQ0FBQ0ksVUFBYixHQUEwQixLQUFLcEcsZUFBTCxDQUFxQmdHLElBQUksQ0FBQ0ksVUFBMUIsRUFBc0M7QUFBQzFGLDBCQUFBQSxJQUFJLEVBQUMsQ0FBQyxZQUFEO0FBQU4seUJBQXRDLEVBQTZELENBQTdELENBQTFCLEdBQTRGLEVBQWhHLENBRkYsRUFHRSxJQUFJc0YsSUFBSSxJQUFJQSxJQUFJLENBQUNLLFNBQWIsR0FBeUIsS0FBS3JHLGVBQUwsQ0FBcUJnRyxJQUFJLENBQUNLLFNBQTFCLEVBQXFDO0FBQUMzRiwwQkFBQUEsSUFBSSxFQUFDLENBQUMsV0FBRDtBQUFOLHlCQUFyQyxFQUEyRCxDQUEzRCxDQUF6QixHQUF5RixFQUE3RixDQUhGLEVBSUUsSUFBSXVGLGVBQWUsR0FBRyxLQUFLakcsZUFBTCxDQUFxQmlHLGVBQXJCLEVBQXNDO0FBQUN2RiwwQkFBQUEsSUFBSSxFQUFDLENBQUMsaUJBQUQ7QUFBTix5QkFBdEMsRUFBa0UsQ0FBbEUsQ0FBSCxHQUEwRSxFQUE3RixDQUpGLEVBS0UsSUFBSXdGLFVBQVUsR0FBRyxLQUFLbEcsZUFBTCxDQUFxQmtHLFVBQXJCLEVBQWlDO0FBQUN4RiwwQkFBQUEsSUFBSSxFQUFDLENBQUMsWUFBRDtBQUFOLHlCQUFqQyxFQUF3RCxDQUF4RCxDQUFILEdBQWdFLEVBQTlFLENBTEY7QUFPQSw0QkFBSWdFLFFBQVEsR0FBRyxFQUFmO0FBQ0F2UCx3QkFBQUEsTUFBTSxDQUFDQyxJQUFQLENBQVlkLE9BQU8sQ0FBQzBQLElBQXBCLEVBQTBCMUYsT0FBMUIsQ0FBbUNxQixDQUFELElBQU87QUFDdkMrRSwwQkFBQUEsUUFBUSxDQUFDclIsSUFBVCxDQUFjc00sQ0FBZDtBQUNELHlCQUZEO0FBR0EsOEJBQU0xSCxPQUFPLEdBQUcsQ0FDZCxFQURjLEVBRWQsR0FBR3lNLFFBQVEsQ0FBQ3pSLE1BQVQsQ0FBaUIwTSxDQUFELElBQU9BLENBQUMsS0FBSyxXQUFOLElBQXFCQSxDQUFDLEtBQUssV0FBbEQsQ0FGVyxDQUFoQjtBQUlBLDRCQUFJZ0IsSUFBSSxHQUFHLEVBQVg7QUFDQThELHdCQUFBQSxXQUFXLENBQUNuRyxPQUFaLENBQXFCcUIsQ0FBRCxJQUFPO0FBQ3pCLDhCQUFJb0IsR0FBRyxHQUFHLEVBQVY7QUFDQUEsMEJBQUFBLEdBQUcsQ0FBQzFOLElBQUosQ0FBU3NNLENBQUMsQ0FBQzJHLEdBQVg7QUFDQXJPLDBCQUFBQSxPQUFPLENBQUNxRyxPQUFSLENBQWlCcUcsQ0FBRCxJQUFPO0FBQ3JCLGdDQUFJQSxDQUFDLEtBQUssRUFBVixFQUFjO0FBQ1o1RCw4QkFBQUEsR0FBRyxDQUFDMU4sSUFBSixDQUFTc00sQ0FBQyxDQUFDcUUsSUFBRixDQUFPNUosT0FBUCxDQUFldUssQ0FBZixJQUFvQixDQUFDLENBQXJCLEdBQXlCLEtBQXpCLEdBQWlDLElBQTFDO0FBQ0Q7QUFDRiwyQkFKRDtBQUtBNUQsMEJBQUFBLEdBQUcsQ0FBQzFOLElBQUosQ0FBU3NNLENBQUMsQ0FBQ2lGLGVBQVg7QUFDQWpFLDBCQUFBQSxJQUFJLENBQUN0TixJQUFMLENBQVUwTixHQUFWO0FBQ0QseUJBVkQ7QUFXQTlJLHdCQUFBQSxPQUFPLENBQUNxRyxPQUFSLENBQWdCLENBQUNxQixDQUFELEVBQUlDLEdBQUosS0FBWTtBQUMxQjNILDBCQUFBQSxPQUFPLENBQUMySCxHQUFELENBQVAsR0FBZXRMLE9BQU8sQ0FBQzBQLElBQVIsQ0FBYXJFLENBQWIsQ0FBZjtBQUNELHlCQUZEO0FBR0ExSCx3QkFBQUEsT0FBTyxDQUFDNUUsSUFBUixDQUFhLElBQWI7QUFDQWdPLHdCQUFBQSxNQUFNLENBQUNoTyxJQUFQLENBQVk7QUFDVnlCLDBCQUFBQSxLQUFLLEVBQUUsdUJBREc7QUFFVmxCLDBCQUFBQSxJQUFJLEVBQUUsT0FGSTtBQUdWcUUsMEJBQUFBLE9BSFU7QUFJVjBJLDBCQUFBQTtBQUpVLHlCQUFaO0FBTUQsdUJBdkNELE1BdUNPO0FBQ0xVLHdCQUFBQSxNQUFNLENBQUNoTyxJQUFQLENBQ0UsR0FBRyxLQUFLMk0sZUFBTCxDQUFxQjBGLFdBQVcsQ0FBQ0csY0FBRCxDQUFoQyxFQUFrRHZSLE9BQWxELEVBQTJEc0wsR0FBM0QsQ0FETDtBQUdEO0FBQ0Y7QUFDRjtBQUNGLGlCQXhHRCxNQXdHTztBQUNMO0FBQ0F2TCxrQkFBQUEsT0FBTyxDQUFDTSxVQUFSLENBQW1CO0FBQ2pCQyxvQkFBQUEsSUFBSSxFQUFFLENBQ0osOEVBREksRUFFSjtBQUNFQSxzQkFBQUEsSUFBSSxFQUFHLEdBQUVOLE9BQU8sQ0FBQ3FSLFFBQVIsQ0FBaUJ2UCxXQUFqQixFQUErQixpQkFEMUM7QUFFRStJLHNCQUFBQSxJQUFJLEVBQUU3SyxPQUFPLENBQUNpUyxRQUZoQjtBQUdFeFIsc0JBQUFBLEtBQUssRUFBRTtBQUFFQyx3QkFBQUEsUUFBUSxFQUFFLEVBQVo7QUFBZ0JDLHdCQUFBQSxLQUFLLEVBQUU7QUFBdkI7QUFIVCxxQkFGSSxDQURXO0FBU2pCQyxvQkFBQUEsTUFBTSxFQUFFLENBQUMsQ0FBRCxFQUFJLENBQUosRUFBTyxDQUFQLEVBQVUsRUFBVjtBQVRTLG1CQUFuQjtBQVdEO0FBQ0YsZUE5SkQsQ0E4SkUsT0FBT3NCLEtBQVAsRUFBYztBQUNkLGlDQUFJLGtCQUFKLEVBQXdCQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQXpDLEVBQWdELE9BQWhEO0FBQ0Q7O0FBQ0RvSixjQUFBQSxHQUFHO0FBQ0o7O0FBQ0QsaUJBQUssTUFBTWlGLEtBQVgsSUFBb0J4RCxNQUFwQixFQUE0QjtBQUMxQmhOLGNBQUFBLE9BQU8sQ0FBQ3lRLGVBQVIsQ0FBd0IsQ0FBQ0QsS0FBRCxDQUF4QjtBQUNEO0FBQ0Y7O0FBQ0RNLFVBQUFBLFlBQVk7QUFDWjlELFVBQUFBLE1BQU0sR0FBRyxFQUFUO0FBQ0Q7QUFDRjs7QUFFRCxZQUFNaE4sT0FBTyxDQUFDbU8sS0FBUixDQUFjUixjQUFLak8sSUFBTCxDQUFVZ08sc0RBQVYsRUFBdURKLE1BQXZELEVBQStEbEssSUFBL0QsQ0FBZCxDQUFOO0FBRUEsYUFBT3lKLFFBQVEsQ0FBQ3VCLEVBQVQsQ0FBWTtBQUNqQmxCLFFBQUFBLElBQUksRUFBRTtBQUNKbUIsVUFBQUEsT0FBTyxFQUFFLElBREw7QUFFSmpNLFVBQUFBLE9BQU8sRUFBRyxVQUFTZ0IsSUFBSztBQUZwQjtBQURXLE9BQVosQ0FBUDtBQU1ELEtBdk9ELENBdU9FLE9BQU9qQixLQUFQLEVBQWM7QUFDZCx1QkFBSSwrQkFBSixFQUFxQ0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUF0RDtBQUNBLGFBQU8sa0NBQWNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUQwSyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7Ozs7QUFPQSxRQUFNc0YsNEJBQU4sQ0FDRXBTLE9BREYsRUFFRXdCLE9BRkYsRUFHRXNMLFFBSEYsRUFJRTtBQUNBLFFBQUk7QUFDRix1QkFBSSx3Q0FBSixFQUErQyxnQkFBL0MsRUFBZ0UsTUFBaEU7QUFDQSxZQUFNO0FBQUVyTyxRQUFBQSxTQUFGO0FBQWFELFFBQUFBLE9BQWI7QUFBc0J3TyxRQUFBQSxJQUF0QjtBQUE0QjNKLFFBQUFBLElBQTVCO0FBQWtDNkosUUFBQUEsaUJBQWxDO0FBQXFEN00sUUFBQUE7QUFBckQsVUFBK0RtQixPQUFPLENBQUMyTCxJQUE3RTtBQUNBLFlBQU07QUFBRTVKLFFBQUFBO0FBQUYsVUFBYy9CLE9BQU8sQ0FBQ2pDLE1BQTVCO0FBQ0EsWUFBTTtBQUFFMkUsUUFBQUEsSUFBRjtBQUFRQyxRQUFBQTtBQUFSLFVBQWU2SSxJQUFJLElBQUksRUFBN0IsQ0FKRSxDQUtGOztBQUNBLFlBQU0vTSxPQUFPLEdBQUcsSUFBSW9OLHNCQUFKLEVBQWhCO0FBRUEsWUFBTTtBQUFFQyxRQUFBQSxRQUFRLEVBQUVDO0FBQVosVUFBdUIsTUFBTXZOLE9BQU8sQ0FBQ29CLEtBQVIsQ0FBY29NLFFBQWQsQ0FBdUJDLGNBQXZCLENBQXNDak0sT0FBdEMsRUFBK0N4QixPQUEvQyxDQUFuQztBQUNBO0FBQ0Esa0RBQTJCME4sOENBQTNCO0FBQ0Esa0RBQTJCQyxzREFBM0I7QUFDQSxrREFBMkJDLGNBQUtqTyxJQUFMLENBQVVnTyxzREFBVixFQUF1REosTUFBdkQsQ0FBM0I7QUFFQSx1QkFBSSx3Q0FBSixFQUErQyxxQkFBL0MsRUFBcUUsT0FBckU7QUFDQSxZQUFNTSxnQkFBZ0IsR0FBR3JQLE9BQU8sR0FBRyxLQUFLRCxxQkFBTCxDQUEyQkMsT0FBM0IsRUFBb0NDLFNBQXBDLENBQUgsR0FBb0QsS0FBcEYsQ0FmRSxDQWlCRjs7QUFDQSxVQUFJNFQsT0FBTyxHQUFHLEVBQWQ7O0FBQ0EsVUFBSTtBQUNGLGNBQU1sUixhQUFhLEdBQUcsTUFBTW5CLE9BQU8sQ0FBQ29CLEtBQVIsQ0FBY0MsR0FBZCxDQUFrQkMsTUFBbEIsQ0FBeUJDLGFBQXpCLENBQXVDQyxPQUF2QyxDQUMxQixLQUQwQixFQUUxQixTQUYwQixFQUcxQjtBQUFFakMsVUFBQUEsTUFBTSxFQUFFO0FBQUVpRSxZQUFBQSxDQUFDLEVBQUcsTUFBS0QsT0FBUTtBQUFuQjtBQUFWLFNBSDBCLEVBSTFCO0FBQUU3QixVQUFBQSxTQUFTLEVBQUVyQjtBQUFiLFNBSjBCLENBQTVCO0FBTUFnUyxRQUFBQSxPQUFPLEdBQUdsUixhQUFhLENBQUNTLElBQWQsQ0FBbUJBLElBQW5CLENBQXdCQyxjQUF4QixDQUF1QyxDQUF2QyxFQUEwQ3VCLEVBQTFDLENBQTZDa1AsUUFBdkQ7QUFDRCxPQVJELENBUUUsT0FBT2xRLEtBQVAsRUFBYztBQUNkLHlCQUFJLHdDQUFKLEVBQThDQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQS9ELEVBQXNFLE9BQXRFO0FBQ0QsT0E3QkMsQ0ErQkY7OztBQUNBbkMsTUFBQUEsT0FBTyxDQUFDOEIscUJBQVIsQ0FBOEI7QUFDNUJ2QixRQUFBQSxJQUFJLEVBQUUsdUJBRHNCO0FBRTVCRyxRQUFBQSxLQUFLLEVBQUU7QUFGcUIsT0FBOUIsRUFoQ0UsQ0FxQ0Y7O0FBQ0EsWUFBTSxLQUFLTyxnQkFBTCxDQUFzQmxCLE9BQXRCLEVBQStCQyxPQUEvQixFQUF3QyxDQUFDc0QsT0FBRCxDQUF4QyxFQUFtRGxELEtBQW5ELENBQU4sQ0F0Q0UsQ0F3Q0Y7O0FBQ0EsWUFBTWtTLHNCQUFzQixHQUFHLENBQzdCO0FBQ0V2SixRQUFBQSxRQUFRLEVBQUcsaUJBQWdCekYsT0FBUSxXQURyQztBQUVFMEYsUUFBQUEsYUFBYSxFQUFHLCtCQUE4QjFGLE9BQVEsRUFGeEQ7QUFHRWtOLFFBQUFBLEtBQUssRUFBRTtBQUNML1AsVUFBQUEsS0FBSyxFQUFFLFVBREY7QUFFTG1ELFVBQUFBLE9BQU8sRUFDTHdPLE9BQU8sS0FBSyxTQUFaLEdBQ0ksQ0FDRTtBQUFFdk8sWUFBQUEsRUFBRSxFQUFFLE1BQU47QUFBY0MsWUFBQUEsS0FBSyxFQUFFO0FBQXJCLFdBREYsRUFFRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsY0FBTjtBQUFzQkMsWUFBQUEsS0FBSyxFQUFFO0FBQTdCLFdBRkYsRUFHRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCLFdBSEYsRUFJRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsUUFBTjtBQUFnQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXZCLFdBSkYsQ0FESixHQU9JLENBQ0U7QUFBRUQsWUFBQUEsRUFBRSxFQUFFLE1BQU47QUFBY0MsWUFBQUEsS0FBSyxFQUFFO0FBQXJCLFdBREYsRUFFRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsY0FBTjtBQUFzQkMsWUFBQUEsS0FBSyxFQUFFO0FBQTdCLFdBRkYsRUFHRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCLFdBSEYsRUFJRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsUUFBTjtBQUFnQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXZCLFdBSkYsRUFLRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsYUFBTjtBQUFxQkMsWUFBQUEsS0FBSyxFQUFFO0FBQTVCLFdBTEY7QUFWRDtBQUhULE9BRDZCLEVBdUI3QjtBQUNFaUYsUUFBQUEsUUFBUSxFQUFHLGlCQUFnQnpGLE9BQVEsWUFEckM7QUFFRTBGLFFBQUFBLGFBQWEsRUFBRyxnQ0FBK0IxRixPQUFRLEVBRnpEO0FBR0VrTixRQUFBQSxLQUFLLEVBQUU7QUFDTC9QLFVBQUFBLEtBQUssRUFBRSxXQURGO0FBRUxtRCxVQUFBQSxPQUFPLEVBQ0x3TyxPQUFPLEtBQUssU0FBWixHQUNJLENBQ0U7QUFBRXZPLFlBQUFBLEVBQUUsRUFBRSxNQUFOO0FBQWNDLFlBQUFBLEtBQUssRUFBRTtBQUFyQixXQURGLEVBRUU7QUFBRUQsWUFBQUEsRUFBRSxFQUFFLEtBQU47QUFBYUMsWUFBQUEsS0FBSyxFQUFFO0FBQXBCLFdBRkYsRUFHRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsVUFBTjtBQUFrQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXpCLFdBSEYsRUFJRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjQyxZQUFBQSxLQUFLLEVBQUU7QUFBckIsV0FKRixDQURKLEdBT0ksQ0FDRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjQyxZQUFBQSxLQUFLLEVBQUU7QUFBckIsV0FERixFQUVFO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxPQUFOO0FBQWVDLFlBQUFBLEtBQUssRUFBRTtBQUF0QixXQUZGLEVBR0U7QUFBRUQsWUFBQUEsRUFBRSxFQUFFLE1BQU47QUFBY0MsWUFBQUEsS0FBSyxFQUFFO0FBQXJCLFdBSEYsRUFJRTtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsT0FBTjtBQUFlQyxZQUFBQSxLQUFLLEVBQUU7QUFBdEIsV0FKRjtBQVZELFNBSFQ7QUFvQkV5TyxRQUFBQSxnQkFBZ0IsRUFBRzFNLElBQUQsSUFDaEJ1TSxPQUFPLEtBQUssU0FBWixHQUF3QnZNLElBQXhCLEdBQStCLEVBQUUsR0FBR0EsSUFBTDtBQUFXMk0sVUFBQUEsS0FBSyxFQUFFQyxpQ0FBbUI1TSxJQUFJLENBQUMyTSxLQUF4QjtBQUFsQjtBQXJCbkMsT0F2QjZCLEVBOEM3QjtBQUNFekosUUFBQUEsUUFBUSxFQUFHLGlCQUFnQnpGLE9BQVEsUUFEckM7QUFFRTBGLFFBQUFBLGFBQWEsRUFBRyw0QkFBMkIxRixPQUFRLEVBRnJEO0FBR0VrTixRQUFBQSxLQUFLLEVBQUU7QUFDTC9QLFVBQUFBLEtBQUssRUFBRSxlQURGO0FBRUxtRCxVQUFBQSxPQUFPLEVBQ0x3TyxPQUFPLEtBQUssU0FBWixHQUNJLENBQ0U7QUFBRXZPLFlBQUFBLEVBQUUsRUFBRSxVQUFOO0FBQWtCQyxZQUFBQSxLQUFLLEVBQUU7QUFBekIsV0FERixFQUVFO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxZQUFOO0FBQW9CQyxZQUFBQSxLQUFLLEVBQUU7QUFBM0IsV0FGRixFQUdFO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxTQUFOO0FBQWlCQyxZQUFBQSxLQUFLLEVBQUU7QUFBeEIsV0FIRixFQUlFO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxPQUFOO0FBQWVDLFlBQUFBLEtBQUssRUFBRTtBQUF0QixXQUpGLEVBS0U7QUFBRUQsWUFBQUEsRUFBRSxFQUFFLFVBQU47QUFBa0JDLFlBQUFBLEtBQUssRUFBRTtBQUF6QixXQUxGLENBREosR0FRSSxDQUNFO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxVQUFOO0FBQWtCQyxZQUFBQSxLQUFLLEVBQUU7QUFBekIsV0FERixFQUVFO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxZQUFOO0FBQW9CQyxZQUFBQSxLQUFLLEVBQUU7QUFBM0IsV0FGRixFQUdFO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxPQUFOO0FBQWVDLFlBQUFBLEtBQUssRUFBRTtBQUF0QixXQUhGLEVBSUU7QUFBRUQsWUFBQUEsRUFBRSxFQUFFLFVBQU47QUFBa0JDLFlBQUFBLEtBQUssRUFBRTtBQUF6QixXQUpGO0FBWEQsU0FIVDtBQXFCRXlPLFFBQUFBLGdCQUFnQixFQUFHMU0sSUFBRCxLQUFXLEVBQzNCLEdBQUdBLElBRHdCO0FBRTNCNk0sVUFBQUEsUUFBUSxFQUFFN00sSUFBSSxDQUFDOE0sS0FBTCxDQUFXQyxFQUZNO0FBRzNCQyxVQUFBQSxVQUFVLEVBQUVoTixJQUFJLENBQUM4TSxLQUFMLENBQVdHO0FBSEksU0FBWDtBQXJCcEIsT0E5QzZCLEVBeUU3QjtBQUNFL0osUUFBQUEsUUFBUSxFQUFHLGlCQUFnQnpGLE9BQVEsV0FEckM7QUFFRTBGLFFBQUFBLGFBQWEsRUFBRywrQkFBOEIxRixPQUFRLEVBRnhEO0FBR0VrTixRQUFBQSxLQUFLLEVBQUU7QUFDTC9QLFVBQUFBLEtBQUssRUFBRSxvQkFERjtBQUVMbUQsVUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRUMsWUFBQUEsRUFBRSxFQUFFLE1BQU47QUFBY0MsWUFBQUEsS0FBSyxFQUFFO0FBQXJCLFdBRE8sRUFFUDtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsS0FBTjtBQUFhQyxZQUFBQSxLQUFLLEVBQUU7QUFBcEIsV0FGTyxFQUdQO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxPQUFOO0FBQWVDLFlBQUFBLEtBQUssRUFBRTtBQUF0QixXQUhPLEVBSVA7QUFBRUQsWUFBQUEsRUFBRSxFQUFFLEtBQU47QUFBYUMsWUFBQUEsS0FBSyxFQUFFO0FBQXBCLFdBSk8sRUFLUDtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsTUFBTjtBQUFjQyxZQUFBQSxLQUFLLEVBQUU7QUFBckIsV0FMTztBQUZKO0FBSFQsT0F6RTZCLEVBdUY3QjtBQUNFaUYsUUFBQUEsUUFBUSxFQUFHLGlCQUFnQnpGLE9BQVEsVUFEckM7QUFFRTBGLFFBQUFBLGFBQWEsRUFBRyw4QkFBNkIxRixPQUFRLEVBRnZEO0FBR0VrTixRQUFBQSxLQUFLLEVBQUU7QUFDTC9QLFVBQUFBLEtBQUssRUFBRSxrQkFERjtBQUVMbUQsVUFBQUEsT0FBTyxFQUFFLENBQ1A7QUFBRUMsWUFBQUEsRUFBRSxFQUFFLE9BQU47QUFBZUMsWUFBQUEsS0FBSyxFQUFFO0FBQXRCLFdBRE8sRUFFUDtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCLFdBRk8sRUFHUDtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsU0FBTjtBQUFpQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXhCLFdBSE8sRUFJUDtBQUFFRCxZQUFBQSxFQUFFLEVBQUUsT0FBTjtBQUFlQyxZQUFBQSxLQUFLLEVBQUU7QUFBdEIsV0FKTyxFQUtQO0FBQUVELFlBQUFBLEVBQUUsRUFBRSxXQUFOO0FBQW1CQyxZQUFBQSxLQUFLLEVBQUU7QUFBMUIsV0FMTztBQUZKO0FBSFQsT0F2RjZCLENBQS9CO0FBdUdBc08sTUFBQUEsT0FBTyxLQUFLLFNBQVosSUFDRUUsc0JBQXNCLENBQUN0VCxJQUF2QixDQUE0QjtBQUMxQitKLFFBQUFBLFFBQVEsRUFBRyxpQkFBZ0J6RixPQUFRLFdBRFQ7QUFFMUIwRixRQUFBQSxhQUFhLEVBQUcsK0JBQThCMUYsT0FBUSxFQUY1QjtBQUcxQmtOLFFBQUFBLEtBQUssRUFBRTtBQUNML1AsVUFBQUEsS0FBSyxFQUFFLGlCQURGO0FBRUxtRCxVQUFBQSxPQUFPLEVBQUUsQ0FBQztBQUFFQyxZQUFBQSxFQUFFLEVBQUUsUUFBTjtBQUFnQkMsWUFBQUEsS0FBSyxFQUFFO0FBQXZCLFdBQUQ7QUFGSjtBQUhtQixPQUE1QixDQURGOztBQVVBLFlBQU1pUCxnQkFBZ0IsR0FBRyxNQUFPQyxxQkFBUCxJQUFpQztBQUN4RCxZQUFJO0FBQ0YsMkJBQ0Usd0NBREYsRUFFRUEscUJBQXFCLENBQUNoSyxhQUZ4QixFQUdFLE9BSEY7QUFNQSxnQkFBTWlLLGlCQUFpQixHQUFHLE1BQU1sVCxPQUFPLENBQUNvQixLQUFSLENBQWNDLEdBQWQsQ0FBa0JDLE1BQWxCLENBQXlCQyxhQUF6QixDQUF1Q0MsT0FBdkMsQ0FDOUIsS0FEOEIsRUFFOUJ5UixxQkFBcUIsQ0FBQ2pLLFFBRlEsRUFHOUIsRUFIOEIsRUFJOUI7QUFBRXRILFlBQUFBLFNBQVMsRUFBRXJCO0FBQWIsV0FKOEIsQ0FBaEM7QUFPQSxnQkFBTThTLFNBQVMsR0FDYkQsaUJBQWlCLElBQ2pCQSxpQkFBaUIsQ0FBQ3RSLElBRGxCLElBRUFzUixpQkFBaUIsQ0FBQ3RSLElBQWxCLENBQXVCQSxJQUZ2QixJQUdBc1IsaUJBQWlCLENBQUN0UixJQUFsQixDQUF1QkEsSUFBdkIsQ0FBNEJDLGNBSjlCOztBQUtBLGNBQUlzUixTQUFKLEVBQWU7QUFDYixtQkFBTyxFQUNMLEdBQUdGLHFCQUFxQixDQUFDeEMsS0FEcEI7QUFFTHpNLGNBQUFBLEtBQUssRUFBRWlQLHFCQUFxQixDQUFDVCxnQkFBdEIsR0FDSFcsU0FBUyxDQUFDclQsR0FBVixDQUFjbVQscUJBQXFCLENBQUNULGdCQUFwQyxDQURHLEdBRUhXO0FBSkMsYUFBUDtBQU1EO0FBQ0YsU0EzQkQsQ0EyQkUsT0FBTy9RLEtBQVAsRUFBYztBQUNkLDJCQUFJLHdDQUFKLEVBQThDQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQS9ELEVBQXNFLE9BQXRFO0FBQ0Q7QUFDRixPQS9CRDs7QUFpQ0EsVUFBSTRLLElBQUosRUFBVTtBQUNSLGNBQU0sS0FBSy9JLG1CQUFMLENBQ0pqRSxPQURJLEVBRUpDLE9BRkksRUFHSixRQUhJLEVBSUosY0FKSSxFQUtKSSxLQUxJLEVBTUo2RCxJQU5JLEVBT0pDLEVBUEksRUFRSjBKLGdCQUFnQixHQUFHLDRDQVJmLEVBU0pYLGlCQVRJLEVBVUozSixPQVZJLENBQU47QUFZRCxPQXhNQyxDQTBNRjs7O0FBQ0EsT0FBQyxNQUFNakIsT0FBTyxDQUFDdUMsR0FBUixDQUFZME4sc0JBQXNCLENBQUN6UyxHQUF2QixDQUEyQmtULGdCQUEzQixDQUFaLENBQVAsRUFDR25VLE1BREgsQ0FDVzRSLEtBQUQsSUFBV0EsS0FEckIsRUFFR3ZHLE9BRkgsQ0FFWXVHLEtBQUQsSUFBV3hRLE9BQU8sQ0FBQzJELGNBQVIsQ0FBdUI2TSxLQUF2QixDQUZ0QixFQTNNRSxDQStNRjs7QUFDQSxZQUFNeFEsT0FBTyxDQUFDbU8sS0FBUixDQUFjUixjQUFLak8sSUFBTCxDQUFVZ08sc0RBQVYsRUFBdURKLE1BQXZELEVBQStEbEssSUFBL0QsQ0FBZCxDQUFOO0FBRUEsYUFBT3lKLFFBQVEsQ0FBQ3VCLEVBQVQsQ0FBWTtBQUNqQmxCLFFBQUFBLElBQUksRUFBRTtBQUNKbUIsVUFBQUEsT0FBTyxFQUFFLElBREw7QUFFSmpNLFVBQUFBLE9BQU8sRUFBRyxVQUFTZ0IsSUFBSztBQUZwQjtBQURXLE9BQVosQ0FBUDtBQU1ELEtBeE5ELENBd05FLE9BQU9qQixLQUFQLEVBQWM7QUFDZCx1QkFBSSwrQkFBSixFQUFxQ0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUF0RDtBQUNBLGFBQU8sa0NBQWNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUQwSyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7Ozs7QUFPQSxRQUFNc0csVUFBTixDQUNFcFQsT0FERixFQUVFd0IsT0FGRixFQUdFc0wsUUFIRixFQUlFO0FBQ0EsUUFBSTtBQUNGLHVCQUFJLHNCQUFKLEVBQTZCLDBCQUE3QixFQUF3RCxNQUF4RDtBQUNBLFlBQU07QUFBRVEsUUFBQUEsUUFBUSxFQUFFQztBQUFaLFVBQXVCLE1BQU12TixPQUFPLENBQUNvQixLQUFSLENBQWNvTSxRQUFkLENBQXVCQyxjQUF2QixDQUFzQ2pNLE9BQXRDLEVBQStDeEIsT0FBL0MsQ0FBbkM7QUFDQTtBQUNBLGtEQUEyQjBOLDhDQUEzQjtBQUNBLGtEQUEyQkMsc0RBQTNCOztBQUNBLFlBQU0wRixvQkFBb0IsR0FBR3pGLGNBQUtqTyxJQUFMLENBQVVnTyxzREFBVixFQUF1REosTUFBdkQsQ0FBN0I7O0FBQ0Esa0RBQTJCOEYsb0JBQTNCO0FBQ0EsdUJBQUksc0JBQUosRUFBNkIsY0FBYUEsb0JBQXFCLEVBQS9ELEVBQWtFLE9BQWxFOztBQUVBLFlBQU1DLGlCQUFpQixHQUFHLENBQUNDLENBQUQsRUFBSUMsQ0FBSixLQUFXRCxDQUFDLENBQUNFLElBQUYsR0FBU0QsQ0FBQyxDQUFDQyxJQUFYLEdBQWtCLENBQWxCLEdBQXNCRixDQUFDLENBQUNFLElBQUYsR0FBU0QsQ0FBQyxDQUFDQyxJQUFYLEdBQWtCLENBQUMsQ0FBbkIsR0FBdUIsQ0FBbEY7O0FBRUEsWUFBTUMsT0FBTyxHQUFHQyxZQUFHQyxXQUFILENBQWVQLG9CQUFmLEVBQXFDdlQsR0FBckMsQ0FBMEMrVCxJQUFELElBQVU7QUFDakUsY0FBTUMsS0FBSyxHQUFHSCxZQUFHSSxRQUFILENBQVlWLG9CQUFvQixHQUFHLEdBQXZCLEdBQTZCUSxJQUF6QyxDQUFkLENBRGlFLENBRWpFO0FBQ0E7OztBQUNBLGNBQU1HLGNBQWMsR0FBRyxDQUFDLFdBQUQsRUFBYyxPQUFkLEVBQXVCLE9BQXZCLEVBQWdDLE9BQWhDLEVBQXlDQyxJQUF6QyxDQUNwQmpILElBQUQsSUFBVThHLEtBQUssQ0FBRSxHQUFFOUcsSUFBSyxJQUFULENBRE0sQ0FBdkI7QUFHQSxlQUFPO0FBQ0wzSixVQUFBQSxJQUFJLEVBQUV3USxJQUREO0FBRUxLLFVBQUFBLElBQUksRUFBRUosS0FBSyxDQUFDSSxJQUZQO0FBR0xULFVBQUFBLElBQUksRUFBRUssS0FBSyxDQUFDRSxjQUFEO0FBSE4sU0FBUDtBQUtELE9BWmUsQ0FBaEI7O0FBYUEsdUJBQUksc0JBQUosRUFBNkIsNkJBQTRCTixPQUFPLENBQUNoVixNQUFPLFFBQXhFLEVBQWlGLE9BQWpGO0FBQ0F5VixNQUFBQSxPQUFPLENBQUNDLElBQVIsQ0FBYVYsT0FBYixFQUFzQkosaUJBQXRCO0FBQ0EsdUJBQUksc0JBQUosRUFBNkIsa0JBQWlCSSxPQUFPLENBQUNoVixNQUFPLEVBQTdELEVBQWdFLE9BQWhFO0FBQ0EsYUFBT29PLFFBQVEsQ0FBQ3VCLEVBQVQsQ0FBWTtBQUNqQmxCLFFBQUFBLElBQUksRUFBRTtBQUFFdUcsVUFBQUE7QUFBRjtBQURXLE9BQVosQ0FBUDtBQUdELEtBL0JELENBK0JFLE9BQU90UixLQUFQLEVBQWM7QUFDZCx1QkFBSSxzQkFBSixFQUE0QkEsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUE3QztBQUNBLGFBQU8sa0NBQWNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUQwSyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7Ozs7QUFPQSxRQUFNdUgsZUFBTixDQUNFclUsT0FERixFQUVFd0IsT0FGRixFQUdFc0wsUUFIRixFQUlFO0FBQ0EsUUFBSTtBQUNGLHVCQUFJLDJCQUFKLEVBQWtDLFdBQVV0TCxPQUFPLENBQUNqQyxNQUFSLENBQWU4RCxJQUFLLFNBQWhFLEVBQTBFLE9BQTFFO0FBQ0EsWUFBTTtBQUFFaUssUUFBQUEsUUFBUSxFQUFFQztBQUFaLFVBQXVCLE1BQU12TixPQUFPLENBQUNvQixLQUFSLENBQWNvTSxRQUFkLENBQXVCQyxjQUF2QixDQUFzQ2pNLE9BQXRDLEVBQStDeEIsT0FBL0MsQ0FBbkM7O0FBQ0EsWUFBTXNVLGdCQUFnQixHQUFHWCxZQUFHWSxZQUFILENBQ3ZCM0csY0FBS2pPLElBQUwsQ0FBVWdPLHNEQUFWLEVBQXVESixNQUF2RCxFQUErRC9MLE9BQU8sQ0FBQ2pDLE1BQVIsQ0FBZThELElBQTlFLENBRHVCLENBQXpCOztBQUdBLGFBQU95SixRQUFRLENBQUN1QixFQUFULENBQVk7QUFDakJtRyxRQUFBQSxPQUFPLEVBQUU7QUFBRSwwQkFBZ0I7QUFBbEIsU0FEUTtBQUVqQnJILFFBQUFBLElBQUksRUFBRW1IO0FBRlcsT0FBWixDQUFQO0FBSUQsS0FWRCxDQVVFLE9BQU9sUyxLQUFQLEVBQWM7QUFDZCx1QkFBSSwyQkFBSixFQUFpQ0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUFsRDtBQUNBLGFBQU8sa0NBQWNBLEtBQUssQ0FBQ0MsT0FBTixJQUFpQkQsS0FBL0IsRUFBc0MsSUFBdEMsRUFBNEMsR0FBNUMsRUFBaUQwSyxRQUFqRCxDQUFQO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7Ozs7QUFPQSxRQUFNMkgsa0JBQU4sQ0FDRXpVLE9BREYsRUFFRXdCLE9BRkYsRUFHRXNMLFFBSEYsRUFJRTtBQUNBLFFBQUk7QUFDRix1QkFBSSw4QkFBSixFQUFxQyxZQUFXdEwsT0FBTyxDQUFDakMsTUFBUixDQUFlOEQsSUFBSyxTQUFwRSxFQUE4RSxPQUE5RTtBQUNBLFlBQU07QUFBRWlLLFFBQUFBLFFBQVEsRUFBRUM7QUFBWixVQUF1QixNQUFNdk4sT0FBTyxDQUFDb0IsS0FBUixDQUFjb00sUUFBZCxDQUF1QkMsY0FBdkIsQ0FBc0NqTSxPQUF0QyxFQUErQ3hCLE9BQS9DLENBQW5DOztBQUNBMlQsa0JBQUdlLFVBQUgsQ0FDRTlHLGNBQUtqTyxJQUFMLENBQVVnTyxzREFBVixFQUF1REosTUFBdkQsRUFBK0QvTCxPQUFPLENBQUNqQyxNQUFSLENBQWU4RCxJQUE5RSxDQURGOztBQUdBLHVCQUFJLDhCQUFKLEVBQXFDLEdBQUU3QixPQUFPLENBQUNqQyxNQUFSLENBQWU4RCxJQUFLLHFCQUEzRCxFQUFpRixNQUFqRjtBQUNBLGFBQU95SixRQUFRLENBQUN1QixFQUFULENBQVk7QUFDakJsQixRQUFBQSxJQUFJLEVBQUU7QUFBRS9LLFVBQUFBLEtBQUssRUFBRTtBQUFUO0FBRFcsT0FBWixDQUFQO0FBR0QsS0FWRCxDQVVFLE9BQU9BLEtBQVAsRUFBYztBQUNkLHVCQUFJLDhCQUFKLEVBQW9DQSxLQUFLLENBQUNDLE9BQU4sSUFBaUJELEtBQXJEO0FBQ0EsYUFBTyxrQ0FBY0EsS0FBSyxDQUFDQyxPQUFOLElBQWlCRCxLQUEvQixFQUFzQyxJQUF0QyxFQUE0QyxHQUE1QyxFQUFpRDBLLFFBQWpELENBQVA7QUFDRDtBQUNGOztBQXgrRDZCIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIGFwcCAtIENsYXNzIGZvciBXYXp1aCByZXBvcnRpbmcgY29udHJvbGxlclxuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcbmltcG9ydCB7IFdBWlVIX01PRFVMRVMgfSBmcm9tICcuLi8uLi9jb21tb24vd2F6dWgtbW9kdWxlcyc7XG5pbXBvcnQgKiBhcyBUaW1Tb3J0IGZyb20gJ3RpbXNvcnQnO1xuaW1wb3J0IHsgRXJyb3JSZXNwb25zZSB9IGZyb20gJy4uL2xpYi9lcnJvci1yZXNwb25zZSc7XG5pbXBvcnQgKiBhcyBWdWxuZXJhYmlsaXR5UmVxdWVzdCBmcm9tICcuLi9saWIvcmVwb3J0aW5nL3Z1bG5lcmFiaWxpdHktcmVxdWVzdCc7XG5pbXBvcnQgKiBhcyBPdmVydmlld1JlcXVlc3QgZnJvbSAnLi4vbGliL3JlcG9ydGluZy9vdmVydmlldy1yZXF1ZXN0JztcbmltcG9ydCAqIGFzIFJvb3RjaGVja1JlcXVlc3QgZnJvbSAnLi4vbGliL3JlcG9ydGluZy9yb290Y2hlY2stcmVxdWVzdCc7XG5pbXBvcnQgKiBhcyBQQ0lSZXF1ZXN0IGZyb20gJy4uL2xpYi9yZXBvcnRpbmcvcGNpLXJlcXVlc3QnO1xuaW1wb3J0ICogYXMgR0RQUlJlcXVlc3QgZnJvbSAnLi4vbGliL3JlcG9ydGluZy9nZHByLXJlcXVlc3QnO1xuaW1wb3J0ICogYXMgVFNDUmVxdWVzdCBmcm9tICcuLi9saWIvcmVwb3J0aW5nL3RzYy1yZXF1ZXN0JztcbmltcG9ydCAqIGFzIEF1ZGl0UmVxdWVzdCBmcm9tICcuLi9saWIvcmVwb3J0aW5nL2F1ZGl0LXJlcXVlc3QnO1xuaW1wb3J0ICogYXMgU3lzY2hlY2tSZXF1ZXN0IGZyb20gJy4uL2xpYi9yZXBvcnRpbmcvc3lzY2hlY2stcmVxdWVzdCc7XG5pbXBvcnQgUENJIGZyb20gJy4uL2ludGVncmF0aW9uLWZpbGVzL3BjaS1yZXF1aXJlbWVudHMtcGRmbWFrZSc7XG5pbXBvcnQgR0RQUiBmcm9tICcuLi9pbnRlZ3JhdGlvbi1maWxlcy9nZHByLXJlcXVpcmVtZW50cy1wZGZtYWtlJztcbmltcG9ydCBUU0MgZnJvbSAnLi4vaW50ZWdyYXRpb24tZmlsZXMvdHNjLXJlcXVpcmVtZW50cy1wZGZtYWtlJztcbmltcG9ydCBQcm9jZXNzRXF1aXZhbGVuY2UgZnJvbSAnLi4vbGliL3Byb2Nlc3Mtc3RhdGUtZXF1aXZhbGVuY2UnO1xuaW1wb3J0IHsgS2V5RXF1aXZhbGVuY2UgfSBmcm9tICcuLi8uLi9jb21tb24vY3N2LWtleS1lcXVpdmFsZW5jZSc7XG5pbXBvcnQgeyBBZ2VudENvbmZpZ3VyYXRpb24gfSBmcm9tICcuLi9saWIvcmVwb3J0aW5nL2FnZW50LWNvbmZpZ3VyYXRpb24nO1xuaW1wb3J0IHsgT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LCBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5IH0gZnJvbSAnc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IFJlcG9ydFByaW50ZXIgfSBmcm9tICcuLi9saWIvcmVwb3J0aW5nL3ByaW50ZXInO1xuaW1wb3J0IHsgbG9nIH0gZnJvbSAnLi4vbGliL2xvZ2dlcic7XG5pbXBvcnQge1xuICBXQVpVSF9BTEVSVFNfUEFUVEVSTixcbiAgV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEgsXG4gIFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsXG4gIEFVVEhPUklaRURfQUdFTlRTLFxufSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7IGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzLCBjcmVhdGVEYXRhRGlyZWN0b3J5SWZOb3RFeGlzdHMgfSBmcm9tICcuLi9saWIvZmlsZXN5c3RlbSc7XG5pbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCc7XG5cbmV4cG9ydCBjbGFzcyBXYXp1aFJlcG9ydGluZ0N0cmwge1xuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgLyoqXG4gICAqIFRoaXMgZG8gZm9ybWF0IHRvIGZpbHRlcnNcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlcnMgRS5nOiBjbHVzdGVyLm5hbWU6IHdhenVoIEFORCBydWxlLmdyb3VwczogdnVsbmVyYWJpbGl0eVxuICAgKiBAcGFyYW0ge1N0cmluZ30gc2VhcmNoQmFyIHNlYXJjaCB0ZXJtXG4gICAqL1xuICBwcml2YXRlIHNhbml0aXplS2liYW5hRmlsdGVycyhmaWx0ZXJzOiBhbnksIHNlYXJjaEJhcj86IHN0cmluZyk6IFtzdHJpbmcsIHN0cmluZ10ge1xuICAgIGxvZygncmVwb3J0aW5nOnNhbml0aXplS2liYW5hRmlsdGVycycsIGBTdGFydGVkIHRvIHNhbml0aXplIGZpbHRlcnNgLCAnaW5mbycpO1xuICAgIGxvZyhcbiAgICAgICdyZXBvcnRpbmc6c2FuaXRpemVLaWJhbmFGaWx0ZXJzJyxcbiAgICAgIGBmaWx0ZXJzOiAke2ZpbHRlcnMubGVuZ3RofSwgc2VhcmNoQmFyOiAke3NlYXJjaEJhcn1gLFxuICAgICAgJ2RlYnVnJ1xuICAgICk7XG4gICAgbGV0IHN0ciA9ICcnO1xuXG4gICAgY29uc3QgYWdlbnRzRmlsdGVyOiBhbnkgPSBbXTtcblxuICAgIC8vc2VwYXJhdGUgYWdlbnRzIGZpbHRlclxuICAgIGZpbHRlcnMgPSBmaWx0ZXJzLmZpbHRlcigoZmlsdGVyKSA9PiB7XG4gICAgICBpZiAoZmlsdGVyLm1ldGEuY29udHJvbGxlZEJ5ID09PSBBVVRIT1JJWkVEX0FHRU5UUykge1xuICAgICAgICBhZ2VudHNGaWx0ZXIucHVzaChmaWx0ZXIpO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmlsdGVyO1xuICAgIH0pO1xuXG4gICAgY29uc3QgbGVuID0gZmlsdGVycy5sZW5ndGg7XG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICBjb25zdCB7IG5lZ2F0ZSwga2V5LCB2YWx1ZSwgcGFyYW1zLCB0eXBlIH0gPSBmaWx0ZXJzW2ldLm1ldGE7XG4gICAgICBzdHIgKz0gYCR7bmVnYXRlID8gJ05PVCAnIDogJyd9YDtcbiAgICAgIHN0ciArPSBgJHtrZXl9OiBgO1xuICAgICAgc3RyICs9IGAke1xuICAgICAgICB0eXBlID09PSAncmFuZ2UnXG4gICAgICAgICAgPyBgJHtwYXJhbXMuZ3RlfS0ke3BhcmFtcy5sdH1gXG4gICAgICAgICAgOiB0eXBlID09PSAncGhyYXNlcydcbiAgICAgICAgICAgID8gJygnICsgcGFyYW1zLmpvaW4oXCIgT1IgXCIpICsgJyknXG4gICAgICAgICAgICA6IHR5cGUgPT09ICdleGlzdHMnXG4gICAgICAgICAgICAgID8gJyonXG4gICAgICAgICAgICAgIDogISF2YWx1ZVxuICAgICAgICAgID8gdmFsdWVcbiAgICAgICAgICA6IChwYXJhbXMgfHwge30pLnF1ZXJ5XG4gICAgICB9YDtcbiAgICAgIHN0ciArPSBgJHtpID09PSBsZW4gLSAxID8gJycgOiAnIEFORCAnfWA7XG4gICAgfVxuXG4gICAgaWYgKHNlYXJjaEJhcikge1xuICAgICAgc3RyICs9IGAgQU5EICgkeyBzZWFyY2hCYXJ9KWA7XG4gICAgfVxuXG4gICAgY29uc3QgYWdlbnRzRmlsdGVyU3RyID0gYWdlbnRzRmlsdGVyLm1hcCgoZmlsdGVyKSA9PiBmaWx0ZXIubWV0YS52YWx1ZSkuam9pbignLCcpO1xuXG4gICAgbG9nKFxuICAgICAgJ3JlcG9ydGluZzpzYW5pdGl6ZUtpYmFuYUZpbHRlcnMnLFxuICAgICAgYHN0cjogJHtzdHJ9LCBhZ2VudHNGaWx0ZXJTdHI6ICR7YWdlbnRzRmlsdGVyU3RyfWAsXG4gICAgICAnZGVidWcnXG4gICAgKTtcblxuICAgIHJldHVybiBbc3RyLCBhZ2VudHNGaWx0ZXJTdHJdO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgcGVyZm9ybXMgdGhlIHJlbmRlcmluZyBvZiBnaXZlbiBoZWFkZXJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHByaW50ZXIgc2VjdGlvbiB0YXJnZXRcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNlY3Rpb24gc2VjdGlvbiB0YXJnZXRcbiAgICogQHBhcmFtIHtPYmplY3R9IHRhYiB0YWIgdGFyZ2V0XG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gaXNBZ2VudHMgaXMgYWdlbnRzIHNlY3Rpb25cbiAgICogQHBhcmFtIHtTdHJpbmd9IGFwaUlkIElEIG9mIEFQSVxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyByZW5kZXJIZWFkZXIoY29udGV4dCwgcHJpbnRlciwgc2VjdGlvbiwgdGFiLCBpc0FnZW50cywgYXBpSWQpIHtcbiAgICB0cnkge1xuICAgICAgbG9nKFxuICAgICAgICAncmVwb3J0aW5nOnJlbmRlckhlYWRlcicsXG4gICAgICAgIGBzZWN0aW9uOiAke3NlY3Rpb259LCB0YWI6ICR7dGFifSwgaXNBZ2VudHM6ICR7aXNBZ2VudHN9LCBhcGlJZDogJHthcGlJZH1gLFxuICAgICAgICAnZGVidWcnXG4gICAgICApO1xuICAgICAgaWYgKHNlY3Rpb24gJiYgdHlwZW9mIHNlY3Rpb24gPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGlmICghWydhZ2VudENvbmZpZycsICdncm91cENvbmZpZyddLmluY2x1ZGVzKHNlY3Rpb24pKSB7XG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcbiAgICAgICAgICAgIHRleHQ6IFdBWlVIX01PRFVMRVNbdGFiXS50aXRsZSArICcgcmVwb3J0JyxcbiAgICAgICAgICAgIHN0eWxlOiAnaDEnLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKHNlY3Rpb24gPT09ICdhZ2VudENvbmZpZycpIHtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgdGV4dDogYEFnZW50ICR7aXNBZ2VudHN9IGNvbmZpZ3VyYXRpb25gLFxuICAgICAgICAgICAgc3R5bGU6ICdoMScsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAoc2VjdGlvbiA9PT0gJ2dyb3VwQ29uZmlnJykge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiAnQWdlbnRzIGluIGdyb3VwJyxcbiAgICAgICAgICAgIHN0eWxlOiB7IGZvbnRTaXplOiAxNCwgY29sb3I6ICcjMDAwJyB9LFxuICAgICAgICAgICAgbWFyZ2luOiBbMCwgMjAsIDAsIDBdLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChzZWN0aW9uID09PSAnZ3JvdXBDb25maWcnICYmICFPYmplY3Qua2V5cyhpc0FnZW50cykubGVuZ3RoKSB7XG4gICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICB0ZXh0OiAnVGhlcmUgYXJlIHN0aWxsIG5vIGFnZW50cyBpbiB0aGlzIGdyb3VwLicsXG4gICAgICAgICAgICAgIHN0eWxlOiB7IGZvbnRTaXplOiAxMiwgY29sb3I6ICcjMDAwJyB9LFxuICAgICAgICAgICAgICBtYXJnaW46IFswLCAxMCwgMCwgMF0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcHJpbnRlci5hZGROZXdMaW5lKCk7XG4gICAgICB9XG5cbiAgICAgIGlmIChpc0FnZW50cyAmJiB0eXBlb2YgaXNBZ2VudHMgPT09ICdvYmplY3QnKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIHByaW50ZXIsXG4gICAgICAgICAgaXNBZ2VudHMsXG4gICAgICAgICAgYXBpSWQsXG4gICAgICAgICAgc2VjdGlvbiA9PT0gJ2dyb3VwQ29uZmlnJyA/IHRhYiA6IGZhbHNlXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGlmIChpc0FnZW50cyAmJiB0eXBlb2YgaXNBZ2VudHMgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbnN0IGFnZW50UmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAgICdHRVQnLFxuICAgICAgICAgIGAvYWdlbnRzYCxcbiAgICAgICAgICB7IHBhcmFtczogeyBhZ2VudHNfbGlzdDogaXNBZ2VudHMgfSB9LFxuICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGFnZW50RGF0YSA9IGFnZW50UmVzcG9uc2UuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zWzBdO1xuICAgICAgICBpZiAoYWdlbnREYXRhICYmIGFnZW50RGF0YS5zdGF0dXMgIT09ICdhY3RpdmUnKSB7XG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xuICAgICAgICAgICAgdGV4dDogYFdhcm5pbmcuIEFnZW50IGlzICR7YWdlbnREYXRhLnN0YXR1cy50b0xvd2VyQ2FzZSgpfWAsXG4gICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBhd2FpdCB0aGlzLmJ1aWxkQWdlbnRzVGFibGUoY29udGV4dCwgcHJpbnRlciwgW2lzQWdlbnRzXSwgYXBpSWQpO1xuXG4gICAgICAgIGlmIChhZ2VudERhdGEgJiYgYWdlbnREYXRhLmdyb3VwKSB7XG4gICAgICAgICAgY29uc3QgYWdlbnRHcm91cHMgPSBhZ2VudERhdGEuZ3JvdXAuam9pbignLCAnKTtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XG4gICAgICAgICAgICB0ZXh0OiBgR3JvdXAke2FnZW50RGF0YS5ncm91cC5sZW5ndGggPiAxID8gJ3MnIDogJyd9OiAke2FnZW50R3JvdXBzfWAsXG4gICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKFdBWlVIX01PRFVMRVNbdGFiXSAmJiBXQVpVSF9NT0RVTEVTW3RhYl0uZGVzY3JpcHRpb24pIHtcbiAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xuICAgICAgICAgIHRleHQ6IFdBWlVIX01PRFVMRVNbdGFiXS5kZXNjcmlwdGlvbixcbiAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybjtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6cmVuZGVySGVhZGVyJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGJ1aWxkIHRoZSBhZ2VudHMgdGFibGVcbiAgICogQHBhcmFtIHtBcnJheTxTdHJpbmdzPn0gaWRzIGlkcyBvZiBhZ2VudHNcbiAgICogQHBhcmFtIHtTdHJpbmd9IGFwaUlkIEFQSSBpZFxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBidWlsZEFnZW50c1RhYmxlKGNvbnRleHQsIHByaW50ZXI6IFJlcG9ydFByaW50ZXIsIGFnZW50SURzOiBzdHJpbmdbXSwgYXBpSWQ6IHN0cmluZywgbXVsdGkgPSBmYWxzZSkge1xuICAgIGNvbnN0IGRhdGVGb3JtYXQgPSBhd2FpdCBjb250ZXh0LmNvcmUudWlTZXR0aW5ncy5jbGllbnQuZ2V0KCdkYXRlRm9ybWF0Jyk7XG4gICAgaWYgKCFhZ2VudElEcyB8fCAhYWdlbnRJRHMubGVuZ3RoKSByZXR1cm47XG4gICAgbG9nKCdyZXBvcnRpbmc6YnVpbGRBZ2VudHNUYWJsZScsIGAke2FnZW50SURzLmxlbmd0aH0gYWdlbnRzIGZvciBBUEkgJHthcGlJZH1gLCAnaW5mbycpO1xuICAgIHRyeSB7XG4gICAgICBsZXQgYWdlbnRSb3dzID0gW107XG4gICAgICBpZiAobXVsdGkpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBhZ2VudHNSZXNwb25zZSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICAgIGAvZ3JvdXBzLyR7bXVsdGl9L2FnZW50c2AsXG4gICAgICAgICAgICB7fSxcbiAgICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XG4gICAgICAgICAgKTtcbiAgICAgICAgICBjb25zdCBhZ2VudHNEYXRhID1cbiAgICAgICAgICAgIGFnZW50c1Jlc3BvbnNlICYmXG4gICAgICAgICAgICBhZ2VudHNSZXNwb25zZS5kYXRhICYmXG4gICAgICAgICAgICBhZ2VudHNSZXNwb25zZS5kYXRhLmRhdGEgJiZcbiAgICAgICAgICAgIGFnZW50c1Jlc3BvbnNlLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtcztcbiAgICAgICAgICBhZ2VudFJvd3MgPSAoYWdlbnRzRGF0YSB8fCBbXSkubWFwKChhZ2VudCkgPT4gKHtcbiAgICAgICAgICAgIC4uLmFnZW50LFxuICAgICAgICAgICAgbWFuYWdlcjogYWdlbnQubWFuYWdlciB8fCBhZ2VudC5tYW5hZ2VyX2hvc3QsXG4gICAgICAgICAgICBvczpcbiAgICAgICAgICAgICAgYWdlbnQub3MgJiYgYWdlbnQub3MubmFtZSAmJiBhZ2VudC5vcy52ZXJzaW9uXG4gICAgICAgICAgICAgICAgPyBgJHthZ2VudC5vcy5uYW1lfSAke2FnZW50Lm9zLnZlcnNpb259YFxuICAgICAgICAgICAgICAgIDogJycsXG4gICAgICAgICAgfSkpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGxvZyhcbiAgICAgICAgICAgICdyZXBvcnRpbmc6YnVpbGRBZ2VudHNUYWJsZScsXG4gICAgICAgICAgICBgU2tpcCBhZ2VudCBkdWUgdG86ICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gLFxuICAgICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZvciAoY29uc3QgYWdlbnRJRCBvZiBhZ2VudElEcykge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBhZ2VudFJlc3BvbnNlID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcbiAgICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICAgIGAvYWdlbnRzYCxcbiAgICAgICAgICAgICAgeyBwYXJhbXM6IHsgcTogYGlkPSR7YWdlbnRJRH1gIH0gfSxcbiAgICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IGFwaUlkIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBjb25zdCBbYWdlbnRdID0gYWdlbnRSZXNwb25zZS5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXM7XG4gICAgICAgICAgICBhZ2VudFJvd3MucHVzaCh7XG4gICAgICAgICAgICAgIC4uLmFnZW50LFxuICAgICAgICAgICAgICBtYW5hZ2VyOiBhZ2VudC5tYW5hZ2VyIHx8IGFnZW50Lm1hbmFnZXJfaG9zdCxcbiAgICAgICAgICAgICAgb3M6IChhZ2VudC5vcyAmJiBhZ2VudC5vcy5uYW1lICYmIGFnZW50Lm9zLnZlcnNpb24pID8gYCR7YWdlbnQub3MubmFtZX0gJHthZ2VudC5vcy52ZXJzaW9ufWAgOiAnJyxcbiAgICAgICAgICAgICAgbGFzdEtlZXBBbGl2ZTogbW9tZW50KGFnZW50Lmxhc3RLZWVwQWxpdmUpLmZvcm1hdChkYXRlRm9ybWF0KSxcbiAgICAgICAgICAgICAgZGF0ZUFkZDogbW9tZW50KGFnZW50LmRhdGVBZGQpLmZvcm1hdChkYXRlRm9ybWF0KVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGxvZyhcbiAgICAgICAgICAgICAgJ3JlcG9ydGluZzpidWlsZEFnZW50c1RhYmxlJyxcbiAgICAgICAgICAgICAgYFNraXAgYWdlbnQgZHVlIHRvOiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YCxcbiAgICAgICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHByaW50ZXIuYWRkU2ltcGxlVGFibGUoe1xuICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgeyBpZDogJ2lkJywgbGFiZWw6ICdJRCcgfSxcbiAgICAgICAgICB7IGlkOiAnbmFtZScsIGxhYmVsOiAnTmFtZScgfSxcbiAgICAgICAgICB7IGlkOiAnaXAnLCBsYWJlbDogJ0lQJyB9LFxuICAgICAgICAgIHsgaWQ6ICd2ZXJzaW9uJywgbGFiZWw6ICdWZXJzaW9uJyB9LFxuICAgICAgICAgIHsgaWQ6ICdtYW5hZ2VyJywgbGFiZWw6ICdNYW5hZ2VyJyB9LFxuICAgICAgICAgIHsgaWQ6ICdvcycsIGxhYmVsOiAnT1MnIH0sXG4gICAgICAgICAgeyBpZDogJ2RhdGVBZGQnLCBsYWJlbDogJ1JlZ2lzdHJhdGlvbiBkYXRlJyB9LFxuICAgICAgICAgIHsgaWQ6ICdsYXN0S2VlcEFsaXZlJywgbGFiZWw6ICdMYXN0IGtlZXAgYWxpdmUnIH0sXG4gICAgICAgIF0sXG4gICAgICAgIGl0ZW1zOiBhZ2VudFJvd3MsXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6YnVpbGRBZ2VudHNUYWJsZScsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBsb2FkIG1vcmUgaW5mb3JtYXRpb25cbiAgICogQHBhcmFtIHsqfSBjb250ZXh0IEVuZHBvaW50IGNvbnRleHRcbiAgICogQHBhcmFtIHsqfSBwcmludGVyIHByaW50ZXIgaW5zdGFuY2VcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNlY3Rpb24gc2VjdGlvbiB0YXJnZXRcbiAgICogQHBhcmFtIHtPYmplY3R9IHRhYiB0YWIgdGFyZ2V0XG4gICAqIEBwYXJhbSB7U3RyaW5nfSBhcGlJZCBJRCBvZiBBUElcbiAgICogQHBhcmFtIHtOdW1iZXJ9IGZyb20gVGltZXN0YW1wIChtcykgZnJvbVxuICAgKiBAcGFyYW0ge051bWJlcn0gdG8gVGltZXN0YW1wIChtcykgdG9cbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlcnMgRS5nOiBjbHVzdGVyLm5hbWU6IHdhenVoIEFORCBydWxlLmdyb3VwczogdnVsbmVyYWJpbGl0eVxuICAgKiBAcGFyYW0ge1N0cmluZ30gcGF0dGVyblxuICAgKiBAcGFyYW0ge09iamVjdH0gYWdlbnQgYWdlbnQgdGFyZ2V0XG4gICAqIEByZXR1cm5zIHtPYmplY3R9IEV4dGVuZGVkIGluZm9ybWF0aW9uXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIGV4dGVuZGVkSW5mb3JtYXRpb24oXG4gICAgY29udGV4dCxcbiAgICBwcmludGVyLFxuICAgIHNlY3Rpb24sXG4gICAgdGFiLFxuICAgIGFwaUlkLFxuICAgIGZyb20sXG4gICAgdG8sXG4gICAgZmlsdGVycyxcbiAgICBwYXR0ZXJuID0gV0FaVUhfQUxFUlRTX1BBVFRFUk4sXG4gICAgYWdlbnQgPSBudWxsXG4gICkge1xuICAgIHRyeSB7XG4gICAgICBsb2coXG4gICAgICAgICdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsXG4gICAgICAgIGBTZWN0aW9uICR7c2VjdGlvbn0gYW5kIHRhYiAke3RhYn0sIEFQSSBpcyAke2FwaUlkfS4gRnJvbSAke2Zyb219IHRvICR7dG99LiBGaWx0ZXJzICR7ZmlsdGVyc30uIEluZGV4IHBhdHRlcm4gJHtwYXR0ZXJufWAsXG4gICAgICAgICdpbmZvJ1xuICAgICAgKTtcbiAgICAgIGlmIChzZWN0aW9uID09PSAnYWdlbnRzJyAmJiAhYWdlbnQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdSZXBvcnRpbmcgZm9yIHNwZWNpZmljIGFnZW50IG5lZWRzIGFuIGFnZW50IElEIGluIG9yZGVyIHRvIHdvcmsgcHJvcGVybHknKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgYWdlbnRzID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgICcvYWdlbnRzJyxcbiAgICAgICAgeyBwYXJhbXM6IHsgbGltaXQ6IDEgfSB9LFxuICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxuICAgICAgKTtcblxuICAgICAgY29uc3QgdG90YWxBZ2VudHMgPSBhZ2VudHMuZGF0YS5kYXRhLnRvdGFsX2FmZmVjdGVkX2l0ZW1zO1xuXG4gICAgICBpZiAoc2VjdGlvbiA9PT0gJ292ZXJ2aWV3JyAmJiB0YWIgPT09ICd2dWxzJykge1xuICAgICAgICBsb2coXG4gICAgICAgICAgJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJyxcbiAgICAgICAgICAnRmV0Y2hpbmcgb3ZlcnZpZXcgdnVsbmVyYWJpbGl0eSBkZXRlY3RvciBtZXRyaWNzJyxcbiAgICAgICAgICAnZGVidWcnXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHZ1bG5lcmFiaWxpdGllc0xldmVscyA9IFsnTG93JywgJ01lZGl1bScsICdIaWdoJywgJ0NyaXRpY2FsJ107XG5cbiAgICAgICAgY29uc3QgdnVsbmVyYWJpbGl0aWVzUmVzcG9uc2VzQ291bnQgPSAoXG4gICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgICAgICB2dWxuZXJhYmlsaXRpZXNMZXZlbHMubWFwKGFzeW5jICh2dWxuZXJhYmlsaXRpZXNMZXZlbCkgPT4ge1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvdW50ID0gYXdhaXQgVnVsbmVyYWJpbGl0eVJlcXVlc3QudW5pcXVlU2V2ZXJpdHlDb3VudChcbiAgICAgICAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICAgICAgICBmcm9tLFxuICAgICAgICAgICAgICAgICAgdG8sXG4gICAgICAgICAgICAgICAgICB2dWxuZXJhYmlsaXRpZXNMZXZlbCxcbiAgICAgICAgICAgICAgICAgIGZpbHRlcnMsXG4gICAgICAgICAgICAgICAgICBwYXR0ZXJuXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gY291bnRcbiAgICAgICAgICAgICAgICAgID8gYCR7Y291bnR9IG9mICR7dG90YWxBZ2VudHN9IGFnZW50cyBoYXZlICR7dnVsbmVyYWJpbGl0aWVzTGV2ZWwudG9Mb2NhbGVMb3dlckNhc2UoKX0gdnVsbmVyYWJpbGl0aWVzLmBcbiAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge31cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgKVxuICAgICAgICApLmZpbHRlcigodnVsbmVyYWJpbGl0aWVzUmVzcG9uc2UpID0+IHZ1bG5lcmFiaWxpdGllc1Jlc3BvbnNlKTtcblxuICAgICAgICBwcmludGVyLmFkZExpc3Qoe1xuICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdTdW1tYXJ5Jywgc3R5bGU6ICdoMicgfSxcbiAgICAgICAgICBsaXN0OiB2dWxuZXJhYmlsaXRpZXNSZXNwb25zZXNDb3VudCxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgbG9nKFxuICAgICAgICAgICdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsXG4gICAgICAgICAgJ0ZldGNoaW5nIG92ZXJ2aWV3IHZ1bG5lcmFiaWxpdHkgZGV0ZWN0b3IgdG9wIDMgYWdlbnRzIGJ5IGNhdGVnb3J5JyxcbiAgICAgICAgICAnZGVidWcnXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGxvd1JhbmsgPSBhd2FpdCBWdWxuZXJhYmlsaXR5UmVxdWVzdC50b3BBZ2VudENvdW50KFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICB0byxcbiAgICAgICAgICAnTG93JyxcbiAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgIHBhdHRlcm5cbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgbWVkaXVtUmFuayA9IGF3YWl0IFZ1bG5lcmFiaWxpdHlSZXF1ZXN0LnRvcEFnZW50Q291bnQoXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICBmcm9tLFxuICAgICAgICAgIHRvLFxuICAgICAgICAgICdNZWRpdW0nLFxuICAgICAgICAgIGZpbHRlcnMsXG4gICAgICAgICAgcGF0dGVyblxuICAgICAgICApO1xuICAgICAgICBjb25zdCBoaWdoUmFuayA9IGF3YWl0IFZ1bG5lcmFiaWxpdHlSZXF1ZXN0LnRvcEFnZW50Q291bnQoXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICBmcm9tLFxuICAgICAgICAgIHRvLFxuICAgICAgICAgICdIaWdoJyxcbiAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgIHBhdHRlcm5cbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgY3JpdGljYWxSYW5rID0gYXdhaXQgVnVsbmVyYWJpbGl0eVJlcXVlc3QudG9wQWdlbnRDb3VudChcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIGZyb20sXG4gICAgICAgICAgdG8sXG4gICAgICAgICAgJ0NyaXRpY2FsJyxcbiAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgIHBhdHRlcm5cbiAgICAgICAgKTtcbiAgICAgICAgbG9nKFxuICAgICAgICAgICdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsXG4gICAgICAgICAgJ0FkZGluZyBvdmVydmlldyB2dWxuZXJhYmlsaXR5IGRldGVjdG9yIHRvcCAzIGFnZW50cyBieSBjYXRlZ29yeScsXG4gICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICApO1xuICAgICAgICBpZiAoY3JpdGljYWxSYW5rICYmIGNyaXRpY2FsUmFuay5sZW5ndGgpIHtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XG4gICAgICAgICAgICB0ZXh0OiAnVG9wIDMgYWdlbnRzIHdpdGggY3JpdGljYWwgc2V2ZXJpdHkgdnVsbmVyYWJpbGl0aWVzJyxcbiAgICAgICAgICAgIHN0eWxlOiAnaDMnLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBjcml0aWNhbFJhbmssIGFwaUlkKTtcbiAgICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChoaWdoUmFuayAmJiBoaWdoUmFuay5sZW5ndGgpIHtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XG4gICAgICAgICAgICB0ZXh0OiAnVG9wIDMgYWdlbnRzIHdpdGggaGlnaCBzZXZlcml0eSB2dWxuZXJhYmlsaXRpZXMnLFxuICAgICAgICAgICAgc3R5bGU6ICdoMycsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgYXdhaXQgdGhpcy5idWlsZEFnZW50c1RhYmxlKGNvbnRleHQsIHByaW50ZXIsIGhpZ2hSYW5rLCBhcGlJZCk7XG4gICAgICAgICAgcHJpbnRlci5hZGROZXdMaW5lKCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAobWVkaXVtUmFuayAmJiBtZWRpdW1SYW5rLmxlbmd0aCkge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcbiAgICAgICAgICAgIHRleHQ6ICdUb3AgMyBhZ2VudHMgd2l0aCBtZWRpdW0gc2V2ZXJpdHkgdnVsbmVyYWJpbGl0aWVzJyxcbiAgICAgICAgICAgIHN0eWxlOiAnaDMnLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBtZWRpdW1SYW5rLCBhcGlJZCk7XG4gICAgICAgICAgcHJpbnRlci5hZGROZXdMaW5lKCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAobG93UmFuayAmJiBsb3dSYW5rLmxlbmd0aCkge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcbiAgICAgICAgICAgIHRleHQ6ICdUb3AgMyBhZ2VudHMgd2l0aCBsb3cgc2V2ZXJpdHkgdnVsbmVyYWJpbGl0aWVzJyxcbiAgICAgICAgICAgIHN0eWxlOiAnaDMnLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBsb3dSYW5rLCBhcGlJZCk7XG4gICAgICAgICAgcHJpbnRlci5hZGROZXdMaW5lKCk7XG4gICAgICAgIH1cblxuICAgICAgICBsb2coXG4gICAgICAgICAgJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJyxcbiAgICAgICAgICAnRmV0Y2hpbmcgb3ZlcnZpZXcgdnVsbmVyYWJpbGl0eSBkZXRlY3RvciB0b3AgMyBDVkVzJyxcbiAgICAgICAgICAnZGVidWcnXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGN2ZVJhbmsgPSBhd2FpdCBWdWxuZXJhYmlsaXR5UmVxdWVzdC50b3BDVkVDb3VudChjb250ZXh0LCBmcm9tLCB0bywgZmlsdGVycywgcGF0dGVybik7XG4gICAgICAgIGxvZyhcbiAgICAgICAgICAncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLFxuICAgICAgICAgICdBZGRpbmcgb3ZlcnZpZXcgdnVsbmVyYWJpbGl0eSBkZXRlY3RvciB0b3AgMyBDVkVzJyxcbiAgICAgICAgICAnZGVidWcnXG4gICAgICAgICk7XG4gICAgICAgIGlmIChjdmVSYW5rICYmIGN2ZVJhbmsubGVuZ3RoKSB7XG4gICAgICAgICAgcHJpbnRlci5hZGRTaW1wbGVUYWJsZSh7XG4gICAgICAgICAgICB0aXRsZTogeyB0ZXh0OiAnVG9wIDMgQ1ZFJywgc3R5bGU6ICdoMicgfSxcbiAgICAgICAgICAgIGNvbHVtbnM6IFtcbiAgICAgICAgICAgICAgeyBpZDogJ3RvcCcsIGxhYmVsOiAnVG9wJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnY3ZlJywgbGFiZWw6ICdDVkUnIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgaXRlbXM6IGN2ZVJhbmsubWFwKChpdGVtKSA9PiAoeyB0b3A6IGN2ZVJhbmsuaW5kZXhPZihpdGVtKSArIDEsIGN2ZTogaXRlbSB9KSksXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHNlY3Rpb24gPT09ICdvdmVydmlldycgJiYgdGFiID09PSAnZ2VuZXJhbCcpIHtcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsICdGZXRjaGluZyB0b3AgMyBhZ2VudHMgd2l0aCBsZXZlbCAxNSBhbGVydHMnLCAnZGVidWcnKTtcblxuICAgICAgICBjb25zdCBsZXZlbDE1UmFuayA9IGF3YWl0IE92ZXJ2aWV3UmVxdWVzdC50b3BMZXZlbDE1KGNvbnRleHQsIGZyb20sIHRvLCBmaWx0ZXJzLCBwYXR0ZXJuKTtcblxuICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgJ0FkZGluZyB0b3AgMyBhZ2VudHMgd2l0aCBsZXZlbCAxNSBhbGVydHMnLCAnZGVidWcnKTtcbiAgICAgICAgaWYgKGxldmVsMTVSYW5rLmxlbmd0aCkge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiAnVG9wIDMgYWdlbnRzIHdpdGggbGV2ZWwgMTUgYWxlcnRzJyxcbiAgICAgICAgICAgIHN0eWxlOiAnaDInLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBsZXZlbDE1UmFuaywgYXBpSWQpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChzZWN0aW9uID09PSAnb3ZlcnZpZXcnICYmIHRhYiA9PT0gJ3BtJykge1xuICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgJ0ZldGNoaW5nIG1vc3QgY29tbW9uIHJvb3RraXRzJywgJ2RlYnVnJyk7XG4gICAgICAgIGNvbnN0IHRvcDVSb290a2l0c1JhbmsgPSBhd2FpdCBSb290Y2hlY2tSZXF1ZXN0LnRvcDVSb290a2l0c0RldGVjdGVkKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICB0byxcbiAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgIHBhdHRlcm5cbiAgICAgICAgKTtcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsICdBZGRpbmcgbW9zdCBjb21tb24gcm9vdGtpdHMnLCAnZGVidWcnKTtcbiAgICAgICAgaWYgKHRvcDVSb290a2l0c1JhbmsgJiYgdG9wNVJvb3RraXRzUmFuay5sZW5ndGgpIHtcbiAgICAgICAgICBwcmludGVyXG4gICAgICAgICAgICAuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcbiAgICAgICAgICAgICAgdGV4dDogJ01vc3QgY29tbW9uIHJvb3RraXRzIGZvdW5kIGFtb25nIHlvdXIgYWdlbnRzJyxcbiAgICAgICAgICAgICAgc3R5bGU6ICdoMicsXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XG4gICAgICAgICAgICAgIHRleHQ6XG4gICAgICAgICAgICAgICAgJ1Jvb3RraXRzIGFyZSBhIHNldCBvZiBzb2Z0d2FyZSB0b29scyB0aGF0IGVuYWJsZSBhbiB1bmF1dGhvcml6ZWQgdXNlciB0byBnYWluIGNvbnRyb2wgb2YgYSBjb21wdXRlciBzeXN0ZW0gd2l0aG91dCBiZWluZyBkZXRlY3RlZC4nLFxuICAgICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuYWRkU2ltcGxlVGFibGUoe1xuICAgICAgICAgICAgICBpdGVtczogdG9wNVJvb3RraXRzUmFuay5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4geyB0b3A6IHRvcDVSb290a2l0c1JhbmsuaW5kZXhPZihpdGVtKSArIDEsIG5hbWU6IGl0ZW0gfTtcbiAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgIGNvbHVtbnM6IFtcbiAgICAgICAgICAgICAgICB7IGlkOiAndG9wJywgbGFiZWw6ICdUb3AnIH0sXG4gICAgICAgICAgICAgICAgeyBpZDogJ25hbWUnLCBsYWJlbDogJ1Jvb3RraXQnIH0sXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgJ0ZldGNoaW5nIGhpZGRlbiBwaWRzJywgJ2RlYnVnJyk7XG4gICAgICAgIGNvbnN0IGhpZGRlblBpZHMgPSBhd2FpdCBSb290Y2hlY2tSZXF1ZXN0LmFnZW50c1dpdGhIaWRkZW5QaWRzKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICB0byxcbiAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgIHBhdHRlcm5cbiAgICAgICAgKTtcbiAgICAgICAgaGlkZGVuUGlkcyAmJlxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiBgJHtoaWRkZW5QaWRzfSBvZiAke3RvdGFsQWdlbnRzfSBhZ2VudHMgaGF2ZSBoaWRkZW4gcHJvY2Vzc2VzYCxcbiAgICAgICAgICAgIHN0eWxlOiAnaDMnLFxuICAgICAgICAgIH0pO1xuICAgICAgICAhaGlkZGVuUGlkcyAmJlxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcbiAgICAgICAgICAgIHRleHQ6IGBObyBhZ2VudHMgaGF2ZSBoaWRkZW4gcHJvY2Vzc2VzYCxcbiAgICAgICAgICAgIHN0eWxlOiAnaDMnLFxuICAgICAgICAgIH0pO1xuXG4gICAgICAgIGNvbnN0IGhpZGRlblBvcnRzID0gYXdhaXQgUm9vdGNoZWNrUmVxdWVzdC5hZ2VudHNXaXRoSGlkZGVuUG9ydHMoXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICBmcm9tLFxuICAgICAgICAgIHRvLFxuICAgICAgICAgIGZpbHRlcnMsXG4gICAgICAgICAgcGF0dGVyblxuICAgICAgICApO1xuICAgICAgICBoaWRkZW5Qb3J0cyAmJlxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiBgJHtoaWRkZW5Qb3J0c30gb2YgJHt0b3RhbEFnZW50c30gYWdlbnRzIGhhdmUgaGlkZGVuIHBvcnRzYCxcbiAgICAgICAgICAgIHN0eWxlOiAnaDMnLFxuICAgICAgICAgIH0pO1xuICAgICAgICAhaGlkZGVuUG9ydHMgJiZcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgdGV4dDogYE5vIGFnZW50cyBoYXZlIGhpZGRlbiBwb3J0c2AsXG4gICAgICAgICAgICBzdHlsZTogJ2gzJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgcHJpbnRlci5hZGROZXdMaW5lKCk7XG4gICAgICB9XG5cbiAgICAgIGlmIChbJ292ZXJ2aWV3JywgJ2FnZW50cyddLmluY2x1ZGVzKHNlY3Rpb24pICYmIHRhYiA9PT0gJ3BjaScpIHtcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsICdGZXRjaGluZyB0b3AgUENJIERTUyByZXF1aXJlbWVudHMnLCAnZGVidWcnKTtcbiAgICAgICAgY29uc3QgdG9wUGNpUmVxdWlyZW1lbnRzID0gYXdhaXQgUENJUmVxdWVzdC50b3BQQ0lSZXF1aXJlbWVudHMoXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICBmcm9tLFxuICAgICAgICAgIHRvLFxuICAgICAgICAgIGZpbHRlcnMsXG4gICAgICAgICAgcGF0dGVyblxuICAgICAgICApO1xuICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XG4gICAgICAgICAgdGV4dDogJ01vc3QgY29tbW9uIFBDSSBEU1MgcmVxdWlyZW1lbnRzIGFsZXJ0cyBmb3VuZCcsXG4gICAgICAgICAgc3R5bGU6ICdoMicsXG4gICAgICAgIH0pO1xuICAgICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgdG9wUGNpUmVxdWlyZW1lbnRzKSB7XG4gICAgICAgICAgY29uc3QgcnVsZXMgPSBhd2FpdCBQQ0lSZXF1ZXN0LmdldFJ1bGVzQnlSZXF1aXJlbWVudChcbiAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICBmcm9tLFxuICAgICAgICAgICAgdG8sXG4gICAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgICAgaXRlbSxcbiAgICAgICAgICAgIHBhdHRlcm5cbiAgICAgICAgICApO1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHsgdGV4dDogYFJlcXVpcmVtZW50ICR7aXRlbX1gLCBzdHlsZTogJ2gzJyB9KTtcblxuICAgICAgICAgIGlmIChQQ0lbaXRlbV0pIHtcbiAgICAgICAgICAgIGNvbnN0IGNvbnRlbnQgPVxuICAgICAgICAgICAgICB0eXBlb2YgUENJW2l0ZW1dID09PSAnc3RyaW5nJyA/IHsgdGV4dDogUENJW2l0ZW1dLCBzdHlsZTogJ3N0YW5kYXJkJyB9IDogUENJW2l0ZW1dO1xuICAgICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoY29udGVudCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcnVsZXMgJiZcbiAgICAgICAgICAgIHJ1bGVzLmxlbmd0aCAmJlxuICAgICAgICAgICAgcHJpbnRlci5hZGRTaW1wbGVUYWJsZSh7XG4gICAgICAgICAgICAgIGNvbHVtbnM6IFtcbiAgICAgICAgICAgICAgICB7IGlkOiAncnVsZUlEJywgbGFiZWw6ICdSdWxlIElEJyB9LFxuICAgICAgICAgICAgICAgIHsgaWQ6ICdydWxlRGVzY3JpcHRpb24nLCBsYWJlbDogJ0Rlc2NyaXB0aW9uJyB9LFxuICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICBpdGVtczogcnVsZXMsXG4gICAgICAgICAgICAgIHRpdGxlOiBgVG9wIHJ1bGVzIGZvciAke2l0ZW19IHJlcXVpcmVtZW50YCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChbJ292ZXJ2aWV3JywgJ2FnZW50cyddLmluY2x1ZGVzKHNlY3Rpb24pICYmIHRhYiA9PT0gJ3RzYycpIHtcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsICdGZXRjaGluZyB0b3AgVFNDIHJlcXVpcmVtZW50cycsICdkZWJ1ZycpO1xuICAgICAgICBjb25zdCB0b3BUU0NSZXF1aXJlbWVudHMgPSBhd2FpdCBUU0NSZXF1ZXN0LnRvcFRTQ1JlcXVpcmVtZW50cyhcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIGZyb20sXG4gICAgICAgICAgdG8sXG4gICAgICAgICAgZmlsdGVycyxcbiAgICAgICAgICBwYXR0ZXJuXG4gICAgICAgICk7XG4gICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcbiAgICAgICAgICB0ZXh0OiAnTW9zdCBjb21tb24gVFNDIHJlcXVpcmVtZW50cyBhbGVydHMgZm91bmQnLFxuICAgICAgICAgIHN0eWxlOiAnaDInLFxuICAgICAgICB9KTtcbiAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIHRvcFRTQ1JlcXVpcmVtZW50cykge1xuICAgICAgICAgIGNvbnN0IHJ1bGVzID0gYXdhaXQgVFNDUmVxdWVzdC5nZXRSdWxlc0J5UmVxdWlyZW1lbnQoXG4gICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgZnJvbSxcbiAgICAgICAgICAgIHRvLFxuICAgICAgICAgICAgZmlsdGVycyxcbiAgICAgICAgICAgIGl0ZW0sXG4gICAgICAgICAgICBwYXR0ZXJuXG4gICAgICAgICAgKTtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7IHRleHQ6IGBSZXF1aXJlbWVudCAke2l0ZW19YCwgc3R5bGU6ICdoMycgfSk7XG5cbiAgICAgICAgICBpZiAoVFNDW2l0ZW1dKSB7XG4gICAgICAgICAgICBjb25zdCBjb250ZW50ID1cbiAgICAgICAgICAgICAgdHlwZW9mIFRTQ1tpdGVtXSA9PT0gJ3N0cmluZycgPyB7IHRleHQ6IFRTQ1tpdGVtXSwgc3R5bGU6ICdzdGFuZGFyZCcgfSA6IFRTQ1tpdGVtXTtcbiAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKGNvbnRlbnQpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJ1bGVzICYmXG4gICAgICAgICAgICBydWxlcy5sZW5ndGggJiZcbiAgICAgICAgICAgIHByaW50ZXIuYWRkU2ltcGxlVGFibGUoe1xuICAgICAgICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICAgICAgeyBpZDogJ3J1bGVJRCcsIGxhYmVsOiAnUnVsZSBJRCcgfSxcbiAgICAgICAgICAgICAgICB7IGlkOiAncnVsZURlc2NyaXB0aW9uJywgbGFiZWw6ICdEZXNjcmlwdGlvbicgfSxcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgaXRlbXM6IHJ1bGVzLFxuICAgICAgICAgICAgICB0aXRsZTogYFRvcCBydWxlcyBmb3IgJHtpdGVtfSByZXF1aXJlbWVudGAsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoWydvdmVydmlldycsICdhZ2VudHMnXS5pbmNsdWRlcyhzZWN0aW9uKSAmJiB0YWIgPT09ICdnZHByJykge1xuICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgJ0ZldGNoaW5nIHRvcCBHRFBSIHJlcXVpcmVtZW50cycsICdkZWJ1ZycpO1xuICAgICAgICBjb25zdCB0b3BHZHByUmVxdWlyZW1lbnRzID0gYXdhaXQgR0RQUlJlcXVlc3QudG9wR0RQUlJlcXVpcmVtZW50cyhcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIGZyb20sXG4gICAgICAgICAgdG8sXG4gICAgICAgICAgZmlsdGVycyxcbiAgICAgICAgICBwYXR0ZXJuXG4gICAgICAgICk7XG4gICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcbiAgICAgICAgICB0ZXh0OiAnTW9zdCBjb21tb24gR0RQUiByZXF1aXJlbWVudHMgYWxlcnRzIGZvdW5kJyxcbiAgICAgICAgICBzdHlsZTogJ2gyJyxcbiAgICAgICAgfSk7XG4gICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiB0b3BHZHByUmVxdWlyZW1lbnRzKSB7XG4gICAgICAgICAgY29uc3QgcnVsZXMgPSBhd2FpdCBHRFBSUmVxdWVzdC5nZXRSdWxlc0J5UmVxdWlyZW1lbnQoXG4gICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgZnJvbSxcbiAgICAgICAgICAgIHRvLFxuICAgICAgICAgICAgZmlsdGVycyxcbiAgICAgICAgICAgIGl0ZW0sXG4gICAgICAgICAgICBwYXR0ZXJuXG4gICAgICAgICAgKTtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7IHRleHQ6IGBSZXF1aXJlbWVudCAke2l0ZW19YCwgc3R5bGU6ICdoMycgfSk7XG5cbiAgICAgICAgICBpZiAoR0RQUiAmJiBHRFBSW2l0ZW1dKSB7XG4gICAgICAgICAgICBjb25zdCBjb250ZW50ID1cbiAgICAgICAgICAgICAgdHlwZW9mIEdEUFJbaXRlbV0gPT09ICdzdHJpbmcnID8geyB0ZXh0OiBHRFBSW2l0ZW1dLCBzdHlsZTogJ3N0YW5kYXJkJyB9IDogR0RQUltpdGVtXTtcbiAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKGNvbnRlbnQpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJ1bGVzICYmXG4gICAgICAgICAgICBydWxlcy5sZW5ndGggJiZcbiAgICAgICAgICAgIHByaW50ZXIuYWRkU2ltcGxlVGFibGUoe1xuICAgICAgICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICAgICAgeyBpZDogJ3J1bGVJRCcsIGxhYmVsOiAnUnVsZSBJRCcgfSxcbiAgICAgICAgICAgICAgICB7IGlkOiAncnVsZURlc2NyaXB0aW9uJywgbGFiZWw6ICdEZXNjcmlwdGlvbicgfSxcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgaXRlbXM6IHJ1bGVzLFxuICAgICAgICAgICAgICB0aXRsZTogYFRvcCBydWxlcyBmb3IgJHtpdGVtfSByZXF1aXJlbWVudGAsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHNlY3Rpb24gPT09ICdvdmVydmlldycgJiYgdGFiID09PSAnYXVkaXQnKSB7XG4gICAgICAgIGxvZyhcbiAgICAgICAgICAncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLFxuICAgICAgICAgICdGZXRjaGluZyBhZ2VudHMgd2l0aCBoaWdoIG51bWJlciBvZiBmYWlsZWQgc3VkbyBjb21tYW5kcycsXG4gICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICApO1xuICAgICAgICBjb25zdCBhdWRpdEFnZW50c05vblN1Y2Nlc3MgPSBhd2FpdCBBdWRpdFJlcXVlc3QuZ2V0VG9wM0FnZW50c1N1ZG9Ob25TdWNjZXNzZnVsKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICB0byxcbiAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgIHBhdHRlcm5cbiAgICAgICAgKTtcbiAgICAgICAgaWYgKGF1ZGl0QWdlbnRzTm9uU3VjY2VzcyAmJiBhdWRpdEFnZW50c05vblN1Y2Nlc3MubGVuZ3RoKSB7XG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcbiAgICAgICAgICAgIHRleHQ6ICdBZ2VudHMgd2l0aCBoaWdoIG51bWJlciBvZiBmYWlsZWQgc3VkbyBjb21tYW5kcycsXG4gICAgICAgICAgICBzdHlsZTogJ2gyJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBhd2FpdCB0aGlzLmJ1aWxkQWdlbnRzVGFibGUoY29udGV4dCwgcHJpbnRlciwgYXVkaXRBZ2VudHNOb25TdWNjZXNzLCBhcGlJZCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYXVkaXRBZ2VudHNGYWlsZWRTeXNjYWxsID0gYXdhaXQgQXVkaXRSZXF1ZXN0LmdldFRvcDNBZ2VudHNGYWlsZWRTeXNjYWxscyhcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIGZyb20sXG4gICAgICAgICAgdG8sXG4gICAgICAgICAgZmlsdGVycyxcbiAgICAgICAgICBwYXR0ZXJuXG4gICAgICAgICk7XG4gICAgICAgIGlmIChhdWRpdEFnZW50c0ZhaWxlZFN5c2NhbGwgJiYgYXVkaXRBZ2VudHNGYWlsZWRTeXNjYWxsLmxlbmd0aCkge1xuICAgICAgICAgIHByaW50ZXIuYWRkU2ltcGxlVGFibGUoe1xuICAgICAgICAgICAgY29sdW1uczogW1xuICAgICAgICAgICAgICB7IGlkOiAnYWdlbnQnLCBsYWJlbDogJ0FnZW50IElEJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnc3lzY2FsbF9pZCcsIGxhYmVsOiAnU3lzY2FsbCBJRCcgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ3N5c2NhbGxfc3lzY2FsbCcsIGxhYmVsOiAnU3lzY2FsbCcgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBpdGVtczogYXVkaXRBZ2VudHNGYWlsZWRTeXNjYWxsLm1hcCgoaXRlbSkgPT4gKHtcbiAgICAgICAgICAgICAgYWdlbnQ6IGl0ZW0uYWdlbnQsXG4gICAgICAgICAgICAgIHN5c2NhbGxfaWQ6IGl0ZW0uc3lzY2FsbC5pZCxcbiAgICAgICAgICAgICAgc3lzY2FsbF9zeXNjYWxsOiBpdGVtLnN5c2NhbGwuc3lzY2FsbCxcbiAgICAgICAgICAgIH0pKSxcbiAgICAgICAgICAgIHRpdGxlOiB7XG4gICAgICAgICAgICAgIHRleHQ6ICdNb3N0IGNvbW1vbiBmYWlsaW5nIHN5c2NhbGxzJyxcbiAgICAgICAgICAgICAgc3R5bGU6ICdoMicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChzZWN0aW9uID09PSAnb3ZlcnZpZXcnICYmIHRhYiA9PT0gJ2ZpbScpIHtcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsICdGZXRjaGluZyB0b3AgMyBydWxlcyBmb3IgRklNJywgJ2RlYnVnJyk7XG4gICAgICAgIGNvbnN0IHJ1bGVzID0gYXdhaXQgU3lzY2hlY2tSZXF1ZXN0LnRvcDNSdWxlcyhjb250ZXh0LCBmcm9tLCB0bywgZmlsdGVycywgcGF0dGVybik7XG5cbiAgICAgICAgaWYgKHJ1bGVzICYmIHJ1bGVzLmxlbmd0aCkge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHsgdGV4dDogJ1RvcCAzIEZJTSBydWxlcycsIHN0eWxlOiAnaDInIH0pLmFkZFNpbXBsZVRhYmxlKHtcbiAgICAgICAgICAgIGNvbHVtbnM6IFtcbiAgICAgICAgICAgICAgeyBpZDogJ3J1bGVJRCcsIGxhYmVsOiAnUnVsZSBJRCcgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ3J1bGVEZXNjcmlwdGlvbicsIGxhYmVsOiAnRGVzY3JpcHRpb24nIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgaXRlbXM6IHJ1bGVzLFxuICAgICAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgICAgdGV4dDogJ1RvcCAzIHJ1bGVzIHRoYXQgYXJlIGdlbmVyYXRpbmcgbW9zdCBhbGVydHMuJyxcbiAgICAgICAgICAgICAgc3R5bGU6ICdzdGFuZGFyZCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsICdGZXRjaGluZyB0b3AgMyBhZ2VudHMgZm9yIEZJTScsICdkZWJ1ZycpO1xuICAgICAgICBjb25zdCBhZ2VudHMgPSBhd2FpdCBTeXNjaGVja1JlcXVlc3QudG9wM2FnZW50cyhjb250ZXh0LCBmcm9tLCB0bywgZmlsdGVycywgcGF0dGVybik7XG5cbiAgICAgICAgaWYgKGFnZW50cyAmJiBhZ2VudHMubGVuZ3RoKSB7XG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xuICAgICAgICAgICAgdGV4dDogJ0FnZW50cyB3aXRoIHN1c3BpY2lvdXMgRklNIGFjdGl2aXR5JyxcbiAgICAgICAgICAgIHN0eWxlOiAnaDInLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcbiAgICAgICAgICAgIHRleHQ6XG4gICAgICAgICAgICAgICdUb3AgMyBhZ2VudHMgdGhhdCBoYXZlIG1vc3QgRklNIGFsZXJ0cyBmcm9tIGxldmVsIDcgdG8gbGV2ZWwgMTUuIFRha2UgY2FyZSBhYm91dCB0aGVtLicsXG4gICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBhd2FpdCB0aGlzLmJ1aWxkQWdlbnRzVGFibGUoY29udGV4dCwgcHJpbnRlciwgYWdlbnRzLCBhcGlJZCk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHNlY3Rpb24gPT09ICdhZ2VudHMnICYmIHRhYiA9PT0gJ2F1ZGl0Jykge1xuICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgYEZldGNoaW5nIG1vc3QgY29tbW9uIGZhaWxlZCBzeXNjYWxsc2AsICdkZWJ1ZycpO1xuICAgICAgICBjb25zdCBhdWRpdEZhaWxlZFN5c2NhbGwgPSBhd2FpdCBBdWRpdFJlcXVlc3QuZ2V0VG9wRmFpbGVkU3lzY2FsbHMoXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICBmcm9tLFxuICAgICAgICAgIHRvLFxuICAgICAgICAgIGZpbHRlcnMsXG4gICAgICAgICAgcGF0dGVyblxuICAgICAgICApO1xuICAgICAgICBhdWRpdEZhaWxlZFN5c2NhbGwgJiZcbiAgICAgICAgICBhdWRpdEZhaWxlZFN5c2NhbGwubGVuZ3RoICYmXG4gICAgICAgICAgcHJpbnRlci5hZGRTaW1wbGVUYWJsZSh7XG4gICAgICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICAgIHsgaWQ6ICdpZCcsIGxhYmVsOiAnaWQnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdzeXNjYWxsJywgbGFiZWw6ICdTeXNjYWxsJyB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIGl0ZW1zOiBhdWRpdEZhaWxlZFN5c2NhbGwsXG4gICAgICAgICAgICB0aXRsZTogJ01vc3QgY29tbW9uIGZhaWxpbmcgc3lzY2FsbHMnLFxuICAgICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBpZiAoc2VjdGlvbiA9PT0gJ2FnZW50cycgJiYgdGFiID09PSAnZmltJykge1xuICAgICAgICBsb2coXG4gICAgICAgICAgJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJyxcbiAgICAgICAgICBgRmV0Y2hpbmcgc3lzY2hlY2sgZGF0YWJhc2UgZm9yIGFnZW50ICR7YWdlbnR9YCxcbiAgICAgICAgICAnZGVidWcnXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc3QgbGFzdFNjYW5SZXNwb25zZSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgYC9zeXNjaGVjay8ke2FnZW50fS9sYXN0X3NjYW5gLFxuICAgICAgICAgIHt9LFxuICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XG4gICAgICAgICk7XG5cbiAgICAgICAgaWYgKGxhc3RTY2FuUmVzcG9uc2UgJiYgbGFzdFNjYW5SZXNwb25zZS5kYXRhKSB7XG4gICAgICAgICAgY29uc3QgbGFzdFNjYW5EYXRhID0gbGFzdFNjYW5SZXNwb25zZS5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF07XG4gICAgICAgICAgaWYgKGxhc3RTY2FuRGF0YS5zdGFydCAmJiBsYXN0U2NhbkRhdGEuZW5kKSB7XG4gICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICB0ZXh0OiBgTGFzdCBmaWxlIGludGVncml0eSBtb25pdG9yaW5nIHNjYW4gd2FzIGV4ZWN1dGVkIGZyb20gJHtsYXN0U2NhbkRhdGEuc3RhcnR9IHRvICR7bGFzdFNjYW5EYXRhLmVuZH0uYCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH0gZWxzZSBpZiAobGFzdFNjYW5EYXRhLnN0YXJ0KSB7XG4gICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICB0ZXh0OiBgRmlsZSBpbnRlZ3JpdHkgbW9uaXRvcmluZyBzY2FuIGlzIGN1cnJlbnRseSBpbiBwcm9ncmVzcyBmb3IgdGhpcyBhZ2VudCAoc3RhcnRlZCBvbiAke2xhc3RTY2FuRGF0YS5zdGFydH0pLmAsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcbiAgICAgICAgICAgICAgdGV4dDogYEZpbGUgaW50ZWdyaXR5IG1vbml0b3Jpbmcgc2NhbiBpcyBjdXJyZW50bHkgaW4gcHJvZ3Jlc3MgZm9yIHRoaXMgYWdlbnQuYCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCBgRmV0Y2hpbmcgbGFzdCAxMCBkZWxldGVkIGZpbGVzIGZvciBGSU1gLCAnZGVidWcnKTtcbiAgICAgICAgY29uc3QgbGFzdFRlbkRlbGV0ZWQgPSBhd2FpdCBTeXNjaGVja1JlcXVlc3QubGFzdFRlbkRlbGV0ZWRGaWxlcyhcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIGZyb20sXG4gICAgICAgICAgdG8sXG4gICAgICAgICAgZmlsdGVycyxcbiAgICAgICAgICBwYXR0ZXJuXG4gICAgICAgICk7XG5cbiAgICAgICAgbGFzdFRlbkRlbGV0ZWQgJiZcbiAgICAgICAgICBsYXN0VGVuRGVsZXRlZC5sZW5ndGggJiZcbiAgICAgICAgICBwcmludGVyLmFkZFNpbXBsZVRhYmxlKHtcbiAgICAgICAgICAgIGNvbHVtbnM6IFtcbiAgICAgICAgICAgICAgeyBpZDogJ3BhdGgnLCBsYWJlbDogJ1BhdGgnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdkYXRlJywgbGFiZWw6ICdEYXRlJyB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIGl0ZW1zOiBsYXN0VGVuRGVsZXRlZCxcbiAgICAgICAgICAgIHRpdGxlOiAnTGFzdCAxMCBkZWxldGVkIGZpbGVzJyxcbiAgICAgICAgICB9KTtcblxuICAgICAgICBsb2coJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJywgYEZldGNoaW5nIGxhc3QgMTAgbW9kaWZpZWQgZmlsZXNgLCAnZGVidWcnKTtcbiAgICAgICAgY29uc3QgbGFzdFRlbk1vZGlmaWVkID0gYXdhaXQgU3lzY2hlY2tSZXF1ZXN0Lmxhc3RUZW5Nb2RpZmllZEZpbGVzKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICB0byxcbiAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgIHBhdHRlcm5cbiAgICAgICAgKTtcblxuICAgICAgICBsYXN0VGVuTW9kaWZpZWQgJiZcbiAgICAgICAgICBsYXN0VGVuTW9kaWZpZWQubGVuZ3RoICYmXG4gICAgICAgICAgcHJpbnRlci5hZGRTaW1wbGVUYWJsZSh7XG4gICAgICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICAgIHsgaWQ6ICdwYXRoJywgbGFiZWw6ICdQYXRoJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnZGF0ZScsIGxhYmVsOiAnRGF0ZScgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBpdGVtczogbGFzdFRlbk1vZGlmaWVkLFxuICAgICAgICAgICAgdGl0bGU6ICdMYXN0IDEwIG1vZGlmaWVkIGZpbGVzJyxcbiAgICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgaWYgKHNlY3Rpb24gPT09ICdhZ2VudHMnICYmIHRhYiA9PT0gJ3N5c2NvbGxlY3RvcicpIHtcbiAgICAgICAgbG9nKFxuICAgICAgICAgICdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsXG4gICAgICAgICAgYEZldGNoaW5nIGhhcmR3YXJlIGluZm9ybWF0aW9uIGZvciBhZ2VudCAke2FnZW50fWAsXG4gICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICApO1xuICAgICAgICBjb25zdCByZXF1ZXN0c1N5c2NvbGxlY3Rvckxpc3RzID0gW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGVuZHBvaW50OiBgL3N5c2NvbGxlY3Rvci8ke2FnZW50fS9oYXJkd2FyZWAsXG4gICAgICAgICAgICBsb2dnZXJNZXNzYWdlOiBgRmV0Y2hpbmcgSGFyZHdhcmUgaW5mb3JtYXRpb24gZm9yIGFnZW50ICR7YWdlbnR9YCxcbiAgICAgICAgICAgIGxpc3Q6IHtcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ0hhcmR3YXJlIGluZm9ybWF0aW9uJywgc3R5bGU6ICdoMicgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBtYXBSZXNwb25zZTogKGhhcmR3YXJlKSA9PiBbXG4gICAgICAgICAgICAgIGhhcmR3YXJlLmNwdSAmJiBoYXJkd2FyZS5jcHUuY29yZXMgJiYgYCR7aGFyZHdhcmUuY3B1LmNvcmVzfSBjb3Jlc2AsXG4gICAgICAgICAgICAgIGhhcmR3YXJlLmNwdSAmJiBoYXJkd2FyZS5jcHUubmFtZSxcbiAgICAgICAgICAgICAgaGFyZHdhcmUucmFtICYmXG4gICAgICAgICAgICAgICAgaGFyZHdhcmUucmFtLnRvdGFsICYmXG4gICAgICAgICAgICAgICAgYCR7TnVtYmVyKGhhcmR3YXJlLnJhbS50b3RhbCAvIDEwMjQgLyAxMDI0KS50b0ZpeGVkKDIpfUdCIFJBTWAsXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgZW5kcG9pbnQ6IGAvc3lzY29sbGVjdG9yLyR7YWdlbnR9L29zYCxcbiAgICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBPUyBpbmZvcm1hdGlvbiBmb3IgYWdlbnQgJHthZ2VudH1gLFxuICAgICAgICAgICAgbGlzdDoge1xuICAgICAgICAgICAgICB0aXRsZTogeyB0ZXh0OiAnT1MgaW5mb3JtYXRpb24nLCBzdHlsZTogJ2gyJyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG1hcFJlc3BvbnNlOiAob3NEYXRhKSA9PiBbXG4gICAgICAgICAgICAgIG9zRGF0YS5zeXNuYW1lLFxuICAgICAgICAgICAgICBvc0RhdGEudmVyc2lvbixcbiAgICAgICAgICAgICAgb3NEYXRhLmFyY2hpdGVjdHVyZSxcbiAgICAgICAgICAgICAgb3NEYXRhLnJlbGVhc2UsXG4gICAgICAgICAgICAgIG9zRGF0YS5vcyAmJlxuICAgICAgICAgICAgICAgIG9zRGF0YS5vcy5uYW1lICYmXG4gICAgICAgICAgICAgICAgb3NEYXRhLm9zLnZlcnNpb24gJiZcbiAgICAgICAgICAgICAgICBgJHtvc0RhdGEub3MubmFtZX0gJHtvc0RhdGEub3MudmVyc2lvbn1gLFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICBdO1xuXG4gICAgICAgIGNvbnN0IHN5c2NvbGxlY3Rvckxpc3RzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgICAgcmVxdWVzdHNTeXNjb2xsZWN0b3JMaXN0cy5tYXAoYXN5bmMgKHJlcXVlc3RTeXNjb2xsZWN0b3IpID0+IHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCByZXF1ZXN0U3lzY29sbGVjdG9yLmxvZ2dlck1lc3NhZ2UsICdkZWJ1ZycpO1xuICAgICAgICAgICAgICBjb25zdCByZXNwb25zZVN5c2NvbGxlY3RvciA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICAgICAgcmVxdWVzdFN5c2NvbGxlY3Rvci5lbmRwb2ludCxcbiAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICBjb25zdCBbZGF0YV0gPVxuICAgICAgICAgICAgICAgIChyZXNwb25zZVN5c2NvbGxlY3RvciAmJlxuICAgICAgICAgICAgICAgICAgcmVzcG9uc2VTeXNjb2xsZWN0b3IuZGF0YSAmJlxuICAgICAgICAgICAgICAgICAgcmVzcG9uc2VTeXNjb2xsZWN0b3IuZGF0YS5kYXRhICYmXG4gICAgICAgICAgICAgICAgICByZXNwb25zZVN5c2NvbGxlY3Rvci5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXMpIHx8XG4gICAgICAgICAgICAgICAgW107XG4gICAgICAgICAgICAgIGlmIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgIC4uLnJlcXVlc3RTeXNjb2xsZWN0b3IubGlzdCxcbiAgICAgICAgICAgICAgICAgIGxpc3Q6IHJlcXVlc3RTeXNjb2xsZWN0b3IubWFwUmVzcG9uc2UoZGF0YSksXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pXG4gICAgICAgICk7XG5cbiAgICAgICAgaWYgKHN5c2NvbGxlY3Rvckxpc3RzKSB7XG4gICAgICAgICAgc3lzY29sbGVjdG9yTGlzdHNcbiAgICAgICAgICAgIC5maWx0ZXIoKHN5c2NvbGxlY3Rvckxpc3QpID0+IHN5c2NvbGxlY3Rvckxpc3QpXG4gICAgICAgICAgICAuZm9yRWFjaCgoc3lzY29sbGVjdG9yTGlzdCkgPT4gcHJpbnRlci5hZGRMaXN0KHN5c2NvbGxlY3Rvckxpc3QpKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHZ1bG5lcmFiaWxpdGllc1JlcXVlc3RzID0gWydDcml0aWNhbCcsICdIaWdoJ107XG5cbiAgICAgICAgY29uc3QgdnVsbmVyYWJpbGl0aWVzUmVzcG9uc2VzSXRlbXMgPSAoXG4gICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgICAgICB2dWxuZXJhYmlsaXRpZXNSZXF1ZXN0cy5tYXAoYXN5bmMgKHZ1bG5lcmFiaWxpdGllc0xldmVsKSA9PiB7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgbG9nKFxuICAgICAgICAgICAgICAgICAgJ3JlcG9ydGluZzpleHRlbmRlZEluZm9ybWF0aW9uJyxcbiAgICAgICAgICAgICAgICAgIGBGZXRjaGluZyB0b3AgJHt2dWxuZXJhYmlsaXRpZXNMZXZlbH0gcGFja2FnZXNgLFxuICAgICAgICAgICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgVnVsbmVyYWJpbGl0eVJlcXVlc3QudG9wUGFja2FnZXMoXG4gICAgICAgICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgICAgICAgZnJvbSxcbiAgICAgICAgICAgICAgICAgIHRvLFxuICAgICAgICAgICAgICAgICAgdnVsbmVyYWJpbGl0aWVzTGV2ZWwsXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgICAgICAgICAgcGF0dGVyblxuICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgbG9nKCdyZXBvcnRpbmc6ZXh0ZW5kZWRJbmZvcm1hdGlvbicsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgICAgIC5maWx0ZXIoKHZ1bG5lcmFiaWxpdGllc1Jlc3BvbnNlKSA9PiB2dWxuZXJhYmlsaXRpZXNSZXNwb25zZSlcbiAgICAgICAgICAuZmxhdCgpO1xuXG4gICAgICAgIGlmICh2dWxuZXJhYmlsaXRpZXNSZXNwb25zZXNJdGVtcyAmJiB2dWxuZXJhYmlsaXRpZXNSZXNwb25zZXNJdGVtcy5sZW5ndGgpIHtcbiAgICAgICAgICBwcmludGVyLmFkZFNpbXBsZVRhYmxlKHtcbiAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdWdWxuZXJhYmxlIHBhY2thZ2VzIGZvdW5kIChsYXN0IDI0IGhvdXJzKScsIHN0eWxlOiAnaDInIH0sXG4gICAgICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICAgIHsgaWQ6ICdwYWNrYWdlJywgbGFiZWw6ICdQYWNrYWdlJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnc2V2ZXJpdHknLCBsYWJlbDogJ1NldmVyaXR5JyB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIGl0ZW1zOiB2dWxuZXJhYmlsaXRpZXNSZXNwb25zZXNJdGVtcyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoc2VjdGlvbiA9PT0gJ2FnZW50cycgJiYgdGFiID09PSAndnVscycpIHtcbiAgICAgICAgY29uc3QgdG9wQ3JpdGljYWxQYWNrYWdlcyA9IGF3YWl0IFZ1bG5lcmFiaWxpdHlSZXF1ZXN0LnRvcFBhY2thZ2VzV2l0aENWRShcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIGZyb20sXG4gICAgICAgICAgdG8sXG4gICAgICAgICAgJ0NyaXRpY2FsJyxcbiAgICAgICAgICBmaWx0ZXJzLFxuICAgICAgICAgIHBhdHRlcm5cbiAgICAgICAgKTtcbiAgICAgICAgaWYgKHRvcENyaXRpY2FsUGFja2FnZXMgJiYgdG9wQ3JpdGljYWxQYWNrYWdlcy5sZW5ndGgpIHtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7IHRleHQ6ICdDcml0aWNhbCBzZXZlcml0eScsIHN0eWxlOiAnaDInIH0pO1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcbiAgICAgICAgICAgIHRleHQ6XG4gICAgICAgICAgICAgICdUaGVzZSB2dWxuZXJhYmlsdGllcyBhcmUgY3JpdGljYWwsIHBsZWFzZSByZXZpZXcgeW91ciBhZ2VudC4gQ2xpY2sgb24gZWFjaCBsaW5rIHRvIHJlYWQgbW9yZSBhYm91dCBlYWNoIGZvdW5kIHZ1bG5lcmFiaWxpdHkuJyxcbiAgICAgICAgICAgIHN0eWxlOiAnc3RhbmRhcmQnLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbnN0IGN1c3RvbXVsID0gW107XG4gICAgICAgICAgZm9yIChjb25zdCBjcml0aWNhbCBvZiB0b3BDcml0aWNhbFBhY2thZ2VzKSB7XG4gICAgICAgICAgICBjdXN0b211bC5wdXNoKHsgdGV4dDogY3JpdGljYWwucGFja2FnZSwgc3R5bGU6ICdzdGFuZGFyZCcgfSk7XG4gICAgICAgICAgICBjdXN0b211bC5wdXNoKHtcbiAgICAgICAgICAgICAgdWw6IGNyaXRpY2FsLnJlZmVyZW5jZXMubWFwKChpdGVtKSA9PiAoe1xuICAgICAgICAgICAgICAgIHRleHQ6IGl0ZW0uc3Vic3RyaW5nKDAsIDgwKSArICcuLi4nLFxuICAgICAgICAgICAgICAgIGxpbms6IGl0ZW0sXG4gICAgICAgICAgICAgICAgY29sb3I6ICcjMUVBNUM4JyxcbiAgICAgICAgICAgICAgfSkpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHsgdWw6IGN1c3RvbXVsIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgdG9wSGlnaFBhY2thZ2VzID0gYXdhaXQgVnVsbmVyYWJpbGl0eVJlcXVlc3QudG9wUGFja2FnZXNXaXRoQ1ZFKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICB0byxcbiAgICAgICAgICAnSGlnaCcsXG4gICAgICAgICAgZmlsdGVycyxcbiAgICAgICAgICBwYXR0ZXJuXG4gICAgICAgICk7XG4gICAgICAgIGlmICh0b3BIaWdoUGFja2FnZXMgJiYgdG9wSGlnaFBhY2thZ2VzLmxlbmd0aCkge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHsgdGV4dDogJ0hpZ2ggc2V2ZXJpdHknLCBzdHlsZTogJ2gyJyB9KTtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XG4gICAgICAgICAgICB0ZXh0OiAnQ2xpY2sgb24gZWFjaCBsaW5rIHRvIHJlYWQgbW9yZSBhYm91dCBlYWNoIGZvdW5kIHZ1bG5lcmFiaWxpdHkuJyxcbiAgICAgICAgICAgIHN0eWxlOiAnc3RhbmRhcmQnLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbnN0IGN1c3RvbXVsID0gW107XG4gICAgICAgICAgZm9yIChjb25zdCBjcml0aWNhbCBvZiB0b3BIaWdoUGFja2FnZXMpIHtcbiAgICAgICAgICAgIGN1c3RvbXVsLnB1c2goeyB0ZXh0OiBjcml0aWNhbC5wYWNrYWdlLCBzdHlsZTogJ3N0YW5kYXJkJyB9KTtcbiAgICAgICAgICAgIGN1c3RvbXVsLnB1c2goe1xuICAgICAgICAgICAgICB1bDogY3JpdGljYWwucmVmZXJlbmNlcy5tYXAoKGl0ZW0pID0+ICh7XG4gICAgICAgICAgICAgICAgdGV4dDogaXRlbSxcbiAgICAgICAgICAgICAgICBjb2xvcjogJyMxRUE1QzgnLFxuICAgICAgICAgICAgICB9KSksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY3VzdG9tdWwgJiYgY3VzdG9tdWwubGVuZ3RoICYmIHByaW50ZXIuYWRkQ29udGVudCh7IHVsOiBjdXN0b211bCB9KTtcbiAgICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygncmVwb3J0aW5nOmV4dGVuZGVkSW5mb3JtYXRpb24nLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBnZXRDb25maWdSb3dzKGRhdGEsIGxhYmVscykge1xuICAgIGxvZygncmVwb3J0aW5nOmdldENvbmZpZ1Jvd3MnLCBgQnVpbGRpbmcgY29uZmlndXJhdGlvbiByb3dzYCwgJ2luZm8nKTtcbiAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICBmb3IgKGxldCBwcm9wIGluIGRhdGEgfHwgW10pIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGFbcHJvcF0pKSB7XG4gICAgICAgIGRhdGFbcHJvcF0uZm9yRWFjaCgoeCwgaWR4KSA9PiB7XG4gICAgICAgICAgaWYgKHR5cGVvZiB4ID09PSAnb2JqZWN0JykgZGF0YVtwcm9wXVtpZHhdID0gSlNPTi5zdHJpbmdpZnkoeCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmVzdWx0LnB1c2goWyhsYWJlbHMgfHwge30pW3Byb3BdIHx8IEtleUVxdWl2YWxlbmNlW3Byb3BdIHx8IHByb3AsIGRhdGFbcHJvcF0gfHwgJy0nXSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICBwcml2YXRlIGdldENvbmZpZ1RhYmxlcyhkYXRhLCBzZWN0aW9uLCB0YWIsIGFycmF5ID0gW10pIHtcbiAgICBsb2coJ3JlcG9ydGluZzpnZXRDb25maWdUYWJsZXMnLCBgQnVpbGRpbmcgY29uZmlndXJhdGlvbiB0YWJsZXNgLCAnaW5mbycpO1xuICAgIGxldCBwbGFpbkRhdGEgPSB7fTtcbiAgICBjb25zdCBuZXN0ZWREYXRhID0gW107XG4gICAgY29uc3QgdGFibGVEYXRhID0gW107XG5cbiAgICBpZiAoZGF0YS5sZW5ndGggPT09IDEgJiYgQXJyYXkuaXNBcnJheShkYXRhKSkge1xuICAgICAgdGFibGVEYXRhW3NlY3Rpb24uY29uZmlnW3RhYl0uY29uZmlndXJhdGlvbl0gPSBkYXRhO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGxldCBrZXkgaW4gZGF0YSkge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgKHR5cGVvZiBkYXRhW2tleV0gIT09ICdvYmplY3QnICYmICFBcnJheS5pc0FycmF5KGRhdGFba2V5XSkpIHx8XG4gICAgICAgICAgKEFycmF5LmlzQXJyYXkoZGF0YVtrZXldKSAmJiB0eXBlb2YgZGF0YVtrZXldWzBdICE9PSAnb2JqZWN0JylcbiAgICAgICAgKSB7XG4gICAgICAgICAgcGxhaW5EYXRhW2tleV0gPVxuICAgICAgICAgICAgQXJyYXkuaXNBcnJheShkYXRhW2tleV0pICYmIHR5cGVvZiBkYXRhW2tleV1bMF0gIT09ICdvYmplY3QnXG4gICAgICAgICAgICAgID8gZGF0YVtrZXldLm1hcCgoeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB4ID09PSAnb2JqZWN0JyA/IEpTT04uc3RyaW5naWZ5KHgpIDogeCArICdcXG4nO1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIDogZGF0YVtrZXldO1xuICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoZGF0YVtrZXldKSAmJiB0eXBlb2YgZGF0YVtrZXldWzBdID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgIHRhYmxlRGF0YVtrZXldID0gZGF0YVtrZXldO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmIChzZWN0aW9uLmlzR3JvdXBDb25maWcgJiYgWydwYWNrJywgJ2NvbnRlbnQnXS5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgICAgICB0YWJsZURhdGFba2V5XSA9IFtkYXRhW2tleV1dO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXN0ZWREYXRhLnB1c2goZGF0YVtrZXldKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgYXJyYXkucHVzaCh7XG4gICAgICB0aXRsZTogKHNlY3Rpb24ub3B0aW9ucyB8fCB7fSkuaGlkZUhlYWRlclxuICAgICAgICA/ICcnXG4gICAgICAgIDogKHNlY3Rpb24udGFicyB8fCBbXSlbdGFiXSB8fFxuICAgICAgICAgIChzZWN0aW9uLmlzR3JvdXBDb25maWcgPyAoKHNlY3Rpb24ubGFiZWxzIHx8IFtdKVswXSB8fCBbXSlbdGFiXSA6ICcnKSxcbiAgICAgIGNvbHVtbnM6IFsnJywgJyddLFxuICAgICAgdHlwZTogJ2NvbmZpZycsXG4gICAgICByb3dzOiB0aGlzLmdldENvbmZpZ1Jvd3MocGxhaW5EYXRhLCAoc2VjdGlvbi5sYWJlbHMgfHwgW10pWzBdKSxcbiAgICB9KTtcbiAgICBmb3IgKGxldCBrZXkgaW4gdGFibGVEYXRhKSB7XG4gICAgICBjb25zdCBjb2x1bW5zID0gT2JqZWN0LmtleXModGFibGVEYXRhW2tleV1bMF0pO1xuICAgICAgY29sdW1ucy5mb3JFYWNoKChjb2wsIGkpID0+IHtcbiAgICAgICAgY29sdW1uc1tpXSA9IGNvbFswXS50b1VwcGVyQ2FzZSgpICsgY29sLnNsaWNlKDEpO1xuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IHJvd3MgPSB0YWJsZURhdGFba2V5XS5tYXAoKHgpID0+IHtcbiAgICAgICAgbGV0IHJvdyA9IFtdO1xuICAgICAgICBmb3IgKGxldCBrZXkgaW4geCkge1xuICAgICAgICAgIHJvdy5wdXNoKFxuICAgICAgICAgICAgdHlwZW9mIHhba2V5XSAhPT0gJ29iamVjdCdcbiAgICAgICAgICAgICAgPyB4W2tleV1cbiAgICAgICAgICAgICAgOiBBcnJheS5pc0FycmF5KHhba2V5XSlcbiAgICAgICAgICAgICAgPyB4W2tleV0ubWFwKCh4KSA9PiB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4geCArICdcXG4nO1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIDogSlNPTi5zdHJpbmdpZnkoeFtrZXldKVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKHJvdy5sZW5ndGggPCBjb2x1bW5zLmxlbmd0aCkge1xuICAgICAgICAgIHJvdy5wdXNoKCctJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJvdztcbiAgICAgIH0pO1xuICAgICAgYXJyYXkucHVzaCh7XG4gICAgICAgIHRpdGxlOiAoKHNlY3Rpb24ubGFiZWxzIHx8IFtdKVswXSB8fCBbXSlba2V5XSB8fCAnJyxcbiAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgY29sdW1ucyxcbiAgICAgICAgcm93cyxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBuZXN0ZWREYXRhLmZvckVhY2gobmVzdCA9PiB7XG4gICAgICB0aGlzLmdldENvbmZpZ1RhYmxlcyhuZXN0LCBzZWN0aW9uLCB0YWIgKyAxLCBhcnJheSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGFycmF5O1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIHJlcG9ydCBmb3IgdGhlIG1vZHVsZXNcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHsqfSByZXBvcnRzIGxpc3Qgb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgY3JlYXRlUmVwb3J0c01vZHVsZXMoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVxdWVzdCxcbiAgICByZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnlcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNNb2R1bGVzJywgYFJlcG9ydCBzdGFydGVkYCwgJ2luZm8nKTtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgYXJyYXksXG4gICAgICAgIGFnZW50cyxcbiAgICAgICAgYnJvd3NlclRpbWV6b25lLFxuICAgICAgICBzZWFyY2hCYXIsXG4gICAgICAgIGZpbHRlcnMsXG4gICAgICAgIHRpbWUsXG4gICAgICAgIHRhYmxlcyxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgc2VjdGlvbixcbiAgICAgICAgaW5kZXhQYXR0ZXJuVGl0bGUsXG4gICAgICAgIGFwaUlkXG4gICAgICB9ID0gcmVxdWVzdC5ib2R5O1xuICAgICAgY29uc3QgeyBtb2R1bGVJRCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICBjb25zdCB7IGZyb20sIHRvIH0gPSB0aW1lIHx8IHt9O1xuICAgICAgLy8gSW5pdFxuICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKCk7XG4gICAgICBjb25zdCB7IHVzZXJuYW1lOiB1c2VySUQgfSA9IGF3YWl0IGNvbnRleHQud2F6dWguc2VjdXJpdHkuZ2V0Q3VycmVudFVzZXIocmVxdWVzdCwgY29udGV4dCk7XG4gICAgICBjcmVhdGVEYXRhRGlyZWN0b3J5SWZOb3RFeGlzdHMoKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKFdBWlVIX0RBVEFfRE9XTkxPQURTX0RJUkVDVE9SWV9QQVRIKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgpO1xuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMocGF0aC5qb2luKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsIHVzZXJJRCkpO1xuXG4gICAgICBhd2FpdCB0aGlzLnJlbmRlckhlYWRlcihjb250ZXh0LCBwcmludGVyLCBzZWN0aW9uLCBtb2R1bGVJRCwgYWdlbnRzLCBhcGlJZCk7XG5cbiAgICAgIGNvbnN0IFtzYW5pdGl6ZWRGaWx0ZXJzLCBhZ2VudHNGaWx0ZXJdID0gZmlsdGVyc1xuICAgICAgICA/IHRoaXMuc2FuaXRpemVLaWJhbmFGaWx0ZXJzKGZpbHRlcnMsIHNlYXJjaEJhcilcbiAgICAgICAgOiBbZmFsc2UsIGZhbHNlXTtcblxuICAgICAgaWYgKHRpbWUgJiYgc2FuaXRpemVkRmlsdGVycykge1xuICAgICAgICBwcmludGVyLmFkZFRpbWVSYW5nZUFuZEZpbHRlcnMoZnJvbSwgdG8sIHNhbml0aXplZEZpbHRlcnMsIGJyb3dzZXJUaW1lem9uZSk7XG4gICAgICB9XG5cbiAgICAgIGlmICh0aW1lKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuZXh0ZW5kZWRJbmZvcm1hdGlvbihcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIHByaW50ZXIsXG4gICAgICAgICAgc2VjdGlvbixcbiAgICAgICAgICBtb2R1bGVJRCxcbiAgICAgICAgICBhcGlJZCxcbiAgICAgICAgICBuZXcgRGF0ZShmcm9tKS5nZXRUaW1lKCksXG4gICAgICAgICAgbmV3IERhdGUodG8pLmdldFRpbWUoKSxcbiAgICAgICAgICBzYW5pdGl6ZWRGaWx0ZXJzLFxuICAgICAgICAgIGluZGV4UGF0dGVyblRpdGxlLFxuICAgICAgICAgIGFnZW50c1xuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBwcmludGVyLmFkZFZpc3VhbGl6YXRpb25zKGFycmF5LCBhZ2VudHMsIG1vZHVsZUlEKTtcblxuICAgICAgaWYgKHRhYmxlcykge1xuICAgICAgICBwcmludGVyLmFkZFRhYmxlcyh0YWJsZXMpO1xuICAgICAgfVxuXG4gICAgICAvL2FkZCBhdXRob3JpemVkIGFnZW50c1xuICAgICAgaWYgKGFnZW50c0ZpbHRlcikge1xuICAgICAgICBwcmludGVyLmFkZEFnZW50c0ZpbHRlcnMoYWdlbnRzRmlsdGVyKTtcbiAgICAgIH1cblxuICAgICAgYXdhaXQgcHJpbnRlci5wcmludChwYXRoLmpvaW4oV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCwgdXNlcklELCBuYW1lKSk7XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIG1lc3NhZ2U6IGBSZXBvcnQgJHtuYW1lfSB3YXMgY3JlYXRlZGAsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAyOSwgNTAwLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIHJlcG9ydCBmb3IgdGhlIGdyb3Vwc1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMgeyp9IHJlcG9ydHMgbGlzdCBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBjcmVhdGVSZXBvcnRzR3JvdXBzKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XG4gICkge1xuICAgIHRyeSB7XG4gICAgICBsb2coJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzR3JvdXBzJywgYFJlcG9ydCBzdGFydGVkYCwgJ2luZm8nKTtcbiAgICAgIGNvbnN0IHsgbmFtZSwgY29tcG9uZW50cywgYXBpSWQgfSA9IHJlcXVlc3QuYm9keTtcbiAgICAgIGNvbnN0IHsgZ3JvdXBJRCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAvLyBJbml0XG4gICAgICBjb25zdCBwcmludGVyID0gbmV3IFJlcG9ydFByaW50ZXIoKTtcblxuICAgICAgY29uc3QgeyB1c2VybmFtZTogdXNlcklEIH0gPSBhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpO1xuICAgICAgY3JlYXRlRGF0YURpcmVjdG9yeUlmTm90RXhpc3RzKCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19ESVJFQ1RPUllfUEFUSCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRIKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKHBhdGguam9pbihXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRILCB1c2VySUQpKTtcblxuICAgICAgbGV0IHRhYmxlcyA9IFtdO1xuICAgICAgY29uc3QgZXF1aXZhbGVuY2VzID0ge1xuICAgICAgICBsb2NhbGZpbGU6ICdMb2NhbCBmaWxlcycsXG4gICAgICAgIG9zcXVlcnk6ICdPc3F1ZXJ5JyxcbiAgICAgICAgY29tbWFuZDogJ0NvbW1hbmQnLFxuICAgICAgICBzeXNjaGVjazogJ1N5c2NoZWNrJyxcbiAgICAgICAgJ29wZW4tc2NhcCc6ICdPcGVuU0NBUCcsXG4gICAgICAgICdjaXMtY2F0JzogJ0NJUy1DQVQnLFxuICAgICAgICBzeXNjb2xsZWN0b3I6ICdTeXNjb2xsZWN0b3InLFxuICAgICAgICByb290Y2hlY2s6ICdSb290Y2hlY2snLFxuICAgICAgICBsYWJlbHM6ICdMYWJlbHMnLFxuICAgICAgICBzY2E6ICdTZWN1cml0eSBjb25maWd1cmF0aW9uIGFzc2Vzc21lbnQnLFxuICAgICAgfTtcbiAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgIHRleHQ6IGBHcm91cCAke2dyb3VwSUR9IGNvbmZpZ3VyYXRpb25gLFxuICAgICAgICBzdHlsZTogJ2gxJyxcbiAgICAgIH0pO1xuXG4gICAgICBpZiAoY29tcG9uZW50c1snMCddKSB7XG4gICAgICAgIGxldCBjb25maWd1cmF0aW9uID0ge307XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgY29uZmlndXJhdGlvblJlc3BvbnNlID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcbiAgICAgICAgICAgICdHRVQnLFxuICAgICAgICAgICAgYC9ncm91cHMvJHtncm91cElEfS9jb25maWd1cmF0aW9uYCxcbiAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IGFwaUlkIH1cbiAgICAgICAgICApO1xuICAgICAgICAgIGNvbmZpZ3VyYXRpb24gPSBjb25maWd1cmF0aW9uUmVzcG9uc2UuZGF0YS5kYXRhO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNHcm91cHMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAnZGVidWcnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChcbiAgICAgICAgICBjb25maWd1cmF0aW9uLmFmZmVjdGVkX2l0ZW1zLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgICBPYmplY3Qua2V5cyhjb25maWd1cmF0aW9uLmFmZmVjdGVkX2l0ZW1zWzBdLmNvbmZpZykubGVuZ3RoXG4gICAgICAgICkge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiAnQ29uZmlndXJhdGlvbnMnLFxuICAgICAgICAgICAgc3R5bGU6IHsgZm9udFNpemU6IDE0LCBjb2xvcjogJyMwMDAnIH0sXG4gICAgICAgICAgICBtYXJnaW46IFswLCAxMCwgMCwgMTVdLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbnN0IHNlY3Rpb24gPSB7XG4gICAgICAgICAgICBsYWJlbHM6IFtdLFxuICAgICAgICAgICAgaXNHcm91cENvbmZpZzogdHJ1ZSxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGZvciAobGV0IGNvbmZpZyBvZiBjb25maWd1cmF0aW9uLmFmZmVjdGVkX2l0ZW1zKSB7XG4gICAgICAgICAgICBsZXQgZmlsdGVyVGl0bGUgPSAnJztcbiAgICAgICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgICAgICBmb3IgKGxldCBmaWx0ZXIgb2YgT2JqZWN0LmtleXMoY29uZmlnLmZpbHRlcnMpKSB7XG4gICAgICAgICAgICAgIGZpbHRlclRpdGxlID0gZmlsdGVyVGl0bGUuY29uY2F0KGAke2ZpbHRlcn06ICR7Y29uZmlnLmZpbHRlcnNbZmlsdGVyXX1gKTtcbiAgICAgICAgICAgICAgaWYgKGluZGV4IDwgT2JqZWN0LmtleXMoY29uZmlnLmZpbHRlcnMpLmxlbmd0aCAtIDEpIHtcbiAgICAgICAgICAgICAgICBmaWx0ZXJUaXRsZSA9IGZpbHRlclRpdGxlLmNvbmNhdCgnIHwgJyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaW5kZXgrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICAgIHRleHQ6IGZpbHRlclRpdGxlLFxuICAgICAgICAgICAgICBzdHlsZTogJ2g0JyxcbiAgICAgICAgICAgICAgbWFyZ2luOiBbMCwgMCwgMCwgMTBdLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBsZXQgaWR4ID0gMDtcbiAgICAgICAgICAgIHNlY3Rpb24udGFicyA9IFtdO1xuICAgICAgICAgICAgZm9yIChsZXQgX2Qgb2YgT2JqZWN0LmtleXMoY29uZmlnLmNvbmZpZykpIHtcbiAgICAgICAgICAgICAgZm9yIChsZXQgYyBvZiBBZ2VudENvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBzIG9mIGMuc2VjdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgIHNlY3Rpb24ub3B0cyA9IHMub3B0cyB8fCB7fTtcbiAgICAgICAgICAgICAgICAgIGZvciAobGV0IGNuIG9mIHMuY29uZmlnIHx8IFtdKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjbi5jb25maWd1cmF0aW9uID09PSBfZCkge1xuICAgICAgICAgICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzID0gcy5sYWJlbHMgfHwgW1tdXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgZm9yIChsZXQgd28gb2Ygcy53b2RsZSB8fCBbXSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAod28ubmFtZSA9PT0gX2QpIHtcbiAgICAgICAgICAgICAgICAgICAgICBzZWN0aW9uLmxhYmVscyA9IHMubGFiZWxzIHx8IFtbXV07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgc2VjdGlvbi5sYWJlbHNbMF1bJ3BhY2snXSA9ICdQYWNrcyc7XG4gICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzWzBdWydjb250ZW50J10gPSAnRXZhbHVhdGlvbnMnO1xuICAgICAgICAgICAgICBzZWN0aW9uLmxhYmVsc1swXVsnNyddID0gJ1NjYW4gbGlzdGVuaW5nIG5ldHdvdGsgcG9ydHMnO1xuICAgICAgICAgICAgICBzZWN0aW9uLnRhYnMucHVzaChlcXVpdmFsZW5jZXNbX2RdKTtcblxuICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShjb25maWcuY29uZmlnW19kXSkpIHtcbiAgICAgICAgICAgICAgICAvKiBMT0cgQ09MTEVDVE9SICovXG4gICAgICAgICAgICAgICAgaWYgKF9kID09PSAnbG9jYWxmaWxlJykge1xuICAgICAgICAgICAgICAgICAgbGV0IGdyb3VwcyA9IFtdO1xuICAgICAgICAgICAgICAgICAgY29uZmlnLmNvbmZpZ1tfZF0uZm9yRWFjaCgob2JqKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghZ3JvdXBzW29iai5sb2dmb3JtYXRdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW29iai5sb2dmb3JtYXRdID0gW107XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW29iai5sb2dmb3JtYXRdLnB1c2gob2JqKTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXMoZ3JvdXBzKS5mb3JFYWNoKChncm91cCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgc2F2ZWlkeCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIGdyb3Vwc1tncm91cF0uZm9yRWFjaCgoeCwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChPYmplY3Qua2V5cyh4KS5sZW5ndGggPiBPYmplY3Qua2V5cyhncm91cHNbZ3JvdXBdW3NhdmVpZHhdKS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhdmVpZHggPSBpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbHVtbnMgPSBPYmplY3Qua2V5cyhncm91cHNbZ3JvdXBdW3NhdmVpZHhdKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgcm93cyA9IGdyb3Vwc1tncm91cF0ubWFwKCh4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgbGV0IHJvdyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZW9mIHhba2V5XSAhPT0gJ29iamVjdCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHhba2V5XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogQXJyYXkuaXNBcnJheSh4W2tleV0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB4W2tleV0ubWFwKCh4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB4ICsgJ1xcbic7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogSlNPTi5zdHJpbmdpZnkoeFtrZXldKVxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcm93O1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKChjb2wsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zW2ldID0gY29sWzBdLnRvVXBwZXJDYXNlKCkgKyBjb2wuc2xpY2UoMSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdMb2NhbCBmaWxlcycsXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLFxuICAgICAgICAgICAgICAgICAgICAgIHJvd3MsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChfZCA9PT0gJ2xhYmVscycpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IG9iaiA9IGNvbmZpZy5jb25maWdbX2RdWzBdLmxhYmVsO1xuICAgICAgICAgICAgICAgICAgY29uc3QgY29sdW1ucyA9IE9iamVjdC5rZXlzKG9ialswXSk7XG4gICAgICAgICAgICAgICAgICBpZiAoIWNvbHVtbnMuaW5jbHVkZXMoJ2hpZGRlbicpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMucHVzaCgnaGlkZGVuJyk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjb25zdCByb3dzID0gb2JqLm1hcCgoeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgcm93ID0gW107XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goeFtrZXldKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByb3c7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoY29sLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnNbaV0gPSBjb2xbMF0udG9VcHBlckNhc2UoKSArIGNvbC5zbGljZSgxKTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0xhYmVscycsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMsXG4gICAgICAgICAgICAgICAgICAgIHJvd3MsXG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgZm9yIChsZXQgX2QyIG9mIGNvbmZpZy5jb25maWdbX2RdKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhYmxlcy5wdXNoKC4uLnRoaXMuZ2V0Q29uZmlnVGFibGVzKF9kMiwgc2VjdGlvbiwgaWR4KSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8qSU5URUdSSVRZIE1PTklUT1JJTkcgTU9OSVRPUkVEIERJUkVDVE9SSUVTICovXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5jb25maWdbX2RdLmRpcmVjdG9yaWVzKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBkaXJlY3RvcmllcyA9IGNvbmZpZy5jb25maWdbX2RdLmRpcmVjdG9yaWVzO1xuICAgICAgICAgICAgICAgICAgZGVsZXRlIGNvbmZpZy5jb25maWdbX2RdLmRpcmVjdG9yaWVzO1xuICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goLi4udGhpcy5nZXRDb25maWdUYWJsZXMoY29uZmlnLmNvbmZpZ1tfZF0sIHNlY3Rpb24sIGlkeCkpO1xuICAgICAgICAgICAgICAgICAgbGV0IGRpZmZPcHRzID0gW107XG4gICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyhzZWN0aW9uLm9wdHMpLmZvckVhY2goKHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZGlmZk9wdHMucHVzaCh4KTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgY29uc3QgY29sdW1ucyA9IFtcbiAgICAgICAgICAgICAgICAgICAgJycsXG4gICAgICAgICAgICAgICAgICAgIC4uLmRpZmZPcHRzLmZpbHRlcigoeCkgPT4geCAhPT0gJ2NoZWNrX2FsbCcgJiYgeCAhPT0gJ2NoZWNrX3N1bScpLFxuICAgICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgICAgICAgIGxldCByb3dzID0gW107XG4gICAgICAgICAgICAgICAgICBkaXJlY3Rvcmllcy5mb3JFYWNoKCh4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGxldCByb3cgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goeC5wYXRoKTtcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKCh5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHkgIT09ICcnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB5ID0geSAhPT0gJ2NoZWNrX3dob2RhdGEnID8geSA6ICd3aG9kYXRhJztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKHhbeV0gPyB4W3ldIDogJ25vJyk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goeC5yZWN1cnNpb25fbGV2ZWwpO1xuICAgICAgICAgICAgICAgICAgICByb3dzLnB1c2gocm93KTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKCh4LCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpZHhdID0gc2VjdGlvbi5vcHRzW3hdO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICBjb2x1bW5zLnB1c2goJ1JMJyk7XG4gICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnTW9uaXRvcmVkIGRpcmVjdG9yaWVzJyxcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucyxcbiAgICAgICAgICAgICAgICAgICAgcm93cyxcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCguLi50aGlzLmdldENvbmZpZ1RhYmxlcyhjb25maWcuY29uZmlnW19kXSwgc2VjdGlvbiwgaWR4KSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGZvciAoY29uc3QgdGFibGUgb2YgdGFibGVzKSB7XG4gICAgICAgICAgICAgICAgcHJpbnRlci5hZGRDb25maWdUYWJsZXMoW3RhYmxlXSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWR4Kys7XG4gICAgICAgICAgICAgIHRhYmxlcyA9IFtdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGFibGVzID0gW107XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiAnQSBjb25maWd1cmF0aW9uIGZvciB0aGlzIGdyb3VwIGhhcyBub3QgeWV0IGJlZW4gc2V0IHVwLicsXG4gICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMTIsIGNvbG9yOiAnIzAwMCcgfSxcbiAgICAgICAgICAgIG1hcmdpbjogWzAsIDEwLCAwLCAxNV0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChjb21wb25lbnRzWycxJ10pIHtcbiAgICAgICAgbGV0IGFnZW50c0luR3JvdXAgPSBbXTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBhZ2VudHNJbkdyb3VwUmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICBgL2dyb3Vwcy8ke2dyb3VwSUR9L2FnZW50c2AsXG4gICAgICAgICAgICB7fSxcbiAgICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XG4gICAgICAgICAgKTtcbiAgICAgICAgICBhZ2VudHNJbkdyb3VwID0gYWdlbnRzSW5Hcm91cFJlc3BvbnNlLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtcztcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBsb2coJ3JlcG9ydGluZzpyZXBvcnQnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAnZGVidWcnKTtcbiAgICAgICAgfVxuICAgICAgICBhd2FpdCB0aGlzLnJlbmRlckhlYWRlcihcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIHByaW50ZXIsXG4gICAgICAgICAgJ2dyb3VwQ29uZmlnJyxcbiAgICAgICAgICBncm91cElELFxuICAgICAgICAgIChhZ2VudHNJbkdyb3VwIHx8IFtdKS5tYXAoKHgpID0+IHguaWQpLFxuICAgICAgICAgIGFwaUlkXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGF3YWl0IHByaW50ZXIucHJpbnQocGF0aC5qb2luKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsIHVzZXJJRCwgbmFtZSkpO1xuXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICBtZXNzYWdlOiBgUmVwb3J0ICR7bmFtZX0gd2FzIGNyZWF0ZWRgLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNHcm91cHMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDUwMjksIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSByZXBvcnQgZm9yIHRoZSBhZ2VudHNcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHsqfSByZXBvcnRzIGxpc3Qgb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgY3JlYXRlUmVwb3J0c0FnZW50cyhcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeVxuICApIHtcbiAgICB0cnkge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50cycsIGBSZXBvcnQgc3RhcnRlZGAsICdpbmZvJyk7XG4gICAgICBjb25zdCB7IG5hbWUsIGNvbXBvbmVudHMsIGFwaUlkIH0gPSByZXF1ZXN0LmJvZHk7XG4gICAgICBjb25zdCB7IGFnZW50SUQgfSA9IHJlcXVlc3QucGFyYW1zO1xuXG4gICAgICBjb25zdCBwcmludGVyID0gbmV3IFJlcG9ydFByaW50ZXIoKTtcblxuICAgICAgY29uc3QgeyB1c2VybmFtZTogdXNlcklEIH0gPSBhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpO1xuICAgICAgY3JlYXRlRGF0YURpcmVjdG9yeUlmTm90RXhpc3RzKCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19ESVJFQ1RPUllfUEFUSCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRIKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKHBhdGguam9pbihXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRILCB1c2VySUQpKTtcblxuICAgICAgbGV0IHdtb2R1bGVzUmVzcG9uc2UgPSB7fTtcbiAgICAgIGxldCB0YWJsZXMgPSBbXTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHdtb2R1bGVzUmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAgICdHRVQnLFxuICAgICAgICAgIGAvYWdlbnRzLyR7YWdlbnRJRH0vY29uZmlnL3dtb2R1bGVzL3dtb2R1bGVzYCxcbiAgICAgICAgICB7fSxcbiAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxuICAgICAgICApO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6cmVwb3J0JywgZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgJ2RlYnVnJyk7XG4gICAgICB9XG5cbiAgICAgIGF3YWl0IHRoaXMucmVuZGVySGVhZGVyKGNvbnRleHQsIHByaW50ZXIsICdhZ2VudENvbmZpZycsICdhZ2VudENvbmZpZycsIGFnZW50SUQsIGFwaUlkKTtcblxuICAgICAgbGV0IGlkeENvbXBvbmVudCA9IDA7XG4gICAgICBmb3IgKGxldCBjb25maWcgb2YgQWdlbnRDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zKSB7XG4gICAgICAgIGxldCB0aXRsZU9mU2VjdGlvbiA9IGZhbHNlO1xuICAgICAgICBsb2coXG4gICAgICAgICAgJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzQWdlbnRzJyxcbiAgICAgICAgICBgSXRlcmF0ZSBvdmVyICR7Y29uZmlnLnNlY3Rpb25zLmxlbmd0aH0gY29uZmlndXJhdGlvbiBzZWN0aW9uc2AsXG4gICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICApO1xuICAgICAgICBmb3IgKGxldCBzZWN0aW9uIG9mIGNvbmZpZy5zZWN0aW9ucykge1xuICAgICAgICAgIGxldCB0aXRsZU9mU3Vic2VjdGlvbiA9IGZhbHNlO1xuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgIGNvbXBvbmVudHNbaWR4Q29tcG9uZW50XSAmJlxuICAgICAgICAgICAgKHNlY3Rpb24uY29uZmlnIHx8IHNlY3Rpb24ud29kbGUpXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICBsZXQgaWR4ID0gMDtcbiAgICAgICAgICAgIGNvbnN0IGNvbmZpZ3MgPSAoc2VjdGlvbi5jb25maWcgfHwgW10pLmNvbmNhdChzZWN0aW9uLndvZGxlIHx8IFtdKTtcbiAgICAgICAgICAgIGxvZyhcbiAgICAgICAgICAgICAgJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzQWdlbnRzJyxcbiAgICAgICAgICAgICAgYEl0ZXJhdGUgb3ZlciAke2NvbmZpZ3MubGVuZ3RofSBjb25maWd1cmF0aW9uIGJsb2Nrc2AsXG4gICAgICAgICAgICAgICdkZWJ1ZydcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBmb3IgKGxldCBjb25mIG9mIGNvbmZpZ3MpIHtcbiAgICAgICAgICAgICAgbGV0IGFnZW50Q29uZmlnUmVzcG9uc2UgPSB7fTtcbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBpZiAoIWNvbmZbJ25hbWUnXSkge1xuICAgICAgICAgICAgICAgICAgYWdlbnRDb25maWdSZXNwb25zZSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgICAgICAgICAgICdHRVQnLFxuICAgICAgICAgICAgICAgICAgICBgL2FnZW50cy8ke2FnZW50SUR9L2NvbmZpZy8ke2NvbmYuY29tcG9uZW50fS8ke2NvbmYuY29uZmlndXJhdGlvbn1gLFxuICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IGFwaUlkIH1cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIGZvciAobGV0IHdvZGxlIG9mIHdtb2R1bGVzUmVzcG9uc2UuZGF0YS5kYXRhWyd3bW9kdWxlcyddKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChPYmplY3Qua2V5cyh3b2RsZSlbMF0gPT09IGNvbmZbJ25hbWUnXSkge1xuICAgICAgICAgICAgICAgICAgICAgIGFnZW50Q29uZmlnUmVzcG9uc2UuZGF0YSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHdvZGxlLFxuICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBjb25zdCBhZ2VudENvbmZpZyA9XG4gICAgICAgICAgICAgICAgICBhZ2VudENvbmZpZ1Jlc3BvbnNlICYmIGFnZW50Q29uZmlnUmVzcG9uc2UuZGF0YSAmJiBhZ2VudENvbmZpZ1Jlc3BvbnNlLmRhdGEuZGF0YTtcbiAgICAgICAgICAgICAgICBpZiAoIXRpdGxlT2ZTZWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICAgICAgICB0ZXh0OiBjb25maWcudGl0bGUsXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlOiAnaDEnLFxuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IFswLCAwLCAwLCAxNV0sXG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIHRpdGxlT2ZTZWN0aW9uID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCF0aXRsZU9mU3Vic2VjdGlvbikge1xuICAgICAgICAgICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogc2VjdGlvbi5zdWJ0aXRsZSxcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU6ICdoNCcsXG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IHNlY3Rpb24uZGVzYyxcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU6IHsgZm9udFNpemU6IDEyLCBjb2xvcjogJyMwMDAnIH0sXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogWzAsIDAsIDAsIDEwXSxcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgdGl0bGVPZlN1YnNlY3Rpb24gPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoYWdlbnRDb25maWcpIHtcbiAgICAgICAgICAgICAgICAgIGZvciAobGV0IGFnZW50Q29uZmlnS2V5IG9mIE9iamVjdC5rZXlzKGFnZW50Q29uZmlnKSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgLyogTE9HIENPTExFQ1RPUiAqL1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChjb25mLmZpbHRlckJ5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZ3JvdXBzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICBhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV0uZm9yRWFjaCgob2JqKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZ3JvdXBzW29iai5sb2dmb3JtYXRdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW29iai5sb2dmb3JtYXRdID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW29iai5sb2dmb3JtYXRdLnB1c2gob2JqKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXMoZ3JvdXBzKS5mb3JFYWNoKChncm91cCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgc2F2ZWlkeCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3Vwc1tncm91cF0uZm9yRWFjaCgoeCwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKHgpLmxlbmd0aCA+IE9iamVjdC5rZXlzKGdyb3Vwc1tncm91cF1bc2F2ZWlkeF0pLmxlbmd0aFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2F2ZWlkeCA9IGk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY29sdW1ucyA9IE9iamVjdC5rZXlzKGdyb3Vwc1tncm91cF1bc2F2ZWlkeF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByb3dzID0gZ3JvdXBzW2dyb3VwXS5tYXAoKHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcm93ID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlb2YgeFtrZXldICE9PSAnb2JqZWN0J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8geFtrZXldXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBBcnJheS5pc0FycmF5KHhba2V5XSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHhba2V5XS5tYXAoKHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHggKyAnXFxuJztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBKU09OLnN0cmluZ2lmeSh4W2tleV0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByb3c7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goKGNvbCwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnNbaV0gPSBjb2xbMF0udG9VcHBlckNhc2UoKSArIGNvbC5zbGljZSgxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRhYmxlcy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogc2VjdGlvbi5sYWJlbHNbMF1bZ3JvdXBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoYWdlbnRDb25maWdLZXkuY29uZmlndXJhdGlvbiAhPT0gJ3NvY2tldCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhYmxlcy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi50aGlzLmdldENvbmZpZ1RhYmxlcyhhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV0sIHNlY3Rpb24sIGlkeClcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IF9kMiBvZiBhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goLi4udGhpcy5nZXRDb25maWdUYWJsZXMoX2QyLCBzZWN0aW9uLCBpZHgpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgLypJTlRFR1JJVFkgTU9OSVRPUklORyBNT05JVE9SRUQgRElSRUNUT1JJRVMgKi9cbiAgICAgICAgICAgICAgICAgICAgICBpZiAoY29uZi5tYXRyaXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHtkaXJlY3RvcmllcyxkaWZmLHN5bmNocm9uaXphdGlvbixmaWxlX2xpbWl0LC4uLnJlc3R9ID0gYWdlbnRDb25maWdbYWdlbnRDb25maWdLZXldO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnRoaXMuZ2V0Q29uZmlnVGFibGVzKHJlc3QsIHNlY3Rpb24sIGlkeCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLihkaWZmICYmIGRpZmYuZGlza19xdW90YSA/IHRoaXMuZ2V0Q29uZmlnVGFibGVzKGRpZmYuZGlza19xdW90YSwge3RhYnM6WydEaXNrIHF1b3RhJ119LCAwICk6IFtdKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKGRpZmYgJiYgZGlmZi5maWxlX3NpemUgPyB0aGlzLmdldENvbmZpZ1RhYmxlcyhkaWZmLmZpbGVfc2l6ZSwge3RhYnM6WydGaWxlIHNpemUnXX0sIDAgKTogW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oc3luY2hyb25pemF0aW9uID8gdGhpcy5nZXRDb25maWdUYWJsZXMoc3luY2hyb25pemF0aW9uLCB7dGFiczpbJ1N5bmNocm9uaXphdGlvbiddfSwgMCApOiBbXSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLihmaWxlX2xpbWl0ID8gdGhpcy5nZXRDb25maWdUYWJsZXMoZmlsZV9saW1pdCwge3RhYnM6WydGaWxlIGxpbWl0J119LCAwICk6IFtdKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGlmZk9wdHMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKHNlY3Rpb24ub3B0cykuZm9yRWFjaCgoeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBkaWZmT3B0cy5wdXNoKHgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2x1bW5zID0gW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZGlmZk9wdHMuZmlsdGVyKCh4KSA9PiB4ICE9PSAnY2hlY2tfYWxsJyAmJiB4ICE9PSAnY2hlY2tfc3VtJyksXG4gICAgICAgICAgICAgICAgICAgICAgICBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJvd3MgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpcmVjdG9yaWVzLmZvckVhY2goKHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJvdyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaCh4LmRpcik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoeSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh5ICE9PSAnJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goeC5vcHRzLmluZGV4T2YoeSkgPiAtMSA/ICd5ZXMnIDogJ25vJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goeC5yZWN1cnNpb25fbGV2ZWwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzLnB1c2gocm93KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKCh4LCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpZHhdID0gc2VjdGlvbi5vcHRzW3hdO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLnB1c2goJ1JMJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnTW9uaXRvcmVkIGRpcmVjdG9yaWVzJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udGhpcy5nZXRDb25maWdUYWJsZXMoYWdlbnRDb25maWdbYWdlbnRDb25maWdLZXldLCBzZWN0aW9uLCBpZHgpXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAvLyBQcmludCBubyBjb25maWd1cmVkIG1vZHVsZSBhbmQgbGluayB0byB0aGUgZG9jdW1lbnRhdGlvblxuICAgICAgICAgICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogW1xuICAgICAgICAgICAgICAgICAgICAgICdUaGlzIG1vZHVsZSBpcyBub3QgY29uZmlndXJlZC4gUGxlYXNlIHRha2UgYSBsb29rIG9uIGhvdyB0byBjb25maWd1cmUgaXQgaW4gJyxcbiAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiBgJHtzZWN0aW9uLnN1YnRpdGxlLnRvTG93ZXJDYXNlKCl9IGNvbmZpZ3VyYXRpb24uYCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpbms6IHNlY3Rpb24uZG9jdUxpbmssXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMTIsIGNvbG9yOiAnIzFhMGRhYicgfSxcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IFswLCAwLCAwLCAyMF0sXG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgbG9nKCdyZXBvcnRpbmc6cmVwb3J0JywgZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgJ2RlYnVnJyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWR4Kys7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHRhYmxlIG9mIHRhYmxlcykge1xuICAgICAgICAgICAgICBwcmludGVyLmFkZENvbmZpZ1RhYmxlcyhbdGFibGVdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgaWR4Q29tcG9uZW50Kys7XG4gICAgICAgICAgdGFibGVzID0gW107XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgYXdhaXQgcHJpbnRlci5wcmludChwYXRoLmpvaW4oV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCwgdXNlcklELCBuYW1lKSk7XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIG1lc3NhZ2U6IGBSZXBvcnQgJHtuYW1lfSB3YXMgY3JlYXRlZGAsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50cycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAyOSwgNTAwLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIHJlcG9ydCBmb3IgdGhlIGFnZW50c1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMgeyp9IHJlcG9ydHMgbGlzdCBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBjcmVhdGVSZXBvcnRzQWdlbnRzSW52ZW50b3J5KFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XG4gICkge1xuICAgIHRyeSB7XG4gICAgICBsb2coJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzQWdlbnRzSW52ZW50b3J5JywgYFJlcG9ydCBzdGFydGVkYCwgJ2luZm8nKTtcbiAgICAgIGNvbnN0IHsgc2VhcmNoQmFyLCBmaWx0ZXJzLCB0aW1lLCBuYW1lLCBpbmRleFBhdHRlcm5UaXRsZSwgYXBpSWQgfSA9IHJlcXVlc3QuYm9keTtcbiAgICAgIGNvbnN0IHsgYWdlbnRJRCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICBjb25zdCB7IGZyb20sIHRvIH0gPSB0aW1lIHx8IHt9O1xuICAgICAgLy8gSW5pdFxuICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKCk7XG5cbiAgICAgIGNvbnN0IHsgdXNlcm5hbWU6IHVzZXJJRCB9ID0gYXdhaXQgY29udGV4dC53YXp1aC5zZWN1cml0eS5nZXRDdXJyZW50VXNlcihyZXF1ZXN0LCBjb250ZXh0KTtcbiAgICAgIGNyZWF0ZURhdGFEaXJlY3RvcnlJZk5vdEV4aXN0cygpO1xuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMoV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEgpO1xuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMoV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhwYXRoLmpvaW4oV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCwgdXNlcklEKSk7XG5cbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNBZ2VudHNJbnZlbnRvcnknLCBgU3lzY29sbGVjdG9yIHJlcG9ydGAsICdkZWJ1ZycpO1xuICAgICAgY29uc3Qgc2FuaXRpemVkRmlsdGVycyA9IGZpbHRlcnMgPyB0aGlzLnNhbml0aXplS2liYW5hRmlsdGVycyhmaWx0ZXJzLCBzZWFyY2hCYXIpIDogZmFsc2U7XG5cbiAgICAgIC8vIEdldCB0aGUgYWdlbnQgT1NcbiAgICAgIGxldCBhZ2VudE9zID0gJyc7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBhZ2VudFJlc3BvbnNlID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcbiAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICAnL2FnZW50cycsXG4gICAgICAgICAgeyBwYXJhbXM6IHsgcTogYGlkPSR7YWdlbnRJRH1gIH0gfSxcbiAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxuICAgICAgICApO1xuICAgICAgICBhZ2VudE9zID0gYWdlbnRSZXNwb25zZS5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0ub3MucGxhdGZvcm07XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBsb2coJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzQWdlbnRzSW52ZW50b3J5JywgZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgJ2RlYnVnJyk7XG4gICAgICB9XG5cbiAgICAgIC8vIEFkZCB0aXRsZVxuICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xuICAgICAgICB0ZXh0OiAnSW52ZW50b3J5IGRhdGEgcmVwb3J0JyxcbiAgICAgICAgc3R5bGU6ICdoMScsXG4gICAgICB9KTtcblxuICAgICAgLy8gQWRkIHRhYmxlIHdpdGggdGhlIGFnZW50IGluZm9cbiAgICAgIGF3YWl0IHRoaXMuYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBbYWdlbnRJRF0sIGFwaUlkKTtcblxuICAgICAgLy8gR2V0IHN5c2NvbGxlY3RvciBwYWNrYWdlcyBhbmQgcHJvY2Vzc2VzXG4gICAgICBjb25zdCBhZ2VudFJlcXVlc3RzSW52ZW50b3J5ID0gW1xuICAgICAgICB7XG4gICAgICAgICAgZW5kcG9pbnQ6IGAvc3lzY29sbGVjdG9yLyR7YWdlbnRJRH0vcGFja2FnZXNgLFxuICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBwYWNrYWdlcyBmb3IgYWdlbnQgJHthZ2VudElEfWAsXG4gICAgICAgICAgdGFibGU6IHtcbiAgICAgICAgICAgIHRpdGxlOiAnUGFja2FnZXMnLFxuICAgICAgICAgICAgY29sdW1uczpcbiAgICAgICAgICAgICAgYWdlbnRPcyA9PT0gJ3dpbmRvd3MnXG4gICAgICAgICAgICAgICAgPyBbXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICduYW1lJywgbGFiZWw6ICdOYW1lJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnYXJjaGl0ZWN0dXJlJywgbGFiZWw6ICdBcmNoaXRlY3R1cmUnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICd2ZXJzaW9uJywgbGFiZWw6ICdWZXJzaW9uJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAndmVuZG9yJywgbGFiZWw6ICdWZW5kb3InIH0sXG4gICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICduYW1lJywgbGFiZWw6ICdOYW1lJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnYXJjaGl0ZWN0dXJlJywgbGFiZWw6ICdBcmNoaXRlY3R1cmUnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICd2ZXJzaW9uJywgbGFiZWw6ICdWZXJzaW9uJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAndmVuZG9yJywgbGFiZWw6ICdWZW5kb3InIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdkZXNjcmlwdGlvbicsIGxhYmVsOiAnRGVzY3JpcHRpb24nIH0sXG4gICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBlbmRwb2ludDogYC9zeXNjb2xsZWN0b3IvJHthZ2VudElEfS9wcm9jZXNzZXNgLFxuICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBwcm9jZXNzZXMgZm9yIGFnZW50ICR7YWdlbnRJRH1gLFxuICAgICAgICAgIHRhYmxlOiB7XG4gICAgICAgICAgICB0aXRsZTogJ1Byb2Nlc3NlcycsXG4gICAgICAgICAgICBjb2x1bW5zOlxuICAgICAgICAgICAgICBhZ2VudE9zID09PSAnd2luZG93cydcbiAgICAgICAgICAgICAgICA/IFtcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ25hbWUnLCBsYWJlbDogJ05hbWUnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdjbWQnLCBsYWJlbDogJ0NNRCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3ByaW9yaXR5JywgbGFiZWw6ICdQcmlvcml0eScgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ25sd3AnLCBsYWJlbDogJ05MV1AnIH0sXG4gICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICduYW1lJywgbGFiZWw6ICdOYW1lJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnZXVzZXInLCBsYWJlbDogJ0VmZmVjdGl2ZSB1c2VyJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbmljZScsIGxhYmVsOiAnUHJpb3JpdHknIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdzdGF0ZScsIGxhYmVsOiAnU3RhdGUnIH0sXG4gICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgbWFwUmVzcG9uc2VJdGVtczogKGl0ZW0pID0+XG4gICAgICAgICAgICBhZ2VudE9zID09PSAnd2luZG93cycgPyBpdGVtIDogeyAuLi5pdGVtLCBzdGF0ZTogUHJvY2Vzc0VxdWl2YWxlbmNlW2l0ZW0uc3RhdGVdIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBlbmRwb2ludDogYC9zeXNjb2xsZWN0b3IvJHthZ2VudElEfS9wb3J0c2AsXG4gICAgICAgICAgbG9nZ2VyTWVzc2FnZTogYEZldGNoaW5nIHBvcnRzIGZvciBhZ2VudCAke2FnZW50SUR9YCxcbiAgICAgICAgICB0YWJsZToge1xuICAgICAgICAgICAgdGl0bGU6ICdOZXR3b3JrIHBvcnRzJyxcbiAgICAgICAgICAgIGNvbHVtbnM6XG4gICAgICAgICAgICAgIGFnZW50T3MgPT09ICd3aW5kb3dzJ1xuICAgICAgICAgICAgICAgID8gW1xuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbG9jYWxfaXAnLCBsYWJlbDogJ0xvY2FsIElQJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbG9jYWxfcG9ydCcsIGxhYmVsOiAnTG9jYWwgcG9ydCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3Byb2Nlc3MnLCBsYWJlbDogJ1Byb2Nlc3MnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdzdGF0ZScsIGxhYmVsOiAnU3RhdGUnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdwcm90b2NvbCcsIGxhYmVsOiAnUHJvdG9jb2wnIH0sXG4gICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdsb2NhbF9pcCcsIGxhYmVsOiAnTG9jYWwgSVAnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdsb2NhbF9wb3J0JywgbGFiZWw6ICdMb2NhbCBwb3J0JyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnc3RhdGUnLCBsYWJlbDogJ1N0YXRlJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAncHJvdG9jb2wnLCBsYWJlbDogJ1Byb3RvY29sJyB9LFxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIG1hcFJlc3BvbnNlSXRlbXM6IChpdGVtKSA9PiAoe1xuICAgICAgICAgICAgLi4uaXRlbSxcbiAgICAgICAgICAgIGxvY2FsX2lwOiBpdGVtLmxvY2FsLmlwLFxuICAgICAgICAgICAgbG9jYWxfcG9ydDogaXRlbS5sb2NhbC5wb3J0LFxuICAgICAgICAgIH0pLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgZW5kcG9pbnQ6IGAvc3lzY29sbGVjdG9yLyR7YWdlbnRJRH0vbmV0aWZhY2VgLFxuICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBuZXRpZmFjZSBmb3IgYWdlbnQgJHthZ2VudElEfWAsXG4gICAgICAgICAgdGFibGU6IHtcbiAgICAgICAgICAgIHRpdGxlOiAnTmV0d29yayBpbnRlcmZhY2VzJyxcbiAgICAgICAgICAgIGNvbHVtbnM6IFtcbiAgICAgICAgICAgICAgeyBpZDogJ25hbWUnLCBsYWJlbDogJ05hbWUnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdtYWMnLCBsYWJlbDogJ01hYycgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ3N0YXRlJywgbGFiZWw6ICdTdGF0ZScgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ210dScsIGxhYmVsOiAnTVRVJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAndHlwZScsIGxhYmVsOiAnVHlwZScgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGVuZHBvaW50OiBgL3N5c2NvbGxlY3Rvci8ke2FnZW50SUR9L25ldGFkZHJgLFxuICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBuZXRhZGRyIGZvciBhZ2VudCAke2FnZW50SUR9YCxcbiAgICAgICAgICB0YWJsZToge1xuICAgICAgICAgICAgdGl0bGU6ICdOZXR3b3JrIHNldHRpbmdzJyxcbiAgICAgICAgICAgIGNvbHVtbnM6IFtcbiAgICAgICAgICAgICAgeyBpZDogJ2lmYWNlJywgbGFiZWw6ICdJbnRlcmZhY2UnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdhZGRyZXNzJywgbGFiZWw6ICdhZGRyZXNzJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnbmV0bWFzaycsIGxhYmVsOiAnTmV0bWFzaycgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ3Byb3RvJywgbGFiZWw6ICdQcm90b2NvbCcgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ2Jyb2FkY2FzdCcsIGxhYmVsOiAnQnJvYWRjYXN0JyB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgXTtcblxuICAgICAgYWdlbnRPcyA9PT0gJ3dpbmRvd3MnICYmXG4gICAgICAgIGFnZW50UmVxdWVzdHNJbnZlbnRvcnkucHVzaCh7XG4gICAgICAgICAgZW5kcG9pbnQ6IGAvc3lzY29sbGVjdG9yLyR7YWdlbnRJRH0vaG90Zml4ZXNgLFxuICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBob3RmaXhlcyBmb3IgYWdlbnQgJHthZ2VudElEfWAsXG4gICAgICAgICAgdGFibGU6IHtcbiAgICAgICAgICAgIHRpdGxlOiAnV2luZG93cyB1cGRhdGVzJyxcbiAgICAgICAgICAgIGNvbHVtbnM6IFt7IGlkOiAnaG90Zml4JywgbGFiZWw6ICdVcGRhdGUgY29kZScgfV0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IHJlcXVlc3RJbnZlbnRvcnkgPSBhc3luYyAoYWdlbnRSZXF1ZXN0SW52ZW50b3J5KSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbG9nKFxuICAgICAgICAgICAgJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzQWdlbnRzSW52ZW50b3J5JyxcbiAgICAgICAgICAgIGFnZW50UmVxdWVzdEludmVudG9yeS5sb2dnZXJNZXNzYWdlLFxuICAgICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICAgICk7XG5cbiAgICAgICAgICBjb25zdCBpbnZlbnRvcnlSZXNwb25zZSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICAgIGFnZW50UmVxdWVzdEludmVudG9yeS5lbmRwb2ludCxcbiAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IGFwaUlkIH1cbiAgICAgICAgICApO1xuXG4gICAgICAgICAgY29uc3QgaW52ZW50b3J5ID1cbiAgICAgICAgICAgIGludmVudG9yeVJlc3BvbnNlICYmXG4gICAgICAgICAgICBpbnZlbnRvcnlSZXNwb25zZS5kYXRhICYmXG4gICAgICAgICAgICBpbnZlbnRvcnlSZXNwb25zZS5kYXRhLmRhdGEgJiZcbiAgICAgICAgICAgIGludmVudG9yeVJlc3BvbnNlLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtcztcbiAgICAgICAgICBpZiAoaW52ZW50b3J5KSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAuLi5hZ2VudFJlcXVlc3RJbnZlbnRvcnkudGFibGUsXG4gICAgICAgICAgICAgIGl0ZW1zOiBhZ2VudFJlcXVlc3RJbnZlbnRvcnkubWFwUmVzcG9uc2VJdGVtc1xuICAgICAgICAgICAgICAgID8gaW52ZW50b3J5Lm1hcChhZ2VudFJlcXVlc3RJbnZlbnRvcnkubWFwUmVzcG9uc2VJdGVtcylcbiAgICAgICAgICAgICAgICA6IGludmVudG9yeSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNBZ2VudHNJbnZlbnRvcnknLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAnZGVidWcnKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgaWYgKHRpbWUpIHtcbiAgICAgICAgYXdhaXQgdGhpcy5leHRlbmRlZEluZm9ybWF0aW9uKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgcHJpbnRlcixcbiAgICAgICAgICAnYWdlbnRzJyxcbiAgICAgICAgICAnc3lzY29sbGVjdG9yJyxcbiAgICAgICAgICBhcGlJZCxcbiAgICAgICAgICBmcm9tLFxuICAgICAgICAgIHRvLFxuICAgICAgICAgIHNhbml0aXplZEZpbHRlcnMgKyAnIEFORCBydWxlLmdyb3VwczogXCJ2dWxuZXJhYmlsaXR5LWRldGVjdG9yXCInLFxuICAgICAgICAgIGluZGV4UGF0dGVyblRpdGxlLFxuICAgICAgICAgIGFnZW50SURcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgLy8gQWRkIGludmVudG9yeSB0YWJsZXNcbiAgICAgIChhd2FpdCBQcm9taXNlLmFsbChhZ2VudFJlcXVlc3RzSW52ZW50b3J5Lm1hcChyZXF1ZXN0SW52ZW50b3J5KSkpXG4gICAgICAgIC5maWx0ZXIoKHRhYmxlKSA9PiB0YWJsZSlcbiAgICAgICAgLmZvckVhY2goKHRhYmxlKSA9PiBwcmludGVyLmFkZFNpbXBsZVRhYmxlKHRhYmxlKSk7XG5cbiAgICAgIC8vIFByaW50IHRoZSBkb2N1bWVudFxuICAgICAgYXdhaXQgcHJpbnRlci5wcmludChwYXRoLmpvaW4oV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCwgdXNlcklELCBuYW1lKSk7XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIG1lc3NhZ2U6IGBSZXBvcnQgJHtuYW1lfSB3YXMgY3JlYXRlZGAsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50cycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAyOSwgNTAwLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEZldGNoIHRoZSByZXBvcnRzIGxpc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtBcnJheTxPYmplY3Q+fSByZXBvcnRzIGxpc3Qgb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgZ2V0UmVwb3J0cyhcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogT3BlblNlYXJjaERhc2hib2FyZHNSZXF1ZXN0LFxuICAgIHJlc3BvbnNlOiBPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlRmFjdG9yeVxuICApIHtcbiAgICB0cnkge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Z2V0UmVwb3J0cycsIGBGZXRjaGluZyBjcmVhdGVkIHJlcG9ydHNgLCAnaW5mbycpO1xuICAgICAgY29uc3QgeyB1c2VybmFtZTogdXNlcklEIH0gPSBhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpO1xuICAgICAgY3JlYXRlRGF0YURpcmVjdG9yeUlmTm90RXhpc3RzKCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19ESVJFQ1RPUllfUEFUSCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRIKTtcbiAgICAgIGNvbnN0IHVzZXJSZXBvcnRzRGlyZWN0b3J5ID0gcGF0aC5qb2luKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsIHVzZXJJRCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyh1c2VyUmVwb3J0c0RpcmVjdG9yeSk7XG4gICAgICBsb2coJ3JlcG9ydGluZzpnZXRSZXBvcnRzJywgYERpcmVjdG9yeTogJHt1c2VyUmVwb3J0c0RpcmVjdG9yeX1gLCAnZGVidWcnKTtcblxuICAgICAgY29uc3Qgc29ydFJlcG9ydHNCeURhdGUgPSAoYSwgYikgPT4gKGEuZGF0ZSA8IGIuZGF0ZSA/IDEgOiBhLmRhdGUgPiBiLmRhdGUgPyAtMSA6IDApO1xuXG4gICAgICBjb25zdCByZXBvcnRzID0gZnMucmVhZGRpclN5bmModXNlclJlcG9ydHNEaXJlY3RvcnkpLm1hcCgoZmlsZSkgPT4ge1xuICAgICAgICBjb25zdCBzdGF0cyA9IGZzLnN0YXRTeW5jKHVzZXJSZXBvcnRzRGlyZWN0b3J5ICsgJy8nICsgZmlsZSk7XG4gICAgICAgIC8vIEdldCB0aGUgZmlsZSBjcmVhdGlvbiB0aW1lIChiaXRodGltZSkuIEl0IHJldHVybnMgdGhlIGZpcnN0IHZhbHVlIHRoYXQgaXMgYSB0cnV0aHkgdmFsdWUgb2YgbmV4dCBmaWxlIHN0YXRzOiBiaXJ0aHRpbWUsIG10aW1lLCBjdGltZSBhbmQgYXRpbWUuXG4gICAgICAgIC8vIFRoaXMgc29sdmVzIHNvbWUgT1NzIGNhbiBoYXZlIHRoZSBiaXRodGltZU1zIGVxdWFsIHRvIDAgYW5kIHJldHVybnMgdGhlIGRhdGUgbGlrZSAxOTcwLTAxLTAxXG4gICAgICAgIGNvbnN0IGJpcnRoVGltZUZpZWxkID0gWydiaXJ0aHRpbWUnLCAnbXRpbWUnLCAnY3RpbWUnLCAnYXRpbWUnXS5maW5kKFxuICAgICAgICAgICh0aW1lKSA9PiBzdGF0c1tgJHt0aW1lfU1zYF1cbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBuYW1lOiBmaWxlLFxuICAgICAgICAgIHNpemU6IHN0YXRzLnNpemUsXG4gICAgICAgICAgZGF0ZTogc3RhdHNbYmlydGhUaW1lRmllbGRdLFxuICAgICAgICB9O1xuICAgICAgfSk7XG4gICAgICBsb2coJ3JlcG9ydGluZzpnZXRSZXBvcnRzJywgYFVzaW5nIFRpbVNvcnQgZm9yIHNvcnRpbmcgJHtyZXBvcnRzLmxlbmd0aH0gaXRlbXNgLCAnZGVidWcnKTtcbiAgICAgIFRpbVNvcnQuc29ydChyZXBvcnRzLCBzb3J0UmVwb3J0c0J5RGF0ZSk7XG4gICAgICBsb2coJ3JlcG9ydGluZzpnZXRSZXBvcnRzJywgYFRvdGFsIHJlcG9ydHM6ICR7cmVwb3J0cy5sZW5ndGh9YCwgJ2RlYnVnJyk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7IHJlcG9ydHMgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coJ3JlcG9ydGluZzpnZXRSZXBvcnRzJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA1MDMxLCA1MDAsIHJlc3BvbnNlKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRmV0Y2ggc3BlY2lmaWMgcmVwb3J0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSByZXBvcnQgb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgZ2V0UmVwb3J0QnlOYW1lKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XG4gICkge1xuICAgIHRyeSB7XG4gICAgICBsb2coJ3JlcG9ydGluZzpnZXRSZXBvcnRCeU5hbWUnLCBgR2V0dGluZyAke3JlcXVlc3QucGFyYW1zLm5hbWV9IHJlcG9ydGAsICdkZWJ1ZycpO1xuICAgICAgY29uc3QgeyB1c2VybmFtZTogdXNlcklEIH0gPSBhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpO1xuICAgICAgY29uc3QgcmVwb3J0RmlsZUJ1ZmZlciA9IGZzLnJlYWRGaWxlU3luYyhcbiAgICAgICAgcGF0aC5qb2luKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsIHVzZXJJRCwgcmVxdWVzdC5wYXJhbXMubmFtZSlcbiAgICAgICk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vcGRmJyB9LFxuICAgICAgICBib2R5OiByZXBvcnRGaWxlQnVmZmVyLFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygncmVwb3J0aW5nOmdldFJlcG9ydEJ5TmFtZScsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAzMCwgNTAwLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIERlbGV0ZSBzcGVjaWZpYyByZXBvcnRcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IHN0YXR1cyBvYmogb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgZGVsZXRlUmVwb3J0QnlOYW1lKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBPcGVuU2VhcmNoRGFzaGJvYXJkc1JlcXVlc3QsXG4gICAgcmVzcG9uc2U6IE9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2VGYWN0b3J5XG4gICkge1xuICAgIHRyeSB7XG4gICAgICBsb2coJ3JlcG9ydGluZzpkZWxldGVSZXBvcnRCeU5hbWUnLCBgRGVsZXRpbmcgJHtyZXF1ZXN0LnBhcmFtcy5uYW1lfSByZXBvcnRgLCAnZGVidWcnKTtcbiAgICAgIGNvbnN0IHsgdXNlcm5hbWU6IHVzZXJJRCB9ID0gYXdhaXQgY29udGV4dC53YXp1aC5zZWN1cml0eS5nZXRDdXJyZW50VXNlcihyZXF1ZXN0LCBjb250ZXh0KTtcbiAgICAgIGZzLnVubGlua1N5bmMoXG4gICAgICAgIHBhdGguam9pbihXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRILCB1c2VySUQsIHJlcXVlc3QucGFyYW1zLm5hbWUpXG4gICAgICApO1xuICAgICAgbG9nKCdyZXBvcnRpbmc6ZGVsZXRlUmVwb3J0QnlOYW1lJywgYCR7cmVxdWVzdC5wYXJhbXMubmFtZX0gcmVwb3J0IHdhcyBkZWxldGVkYCwgJ2luZm8nKTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHsgZXJyb3I6IDAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coJ3JlcG9ydGluZzpkZWxldGVSZXBvcnRCeU5hbWUnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDUwMzIsIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxufVxuIl19